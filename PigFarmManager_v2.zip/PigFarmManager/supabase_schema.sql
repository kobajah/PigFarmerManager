-- ============================================================
--  PIG FARM MANAGER — Supabase / PostgreSQL Schema
--  Backend for optional cloud sync & multi-device access
-- ============================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ── FARMS ──────────────────────────────────────────────────
CREATE TABLE farms (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id       UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    name          TEXT NOT NULL,
    location      TEXT,
    contact_phone TEXT,
    created_at    TIMESTAMPTZ DEFAULT NOW(),
    updated_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ── INFRASTRUCTURE ─────────────────────────────────────────
CREATE TABLE buildings (
    id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    farm_id    UUID NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
    name       TEXT NOT NULL,
    type       TEXT CHECK (type IN ('FARROWING','NURSERY','GROW_FINISH','GESTATION','BOAR','STORAGE')),
    capacity   INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE pens (
    id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    building_id       UUID NOT NULL REFERENCES buildings(id) ON DELETE CASCADE,
    farm_id           UUID NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
    name              TEXT NOT NULL,
    capacity          INT DEFAULT 0,
    current_occupancy INT DEFAULT 0,
    created_at        TIMESTAMPTZ DEFAULT NOW()
);

-- ── PIGS ───────────────────────────────────────────────────
CREATE TABLE pigs (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    farm_id      UUID NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
    pen_id       UUID REFERENCES pens(id),
    tag_number   TEXT NOT NULL,
    name         TEXT,
    sex          TEXT NOT NULL CHECK (sex IN ('SOW','BOAR','GILT','BARROW')),
    breed        TEXT,
    birth_date   DATE,
    entry_date   DATE NOT NULL DEFAULT CURRENT_DATE,
    entry_weight DECIMAL(8,2),
    status       TEXT NOT NULL DEFAULT 'ACTIVE'
                 CHECK (status IN ('ACTIVE','SOLD','DECEASED','CULLED')),
    dam_id       UUID REFERENCES pigs(id),
    sire_id      UUID REFERENCES pigs(id),
    notes        TEXT,
    created_at   TIMESTAMPTZ DEFAULT NOW(),
    updated_at   TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (farm_id, tag_number)
);

-- ── HEALTH RECORDS ─────────────────────────────────────────
CREATE TABLE weight_records (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pig_id        UUID NOT NULL REFERENCES pigs(id) ON DELETE CASCADE,
    farm_id       UUID NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
    weight_kg     DECIMAL(8,2) NOT NULL,
    recorded_date DATE NOT NULL DEFAULT CURRENT_DATE,
    recorded_by   TEXT,
    notes         TEXT,
    created_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE treatments (
    id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pig_id         UUID NOT NULL REFERENCES pigs(id) ON DELETE CASCADE,
    farm_id        UUID NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
    treatment_date DATE NOT NULL,
    diagnosis      TEXT,
    medicine       TEXT NOT NULL,
    dose           TEXT,
    route          TEXT CHECK (route IN ('ORAL','INJECTION','TOPICAL','IV')),
    duration_days  INT,
    follow_up_date DATE,
    treated_by     TEXT,
    cost           DECIMAL(10,2) DEFAULT 0,
    notes          TEXT,
    created_at     TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE vaccinations (
    id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pig_id            UUID NOT NULL REFERENCES pigs(id) ON DELETE CASCADE,
    farm_id           UUID NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
    vaccine_name      TEXT NOT NULL,
    vaccination_date  DATE NOT NULL,
    next_due_date     DATE,
    dose              TEXT,
    administered_by   TEXT,
    batch_number      TEXT,
    cost              DECIMAL(10,2) DEFAULT 0,
    notes             TEXT,
    created_at        TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE deworming (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pig_id          UUID NOT NULL REFERENCES pigs(id) ON DELETE CASCADE,
    farm_id         UUID NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
    product         TEXT NOT NULL,
    deworming_date  DATE NOT NULL,
    next_due_date   DATE,
    dose            TEXT,
    administered_by TEXT,
    cost            DECIMAL(10,2) DEFAULT 0,
    notes           TEXT,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE movements (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pig_id          UUID NOT NULL REFERENCES pigs(id) ON DELETE CASCADE,
    farm_id         UUID NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
    from_pen_id     UUID REFERENCES pens(id),
    to_pen_id       UUID REFERENCES pens(id),
    movement_date   DATE NOT NULL,
    reason          TEXT,
    notes           TEXT,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── REPRODUCTION ───────────────────────────────────────────
CREATE TABLE breedings (
    id                 UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    farm_id            UUID NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
    sow_id             UUID NOT NULL REFERENCES pigs(id),
    boar_id            UUID REFERENCES pigs(id),
    breeding_date      DATE NOT NULL,
    method             TEXT CHECK (method IN ('NATURAL','AI')),
    ai_batch           TEXT,
    heat_detection_date DATE,
    repeat_due_date    DATE GENERATED ALWAYS AS (breeding_date + INTERVAL '21 days') STORED,
    expected_farrowing DATE GENERATED ALWAYS AS (breeding_date + INTERVAL '114 days') STORED,
    notes              TEXT,
    created_at         TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE pregnancies (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    farm_id                 UUID NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
    sow_id                  UUID NOT NULL REFERENCES pigs(id),
    breeding_id             UUID REFERENCES breedings(id),
    confirmation_date       DATE,
    expected_farrowing_date DATE,
    status                  TEXT DEFAULT 'SUSPECTED'
                            CHECK (status IN ('SUSPECTED','CONFIRMED','OPEN','ABORTED')),
    confirmed_by            TEXT,
    notes                   TEXT,
    created_at              TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE farrowings (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    farm_id         UUID NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
    sow_id          UUID NOT NULL REFERENCES pigs(id),
    pregnancy_id    UUID REFERENCES pregnancies(id),
    farrowing_date  DATE NOT NULL,
    total_born      INT DEFAULT 0,
    born_alive      INT DEFAULT 0,
    stillborn       INT DEFAULT 0,
    mummies         INT DEFAULT 0,
    farrowing_ease  TEXT CHECK (farrowing_ease IN ('EASY','NORMAL','DIFFICULT','ASSISTED')),
    duration_hours  DECIMAL(4,1),
    pen_id          UUID REFERENCES pens(id),
    notes           TEXT,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE litters (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    farm_id             UUID NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
    farrowing_id        UUID NOT NULL REFERENCES farrowings(id),
    sow_id              UUID NOT NULL REFERENCES pigs(id),
    litter_number       INT,
    weaning_date        DATE,
    weaning_weight_avg  DECIMAL(6,2),
    piglets_weaned      INT DEFAULT 0,
    notes               TEXT,
    created_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE piglets (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    litter_id           UUID NOT NULL REFERENCES litters(id) ON DELETE CASCADE,
    farm_id             UUID NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
    tag_number          TEXT,
    sex                 TEXT CHECK (sex IN ('MALE','FEMALE','UNKNOWN')),
    birth_weight        DECIMAL(6,2),
    birth_date          DATE,
    status              TEXT DEFAULT 'ALIVE' CHECK (status IN ('ALIVE','DEAD','SOLD','WEANED')),
    death_date          DATE,
    death_cause         TEXT,
    iron_injection_date DATE,
    castration_date     DATE,
    notes               TEXT,
    created_at          TIMESTAMPTZ DEFAULT NOW()
);

-- ── FEED ───────────────────────────────────────────────────
CREATE TABLE feed_formulas (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    farm_id         UUID NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
    name            TEXT NOT NULL,
    target_group    TEXT NOT NULL
                    CHECK (target_group IN ('GESTATION','LACTATION','NURSERY','GROWER','FINISHER','BOAR')),
    description     TEXT,
    total_cost_per_kg DECIMAL(10,4) DEFAULT 0,
    crude_protein   DECIMAL(5,2),
    energy_mj       DECIMAL(6,2),
    lysine_pct      DECIMAL(5,3),
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE formula_ingredients (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    formula_id      UUID NOT NULL REFERENCES feed_formulas(id) ON DELETE CASCADE,
    ingredient_name TEXT NOT NULL,
    percentage      DECIMAL(5,2) NOT NULL,
    cost_per_kg     DECIMAL(10,4) DEFAULT 0,
    cp_percent      DECIMAL(5,2),
    de_mj_per_kg    DECIMAL(6,2),
    lysine_pct      DECIMAL(5,3),
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE feed_inventory (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    farm_id             UUID NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
    ingredient_name     TEXT NOT NULL,
    quantity_kg         DECIMAL(12,2) DEFAULT 0,
    unit_cost           DECIMAL(10,4) DEFAULT 0,
    supplier            TEXT,
    last_purchase_date  DATE,
    reorder_level_kg    DECIMAL(10,2) DEFAULT 0,
    notes               TEXT,
    updated_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE feeding_plans (
    id                 UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    farm_id            UUID NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
    formula_id         UUID REFERENCES feed_formulas(id),
    target_group       TEXT NOT NULL,
    daily_amount_kg    DECIMAL(8,3) NOT NULL,
    feeding_frequency  INT DEFAULT 2,
    start_date         DATE,
    end_date           DATE,
    is_active          BOOLEAN DEFAULT TRUE,
    notes              TEXT,
    created_at         TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE feed_consumption (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    farm_id          UUID NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
    formula_id       UUID REFERENCES feed_formulas(id),
    consumption_date DATE NOT NULL,
    target_group     TEXT NOT NULL,
    amount_kg        DECIMAL(10,3) NOT NULL,
    pig_count        INT,
    recorded_by      TEXT,
    notes            TEXT,
    created_at       TIMESTAMPTZ DEFAULT NOW()
);

-- ── FINANCE ────────────────────────────────────────────────
CREATE TABLE sales (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    farm_id      UUID NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
    pig_id       UUID REFERENCES pigs(id),
    sale_date    DATE NOT NULL,
    weight_kg    DECIMAL(8,2),
    price_per_kg DECIMAL(10,2),
    total_amount DECIMAL(12,2) NOT NULL,
    buyer_name   TEXT,
    buyer_contact TEXT,
    sale_type    TEXT DEFAULT 'LIVE' CHECK (sale_type IN ('LIVE','SLAUGHTER','BREEDING')),
    notes        TEXT,
    created_at   TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE expenses (
    id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    farm_id        UUID NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
    expense_date   DATE NOT NULL,
    category       TEXT NOT NULL
                   CHECK (category IN ('FEED','MEDICINE','VACCINE','LABOR','UTILITIES',
                                       'EQUIPMENT','TRANSPORT','OTHER')),
    amount         DECIMAL(12,2) NOT NULL,
    description    TEXT,
    supplier       TEXT,
    invoice_number TEXT,
    recorded_by    TEXT,
    notes          TEXT,
    created_at     TIMESTAMPTZ DEFAULT NOW()
);

-- ── NOTIFICATIONS ──────────────────────────────────────────
CREATE TABLE farm_notifications (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    farm_id      UUID NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
    pig_id       UUID REFERENCES pigs(id),
    litter_id    UUID REFERENCES litters(id),
    type         TEXT NOT NULL CHECK (type IN (
        'IRON_INJECTION','CASTRATION','REPEAT_BREEDING',
        'FARROWING_DUE','VACCINATION_DUE','DEWORMING_DUE',
        'WEANING_DUE','TREATMENT_FOLLOWUP','PREGNANCY_CHECK',
        'HEAT_DETECTION','LOW_FEED_STOCK','SALE_REMINDER'
    )),
    title        TEXT NOT NULL,
    message      TEXT,
    due_date     DATE NOT NULL,
    priority     TEXT DEFAULT 'MEDIUM' CHECK (priority IN ('LOW','MEDIUM','HIGH','URGENT')),
    is_read      BOOLEAN DEFAULT FALSE,
    is_completed BOOLEAN DEFAULT FALSE,
    completed_at TIMESTAMPTZ,
    created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- ── INDEXES ────────────────────────────────────────────────
CREATE INDEX idx_pigs_farm       ON pigs(farm_id);
CREATE INDEX idx_pigs_status     ON pigs(status);
CREATE INDEX idx_pigs_pen        ON pigs(pen_id);
CREATE INDEX idx_weight_pig      ON weight_records(pig_id);
CREATE INDEX idx_treatment_pig   ON treatments(pig_id);
CREATE INDEX idx_vacc_pig        ON vaccinations(pig_id);
CREATE INDEX idx_deworm_pig      ON deworming(pig_id);
CREATE INDEX idx_breeding_sow    ON breedings(sow_id);
CREATE INDEX idx_breeding_farm   ON breedings(farm_id);
CREATE INDEX idx_breeding_date   ON breedings(breeding_date);
CREATE INDEX idx_preg_sow        ON pregnancies(sow_id);
CREATE INDEX idx_preg_status     ON pregnancies(status);
CREATE INDEX idx_farrow_sow      ON farrowings(sow_id);
CREATE INDEX idx_farrow_date     ON farrowings(farrowing_date);
CREATE INDEX idx_litter_sow      ON litters(sow_id);
CREATE INDEX idx_piglet_litter   ON piglets(litter_id);
CREATE INDEX idx_notif_farm      ON farm_notifications(farm_id);
CREATE INDEX idx_notif_due       ON farm_notifications(due_date);
CREATE INDEX idx_notif_read      ON farm_notifications(is_read);
CREATE INDEX idx_expense_date    ON expenses(expense_date);
CREATE INDEX idx_sale_date       ON sales(sale_date);
CREATE INDEX idx_feed_cons_date  ON feed_consumption(consumption_date);

-- ── ROW LEVEL SECURITY ─────────────────────────────────────
ALTER TABLE farms              ENABLE ROW LEVEL SECURITY;
ALTER TABLE buildings          ENABLE ROW LEVEL SECURITY;
ALTER TABLE pens               ENABLE ROW LEVEL SECURITY;
ALTER TABLE pigs               ENABLE ROW LEVEL SECURITY;
ALTER TABLE weight_records     ENABLE ROW LEVEL SECURITY;
ALTER TABLE treatments         ENABLE ROW LEVEL SECURITY;
ALTER TABLE vaccinations       ENABLE ROW LEVEL SECURITY;
ALTER TABLE deworming          ENABLE ROW LEVEL SECURITY;
ALTER TABLE movements          ENABLE ROW LEVEL SECURITY;
ALTER TABLE breedings          ENABLE ROW LEVEL SECURITY;
ALTER TABLE pregnancies        ENABLE ROW LEVEL SECURITY;
ALTER TABLE farrowings         ENABLE ROW LEVEL SECURITY;
ALTER TABLE litters            ENABLE ROW LEVEL SECURITY;
ALTER TABLE piglets            ENABLE ROW LEVEL SECURITY;
ALTER TABLE feed_formulas      ENABLE ROW LEVEL SECURITY;
ALTER TABLE formula_ingredients ENABLE ROW LEVEL SECURITY;
ALTER TABLE feed_inventory     ENABLE ROW LEVEL SECURITY;
ALTER TABLE feeding_plans      ENABLE ROW LEVEL SECURITY;
ALTER TABLE feed_consumption   ENABLE ROW LEVEL SECURITY;
ALTER TABLE sales              ENABLE ROW LEVEL SECURITY;
ALTER TABLE expenses           ENABLE ROW LEVEL SECURITY;
ALTER TABLE farm_notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Own farms"     ON farms              FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Farm buildings" ON buildings         FOR ALL USING (farm_id IN (SELECT id FROM farms WHERE user_id = auth.uid()));
CREATE POLICY "Farm pens"      ON pens              FOR ALL USING (farm_id IN (SELECT id FROM farms WHERE user_id = auth.uid()));
CREATE POLICY "Farm pigs"      ON pigs              FOR ALL USING (farm_id IN (SELECT id FROM farms WHERE user_id = auth.uid()));
CREATE POLICY "Farm weights"   ON weight_records    FOR ALL USING (farm_id IN (SELECT id FROM farms WHERE user_id = auth.uid()));
CREATE POLICY "Farm treatments" ON treatments       FOR ALL USING (farm_id IN (SELECT id FROM farms WHERE user_id = auth.uid()));
CREATE POLICY "Farm vacc"      ON vaccinations      FOR ALL USING (farm_id IN (SELECT id FROM farms WHERE user_id = auth.uid()));
CREATE POLICY "Farm deworm"    ON deworming         FOR ALL USING (farm_id IN (SELECT id FROM farms WHERE user_id = auth.uid()));
CREATE POLICY "Farm movements" ON movements         FOR ALL USING (farm_id IN (SELECT id FROM farms WHERE user_id = auth.uid()));
CREATE POLICY "Farm breedings" ON breedings         FOR ALL USING (farm_id IN (SELECT id FROM farms WHERE user_id = auth.uid()));
CREATE POLICY "Farm preg"      ON pregnancies       FOR ALL USING (farm_id IN (SELECT id FROM farms WHERE user_id = auth.uid()));
CREATE POLICY "Farm farrow"    ON farrowings        FOR ALL USING (farm_id IN (SELECT id FROM farms WHERE user_id = auth.uid()));
CREATE POLICY "Farm litters"   ON litters           FOR ALL USING (farm_id IN (SELECT id FROM farms WHERE user_id = auth.uid()));
CREATE POLICY "Farm piglets"   ON piglets           FOR ALL USING (farm_id IN (SELECT id FROM farms WHERE user_id = auth.uid()));
CREATE POLICY "Farm formulas"  ON feed_formulas     FOR ALL USING (farm_id IN (SELECT id FROM farms WHERE user_id = auth.uid()));
CREATE POLICY "Farm formula_ing" ON formula_ingredients FOR ALL USING (formula_id IN (SELECT id FROM feed_formulas WHERE farm_id IN (SELECT id FROM farms WHERE user_id = auth.uid())));
CREATE POLICY "Farm inventory" ON feed_inventory    FOR ALL USING (farm_id IN (SELECT id FROM farms WHERE user_id = auth.uid()));
CREATE POLICY "Farm feed_plan" ON feeding_plans     FOR ALL USING (farm_id IN (SELECT id FROM farms WHERE user_id = auth.uid()));
CREATE POLICY "Farm feed_cons" ON feed_consumption  FOR ALL USING (farm_id IN (SELECT id FROM farms WHERE user_id = auth.uid()));
CREATE POLICY "Farm sales"     ON sales             FOR ALL USING (farm_id IN (SELECT id FROM farms WHERE user_id = auth.uid()));
CREATE POLICY "Farm expenses"  ON expenses          FOR ALL USING (farm_id IN (SELECT id FROM farms WHERE user_id = auth.uid()));
CREATE POLICY "Farm notifs"    ON farm_notifications FOR ALL USING (farm_id IN (SELECT id FROM farms WHERE user_id = auth.uid()));

-- ── AUTO-NOTIFICATION TRIGGERS ─────────────────────────────
CREATE OR REPLACE FUNCTION fn_farrowing_notifications()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    -- Iron injection at D+3
    INSERT INTO farm_notifications(farm_id,pig_id,type,title,message,due_date,priority)
    VALUES(NEW.farm_id,NEW.sow_id,'IRON_INJECTION',
           'Iron Injection Due','Piglets need iron injection (3 days old)',
           NEW.farrowing_date + 3,'HIGH');
    -- Castration at D+7
    INSERT INTO farm_notifications(farm_id,pig_id,type,title,message,due_date,priority)
    VALUES(NEW.farm_id,NEW.sow_id,'CASTRATION',
           'Castration Due','Male piglets ready for castration',
           NEW.farrowing_date + 7,'MEDIUM');
    -- Weaning at D+21
    INSERT INTO farm_notifications(farm_id,pig_id,type,title,message,due_date,priority)
    VALUES(NEW.farm_id,NEW.sow_id,'WEANING_DUE',
           'Weaning Due','Litter ready to be weaned (21 days)',
           NEW.farrowing_date + 21,'HIGH');
    RETURN NEW;
END; $$;

CREATE OR REPLACE FUNCTION fn_breeding_notifications()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    -- Repeat heat check at D+21
    INSERT INTO farm_notifications(farm_id,pig_id,type,title,message,due_date,priority)
    VALUES(NEW.farm_id,NEW.sow_id,'REPEAT_BREEDING',
           'Return to Heat Check','Check if sow returns to heat (not pregnant)',
           NEW.breeding_date + 21,'HIGH');
    -- Pregnancy confirmation at D+28
    INSERT INTO farm_notifications(farm_id,pig_id,type,title,message,due_date,priority)
    VALUES(NEW.farm_id,NEW.sow_id,'PREGNANCY_CHECK',
           'Pregnancy Check Due','Confirm pregnancy by ultrasound',
           NEW.breeding_date + 28,'MEDIUM');
    RETURN NEW;
END; $$;

CREATE OR REPLACE FUNCTION fn_pregnancy_farrowing_alert()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    IF NEW.status = 'CONFIRMED' AND NEW.expected_farrowing_date IS NOT NULL THEN
        -- Pre-farrowing alert D-7
        INSERT INTO farm_notifications(farm_id,pig_id,type,title,message,due_date,priority)
        VALUES(NEW.farm_id,NEW.sow_id,'FARROWING_DUE',
               'Farrowing in 7 Days','Move sow to farrowing crate, prepare supplies',
               NEW.expected_farrowing_date - 7,'URGENT');
        -- Farrowing day
        INSERT INTO farm_notifications(farm_id,pig_id,type,title,message,due_date,priority)
        VALUES(NEW.farm_id,NEW.sow_id,'FARROWING_DUE',
               'Farrowing Expected Today','Sow is due to farrow — monitor closely',
               NEW.expected_farrowing_date,'URGENT');
    END IF;
    RETURN NEW;
END; $$;

CREATE TRIGGER trg_farrowing_notif  AFTER INSERT ON farrowings  FOR EACH ROW EXECUTE FUNCTION fn_farrowing_notifications();
CREATE TRIGGER trg_breeding_notif   AFTER INSERT ON breedings   FOR EACH ROW EXECUTE FUNCTION fn_breeding_notifications();
CREATE TRIGGER trg_pregnancy_notif  AFTER INSERT OR UPDATE ON pregnancies FOR EACH ROW EXECUTE FUNCTION fn_pregnancy_farrowing_alert();

-- ── VIEWS ─────────────────────────────────────────────────
CREATE VIEW v_active_pregnancies AS
SELECT p.id, p.farm_id, pg.tag_number, pg.name AS sow_name,
       b.breeding_date, p.expected_farrowing_date, p.status,
       (p.expected_farrowing_date - CURRENT_DATE) AS days_to_farrow
FROM pregnancies p
JOIN pigs pg ON p.sow_id = pg.id
LEFT JOIN breedings b ON p.breeding_id = b.id
WHERE p.status = 'CONFIRMED';

CREATE VIEW v_litter_performance AS
SELECT l.id, l.farm_id, pg.tag_number AS sow_tag,
       f.farrowing_date, f.born_alive,
       l.piglets_weaned, l.weaning_weight_avg,
       ROUND((l.piglets_weaned::DECIMAL / NULLIF(f.born_alive,0)) * 100, 1) AS survival_rate_pct,
       ROUND(l.weaning_weight_avg * l.piglets_weaned, 2)                    AS total_litter_weight_kg
FROM litters l
JOIN farrowings f ON l.farrowing_id = f.id
JOIN pigs pg ON l.sow_id = pg.id;

CREATE VIEW v_feed_monthly_forecast AS
SELECT fp.farm_id, fp.target_group, fp.daily_amount_kg,
       fp.daily_amount_kg * 30 AS monthly_kg_per_head
FROM feeding_plans fp
WHERE fp.is_active = TRUE;

CREATE VIEW v_mortality_stats AS
SELECT farm_id,
       COUNT(*) FILTER (WHERE status = 'DECEASED') AS total_deaths,
       COUNT(*) AS total_pigs,
       ROUND(COUNT(*) FILTER (WHERE status = 'DECEASED')::DECIMAL / NULLIF(COUNT(*),0) * 100, 2) AS mortality_rate_pct
FROM pigs
GROUP BY farm_id;
