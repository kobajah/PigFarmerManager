package com.pigfarm.manager.ui.screens.health

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.pigfarm.manager.data.local.entity.*
import com.pigfarm.manager.ui.components.*
import com.pigfarm.manager.ui.theme.*
import com.pigfarm.manager.viewmodel.HealthViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HealthScreen(
    navController: NavController,
    vm: HealthViewModel = hiltViewModel()
) {
    val treatments       by vm.allTreatments.collectAsState()
    val followUps        by vm.pendingFollowUps.collectAsState()
    val vaccinations     by vm.upcomingVaccinations.collectAsState()
    val deworming        by vm.upcomingDeworming.collectAsState()
    val activePigs       by vm.activePigs.collectAsState()

    var selectedTab      by remember { mutableIntStateOf(0) }
    var showAddTreatment by remember { mutableStateOf(false) }
    var showAddVaccine   by remember { mutableStateOf(false) }
    var showAddDeworm    by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title  = { Text("Animal Health") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor    = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        floatingActionButton = {
            when (selectedTab) {
                0 -> PrimaryFab("Treatment",   Icons.Default.Healing)    { showAddTreatment = true }
                1 -> PrimaryFab("Vaccination", Icons.Default.Vaccines)   { showAddVaccine = true }
                2 -> PrimaryFab("Deworming",   Icons.Default.Medication) { showAddDeworm = true }
                else -> {}
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding)) {

            // Urgent alerts bar
            val urgentCount = followUps.size + vaccinations.size + deworming.size
            if (urgentCount > 0) {
                Card(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = Amber100)
                ) {
                    Row(
                        Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, null, tint = Amber700)
                        Text(
                            buildString {
                                if (followUps.isNotEmpty())   append("${followUps.size} follow-up(s)  ")
                                if (vaccinations.isNotEmpty()) append("${vaccinations.size} vaccine(s)  ")
                                if (deworming.isNotEmpty())   append("${deworming.size} deworming  ")
                                append("due within 14 days")
                            },
                            style = MaterialTheme.typography.bodyMedium, color = Amber700
                        )
                    }
                }
            }

            TabRow(selectedTabIndex = selectedTab) {
                listOf("Treatments", "Vaccines", "Deworming").forEachIndexed { i, t ->
                    Tab(
                        selected = selectedTab == i,
                        onClick  = { selectedTab = i },
                        text     = {
                            BadgedBox(badge = {
                                val count = when (i) { 1 -> vaccinations.size; 2 -> deworming.size; else -> followUps.size }
                                if (count > 0) Badge { Text(count.toString()) }
                            }) { Text(t) }
                        }
                    )
                }
            }

            LazyColumn(
                contentPadding      = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                when (selectedTab) {

                    // ── Treatments ────────────────────────
                    0 -> {
                        if (followUps.isNotEmpty()) {
                            item { SectionHeader("⚠️ Pending Follow-Ups") }
                            items(followUps, key = { "f${it.id}" }) { t ->
                                TreatmentCard(t, isFollowUp = true, onDelete = { vm.deleteTreatment(t) })
                            }
                            item { HorizontalDivider(Modifier.padding(vertical = 4.dp)) }
                        }
                        if (treatments.isEmpty()) {
                            item { EmptyState("No treatment records yet", Icons.Default.Healing) }
                        } else {
                            item { SectionHeader("All Treatments (${treatments.size})") }
                            items(treatments, key = { it.id }) { t ->
                                TreatmentCard(t, isFollowUp = false, onDelete = { vm.deleteTreatment(t) })
                            }
                        }
                    }

                    // ── Vaccinations ──────────────────────
                    1 -> {
                        if (vaccinations.isNotEmpty()) {
                            item { SectionHeader("📅 Due Within 14 Days") }
                            items(vaccinations, key = { "v${it.id}" }) { v ->
                                VaccinationCard(v, isDue = true)
                            }
                            item { HorizontalDivider(Modifier.padding(vertical = 4.dp)) }
                        }
                        item { SectionHeader("All Vaccination Records") }
                        if (vaccinations.isEmpty()) {
                            item { EmptyState("No vaccination records", Icons.Default.Vaccines) }
                        }
                    }

                    // ── Deworming ─────────────────────────
                    2 -> {
                        if (deworming.isNotEmpty()) {
                            item { SectionHeader("📅 Due Within 14 Days") }
                            items(deworming, key = { "d${it.id}" }) { d ->
                                DewormingCard(d, isDue = true)
                            }
                            item { HorizontalDivider(Modifier.padding(vertical = 4.dp)) }
                        }
                        item { SectionHeader("All Deworming Records") }
                        if (deworming.isEmpty()) {
                            item { EmptyState("No deworming records", Icons.Default.Medication) }
                        }
                    }
                }
                item { Spacer(Modifier.height(80.dp)) }
            }
        }
    }

    if (showAddTreatment) AddTreatmentDialog(activePigs, onDismiss = { showAddTreatment = false }) { vm.addTreatment(it); showAddTreatment = false }
    if (showAddVaccine)   AddVaccinationDialog(activePigs, onDismiss = { showAddVaccine = false }) { vm.addVaccination(it); showAddVaccine = false }
    if (showAddDeworm)    AddDewormingDialog(activePigs, onDismiss = { showAddDeworm = false }) { vm.addDeworming(it); showAddDeworm = false }
}

@Composable
private fun TreatmentCard(t: TreatmentEntity, isFollowUp: Boolean, onDelete: () -> Unit) {
    var showDelete by remember { mutableStateOf(false) }
    Card(
        Modifier.fillMaxWidth(),
        colors    = CardDefaults.cardColors(containerColor = if (isFollowUp) Amber100 else MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(t.medicine, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                IconButton(onClick = { showDelete = true }, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Delete, null, tint = Red400, modifier = Modifier.size(18.dp))
                }
            }
            if (t.diagnosis.isNotBlank())
                Text("Dx: ${t.diagnosis}", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                LabeledField("Pig", "#${t.pigId}")
                LabeledField("Date", t.treatmentDate.toDateString())
                if (t.dose.isNotBlank()) LabeledField("Dose", t.dose)
                t.route?.let { LabeledField("Route", it.name) }
            }
            t.followUpDate?.let {
                val days = it.daysUntil()
                Text(
                    "Follow-up: ${it.toDateString()} (${if (days >= 0) "in $days days" else "${-days}d overdue"})",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (days < 0) Red700 else if (days <= 2) Amber700 else Green600
                )
            }
            if (t.cost > 0) Text("Cost: %.2f".format(t.cost), style = MaterialTheme.typography.bodySmall)
        }
    }
    if (showDelete) {
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text("Delete Treatment") },
            text  = { Text("Delete treatment record for ${t.medicine}?") },
            confirmButton = { TextButton(onClick = { onDelete(); showDelete = false }) { Text("Delete", color = Red700) } },
            dismissButton = { TextButton(onClick = { showDelete = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun VaccinationCard(v: VaccinationEntity, isDue: Boolean) {
    Card(
        Modifier.fillMaxWidth(),
        colors    = CardDefaults.cardColors(containerColor = if (isDue) Amber100 else MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(v.vaccineName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (isDue) {
                    v.nextDueDate?.let {
                        val days = it.daysUntil()
                        Text(
                            if (days <= 0) "DUE TODAY" else "Due in $days days",
                            style = MaterialTheme.typography.labelMedium,
                            color = if (days <= 0) Red700 else Amber700
                        )
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                LabeledField("Pig", "#${v.pigId}")
                LabeledField("Given", v.vaccinationDate.toDateString())
                v.nextDueDate?.let { LabeledField("Next due", it.toDateString()) }
            }
            if (v.batchNumber.isNotBlank()) Text("Batch: ${v.batchNumber}", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun DewormingCard(d: DewormingEntity, isDue: Boolean) {
    Card(
        Modifier.fillMaxWidth(),
        colors    = CardDefaults.cardColors(containerColor = if (isDue) Amber100 else MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(d.product, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (isDue) d.nextDueDate?.let {
                    val days = it.daysUntil()
                    Text(if (days <= 0) "DUE TODAY" else "Due in $days days",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (days <= 0) Red700 else Amber700)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                LabeledField("Pig", "#${d.pigId}")
                LabeledField("Given", d.dewormingDate.toDateString())
                d.nextDueDate?.let { LabeledField("Next", it.toDateString()) }
            }
        }
    }
}

// ── Dialogs ──────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddTreatmentDialog(pigs: List<PigEntity>, onDismiss: () -> Unit, onSave: (TreatmentEntity) -> Unit) {
    var selectedPig  by remember { mutableStateOf<Long?>(null) }
    var medicine     by remember { mutableStateOf("") }
    var diagnosis    by remember { mutableStateOf("") }
    var dose         by remember { mutableStateOf("") }
    var durationDays by remember { mutableStateOf("1") }
    var followUp     by remember { mutableStateOf("") }
    var cost         by remember { mutableStateOf("") }
    var pigExpanded  by remember { mutableStateOf(false) }
    var routeExp     by remember { mutableStateOf(false) }
    var route        by remember { mutableStateOf(TreatmentRoute.INJECTION) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Record Treatment") },
        text  = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.heightIn(max = 400.dp)) {
                item {
                    ExposedDropdownMenuBox(expanded = pigExpanded, onExpandedChange = { pigExpanded = it }) {
                        OutlinedTextField(value = pigs.find { it.id == selectedPig }?.tagNumber ?: "Select Pig *",
                            onValueChange = {}, readOnly = true, label = { Text("Pig") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(pigExpanded) },
                            modifier = Modifier.menuAnchor().fillMaxWidth())
                        ExposedDropdownMenu(expanded = pigExpanded, onDismissRequest = { pigExpanded = false }) {
                            pigs.forEach { p -> DropdownMenuItem(text = { Text("${p.tagNumber} (${p.sex.name})") }, onClick = { selectedPig = p.id; pigExpanded = false }) }
                        }
                    }
                }
                item { OutlinedTextField(value = medicine, onValueChange = { medicine = it }, label = { Text("Medicine *") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(value = diagnosis, onValueChange = { diagnosis = it }, label = { Text("Diagnosis") }, modifier = Modifier.fillMaxWidth()) }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = dose, onValueChange = { dose = it }, label = { Text("Dose") }, modifier = Modifier.weight(1f), singleLine = true)
                        ExposedDropdownMenuBox(expanded = routeExp, onExpandedChange = { routeExp = it }, modifier = Modifier.weight(1f)) {
                            OutlinedTextField(value = route.name, onValueChange = {}, readOnly = true, label = { Text("Route") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(routeExp) },
                                modifier = Modifier.menuAnchor().fillMaxWidth())
                            ExposedDropdownMenu(expanded = routeExp, onDismissRequest = { routeExp = false }) {
                                TreatmentRoute.entries.forEach { r -> DropdownMenuItem(text = { Text(r.name) }, onClick = { route = r; routeExp = false }) }
                            }
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = durationDays, onValueChange = { durationDays = it }, label = { Text("Days") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(value = cost, onValueChange = { cost = it }, label = { Text("Cost") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                }
                item { OutlinedTextField(value = followUp, onValueChange = { followUp = it }, label = { Text("Follow-up date (dd/MM/yyyy)") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
            }
        },
        confirmButton = {
            TextButton(enabled = selectedPig != null && medicine.isNotBlank(), onClick = {
                val followMs = runCatching {
                    java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).parse(followUp)?.time
                }.getOrNull()
                onSave(TreatmentEntity(pigId = selectedPig!!, farmId = 1L, medicine = medicine, diagnosis = diagnosis,
                    dose = dose, route = route, durationDays = durationDays.toIntOrNull() ?: 1,
                    followUpDate = followMs, cost = cost.toDoubleOrNull() ?: 0.0))
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddVaccinationDialog(pigs: List<PigEntity>, onDismiss: () -> Unit, onSave: (VaccinationEntity) -> Unit) {
    var selectedPig  by remember { mutableStateOf<Long?>(null) }
    var vaccine      by remember { mutableStateOf("") }
    var dose         by remember { mutableStateOf("") }
    var nextDue      by remember { mutableStateOf("") }
    var batch        by remember { mutableStateOf("") }
    var cost         by remember { mutableStateOf("") }
    var pigExpanded  by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Record Vaccination") },
        text  = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ExposedDropdownMenuBox(expanded = pigExpanded, onExpandedChange = { pigExpanded = it }) {
                    OutlinedTextField(value = pigs.find { it.id == selectedPig }?.tagNumber ?: "Select Pig *",
                        onValueChange = {}, readOnly = true, label = { Text("Pig") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(pigExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = pigExpanded, onDismissRequest = { pigExpanded = false }) {
                        pigs.forEach { p -> DropdownMenuItem(text = { Text(p.tagNumber) }, onClick = { selectedPig = p.id; pigExpanded = false }) }
                    }
                }
                OutlinedTextField(value = vaccine, onValueChange = { vaccine = it }, label = { Text("Vaccine Name *") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = dose, onValueChange = { dose = it }, label = { Text("Dose") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = cost, onValueChange = { cost = it }, label = { Text("Cost") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                OutlinedTextField(value = batch, onValueChange = { batch = it }, label = { Text("Batch Number") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(value = nextDue, onValueChange = { nextDue = it }, label = { Text("Next due (dd/MM/yyyy)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
        },
        confirmButton = {
            TextButton(enabled = selectedPig != null && vaccine.isNotBlank(), onClick = {
                val nextMs = runCatching { java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).parse(nextDue)?.time }.getOrNull()
                onSave(VaccinationEntity(pigId = selectedPig!!, farmId = 1L, vaccineName = vaccine,
                    dose = dose, nextDueDate = nextMs, batchNumber = batch, cost = cost.toDoubleOrNull() ?: 0.0))
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddDewormingDialog(pigs: List<PigEntity>, onDismiss: () -> Unit, onSave: (DewormingEntity) -> Unit) {
    var selectedPig by remember { mutableStateOf<Long?>(null) }
    var product     by remember { mutableStateOf("") }
    var dose        by remember { mutableStateOf("") }
    var nextDue     by remember { mutableStateOf("") }
    var cost        by remember { mutableStateOf("") }
    var pigExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Record Deworming") },
        text  = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ExposedDropdownMenuBox(expanded = pigExpanded, onExpandedChange = { pigExpanded = it }) {
                    OutlinedTextField(value = pigs.find { it.id == selectedPig }?.tagNumber ?: "Select Pig *",
                        onValueChange = {}, readOnly = true, label = { Text("Pig") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(pigExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = pigExpanded, onDismissRequest = { pigExpanded = false }) {
                        pigs.forEach { p -> DropdownMenuItem(text = { Text(p.tagNumber) }, onClick = { selectedPig = p.id; pigExpanded = false }) }
                    }
                }
                OutlinedTextField(value = product, onValueChange = { product = it }, label = { Text("Product *") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = dose, onValueChange = { dose = it }, label = { Text("Dose") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = cost, onValueChange = { cost = it }, label = { Text("Cost") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                OutlinedTextField(value = nextDue, onValueChange = { nextDue = it }, label = { Text("Next due (dd/MM/yyyy)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
        },
        confirmButton = {
            TextButton(enabled = selectedPig != null && product.isNotBlank(), onClick = {
                val nextMs = runCatching { java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).parse(nextDue)?.time }.getOrNull()
                onSave(DewormingEntity(pigId = selectedPig!!, farmId = 1L, product = product,
                    dose = dose, nextDueDate = nextMs, cost = cost.toDoubleOrNull() ?: 0.0))
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
