package com.pigfarm.manager.ui.screens.notifications

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.pigfarm.manager.data.local.entity.*
import com.pigfarm.manager.ui.components.*
import com.pigfarm.manager.ui.theme.*
import com.pigfarm.manager.viewmodel.NotificationViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsScreen(
    navController: NavController,
    vm: NotificationViewModel = hiltViewModel()
) {
    val notifications by vm.allNotifications.collectAsState()
    val urgent        by vm.urgentNotifications.collectAsState()
    val unreadCount   by vm.unreadCount.collectAsState()
    var selectedTab   by remember { mutableIntStateOf(0) }

    // Group by completed / pending
    val pending   = notifications.filter { !it.isCompleted }
    val completed = notifications.filter { it.isCompleted }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Alerts")
                        if (unreadCount > 0)
                            Badge(containerColor = Red700) { Text(unreadCount.toString()) }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor    = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                ),
                actions = {
                    IconButton(onClick = { vm.markAllRead() }) {
                        Icon(Icons.Default.DoneAll, "Mark all read", tint = MaterialTheme.colorScheme.onPrimary)
                    }
                    IconButton(onClick = { vm.deleteCompleted() }) {
                        Icon(Icons.Default.DeleteSweep, "Clear completed", tint = MaterialTheme.colorScheme.onPrimary)
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding)) {

            // Urgent strip
            if (urgent.isNotEmpty()) {
                Card(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = Red100)
                ) {
                    Row(
                        Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, null, tint = Red700, modifier = Modifier.size(20.dp))
                        Text("${urgent.size} urgent alert(s) require immediate action",
                            style = MaterialTheme.typography.bodyMedium, color = Red700, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            TabRow(selectedTabIndex = selectedTab) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = {
                    BadgedBox(badge = { if (pending.isNotEmpty()) Badge { Text(pending.size.toString()) } }) { Text("Pending") }
                })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Completed (${completed.size})") })
            }

            LazyColumn(
                contentPadding      = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                when (selectedTab) {
                    0 -> {
                        if (pending.isEmpty()) {
                            item {
                                Column(
                                    Modifier.fillMaxWidth().padding(32.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Icon(Icons.Default.CheckCircle, null, modifier = Modifier.size(64.dp), tint = Green600)
                                    Text("All clear! No pending alerts.", style = MaterialTheme.typography.bodyMedium, color = Green600)
                                }
                            }
                        } else {
                            // Group by priority
                            val urgentPending = pending.filter { it.priority == NotificationPriority.URGENT }
                            val highPending   = pending.filter { it.priority == NotificationPriority.HIGH }
                            val otherPending  = pending.filter { it.priority !in listOf(NotificationPriority.URGENT, NotificationPriority.HIGH) }

                            if (urgentPending.isNotEmpty()) {
                                item { SectionHeader("🔴 Urgent") }
                                items(urgentPending, key = { it.id }) { n ->
                                    NotificationCard(n,
                                        onMarkRead      = { vm.markRead(n.id) },
                                        onMarkCompleted = { vm.markCompleted(n.id) },
                                        onDelete        = { vm.delete(n) }
                                    )
                                }
                            }
                            if (highPending.isNotEmpty()) {
                                item { SectionHeader("🟡 High Priority") }
                                items(highPending, key = { it.id }) { n ->
                                    NotificationCard(n,
                                        onMarkRead      = { vm.markRead(n.id) },
                                        onMarkCompleted = { vm.markCompleted(n.id) },
                                        onDelete        = { vm.delete(n) }
                                    )
                                }
                            }
                            if (otherPending.isNotEmpty()) {
                                item { SectionHeader("🔵 Other") }
                                items(otherPending, key = { it.id }) { n ->
                                    NotificationCard(n,
                                        onMarkRead      = { vm.markRead(n.id) },
                                        onMarkCompleted = { vm.markCompleted(n.id) },
                                        onDelete        = { vm.delete(n) }
                                    )
                                }
                            }
                        }
                    }
                    1 -> {
                        if (completed.isEmpty()) {
                            item { EmptyState("No completed alerts yet") }
                        } else {
                            items(completed, key = { it.id }) { n ->
                                CompletedNotificationRow(n, onDelete = { vm.delete(n) })
                            }
                        }
                    }
                }
                item { Spacer(Modifier.height(32.dp)) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NotificationCard(
    n: FarmNotificationEntity,
    onMarkRead: () -> Unit,
    onMarkCompleted: () -> Unit,
    onDelete: () -> Unit
) {
    val (bgColor, accentColor) = when (n.priority) {
        NotificationPriority.URGENT -> Pair(Red100,  Red700)
        NotificationPriority.HIGH   -> Pair(Amber100, Amber700)
        NotificationPriority.MEDIUM -> Pair(Blue100,  Blue600)
        NotificationPriority.LOW    -> Pair(MaterialTheme.colorScheme.surface, ColorLow)
    }

    var showDelete by remember { mutableStateOf(false) }

    Card(
        Modifier.fillMaxWidth(),
        colors    = CardDefaults.cardColors(containerColor = bgColor),
        elevation = CardDefaults.cardElevation(if (n.isRead) 0.dp else 3.dp)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment     = Alignment.Top
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(notificationIcon(n.type), null, tint = accentColor, modifier = Modifier.size(20.dp))
                    Column {
                        Text(n.title, style = MaterialTheme.typography.titleMedium,
                            fontWeight = if (!n.isRead) FontWeight.Bold else FontWeight.Normal,
                            color = accentColor)
                        if (n.message.isNotBlank())
                            Text(n.message, style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                    }
                }
                PriorityBadge(n.priority)
            }

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment     = Alignment.CenterVertically
            ) {
                Column {
                    val daysLeft = n.dueDate.daysUntil()
                    Text(
                        "Due: ${n.dueDate.toDateString()} ${
                            when {
                                daysLeft < 0  -> "(${-daysLeft}d overdue)"
                                daysLeft == 0L -> "(TODAY)"
                                daysLeft <= 3 -> "(in $daysLeft days)"
                                else          -> ""
                            }
                        }",
                        style = MaterialTheme.typography.bodySmall,
                        color = when {
                            daysLeft < 0  -> Red700
                            daysLeft == 0L -> Red700
                            daysLeft <= 3 -> Amber700
                            else          -> MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)
                        }
                    )
                    n.pigId?.let { Text("Pig #$it", style = MaterialTheme.typography.bodySmall) }
                }

                Row {
                    if (!n.isRead) {
                        IconButton(onClick = onMarkRead, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Default.MarkEmailRead, "Mark read", tint = Blue600, modifier = Modifier.size(18.dp))
                        }
                    }
                    IconButton(onClick = onMarkCompleted, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.CheckCircle, "Complete", tint = Green600, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = { showDelete = true }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Delete, "Delete", tint = ColorLow, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }

    if (showDelete) {
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text("Delete Alert") },
            text  = { Text("Delete \"${n.title}\"?") },
            confirmButton = { TextButton(onClick = { onDelete(); showDelete = false }) { Text("Delete", color = Red700) } },
            dismissButton = { TextButton(onClick = { showDelete = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun CompletedNotificationRow(n: FarmNotificationEntity, onDelete: () -> Unit) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            Modifier.padding(12.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(Icons.Default.CheckCircle, null, tint = Green600, modifier = Modifier.size(18.dp))
            Column(Modifier.weight(1f)) {
                Text(n.title, style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
                n.completedAt?.let {
                    Text("Completed ${it.toDateString()}", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                }
            }
            IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.Delete, null, tint = ColorLow, modifier = Modifier.size(16.dp))
            }
        }
    }
}
