package com.pigfarm.manager.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// ── Palette ───────────────────────────────────────────────
val Green800    = Color(0xFF2E7D32)
val Green600    = Color(0xFF43A047)
val Green200    = Color(0xFFA5D6A7)
val Green50     = Color(0xFFE8F5E9)
val Amber700    = Color(0xFFF57F17)
val Amber400    = Color(0xFFFFCA28)
val Amber100    = Color(0xFFFFF8E1)
val Red700      = Color(0xFFC62828)
val Red400      = Color(0xFFEF5350)
val Red100      = Color(0xFFFFEBEE)
val Blue600     = Color(0xFF1E88E5)
val Blue100     = Color(0xFFE3F2FD)
val Brown700    = Color(0xFF5D4037)
val Brown200    = Color(0xFFBCAAA4)
val Surface     = Color(0xFFFAFAFA)
val OnSurface   = Color(0xFF1C1B1F)

// Semantic shorthand used in composables
val ColorUrgent  = Red400
val ColorHigh    = Amber700
val ColorMedium  = Blue600
val ColorLow     = Color(0xFF78909C)
val ColorSuccess = Green600

private val LightColorScheme = lightColorScheme(
    primary          = Green800,
    onPrimary        = Color.White,
    primaryContainer = Green200,
    onPrimaryContainer = Green800,
    secondary        = Amber700,
    onSecondary      = Color.White,
    secondaryContainer = Amber100,
    onSecondaryContainer = Brown700,
    tertiary         = Blue600,
    error            = Red700,
    background       = Green50,
    onBackground     = OnSurface,
    surface          = Surface,
    onSurface        = OnSurface,
    surfaceVariant   = Color(0xFFEEEEEE),
    outline          = Color(0xFFBDBDBD)
)

val AppTypography = Typography(
    headlineLarge  = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Bold,   fontSize = 28.sp, lineHeight = 36.sp),
    headlineMedium = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Bold,   fontSize = 22.sp, lineHeight = 28.sp),
    headlineSmall  = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, lineHeight = 24.sp),
    titleLarge     = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp),
    titleMedium    = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Medium,  fontSize = 14.sp, lineHeight = 20.sp),
    bodyLarge      = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Normal,  fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium     = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Normal,  fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall      = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Normal,  fontSize = 12.sp, lineHeight = 16.sp),
    labelLarge     = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Medium,  fontSize = 14.sp, lineHeight = 20.sp),
    labelSmall     = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Medium,  fontSize = 11.sp, lineHeight = 16.sp)
)

@Composable
fun PigFarmTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        typography  = AppTypography,
        content     = content
    )
}
