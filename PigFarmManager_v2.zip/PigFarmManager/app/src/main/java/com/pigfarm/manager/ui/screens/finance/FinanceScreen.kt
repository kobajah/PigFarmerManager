package com.pigfarm.manager.ui.screens.finance

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.pigfarm.manager.data.local.entity.*
import com.pigfarm.manager.ui.components.*
import com.pigfarm.manager.ui.theme.*
import com.pigfarm.manager.viewmodel.FinanceViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FinanceScreen(
    navController: NavController,
    vm: FinanceViewModel = hiltViewModel()
) {
    val sales            by vm.allSales.collectAsState()
    val expenses         by vm.allExpenses.collectAsState()
    val revenue          by vm.periodRevenue.collectAsState()
    val expense          by vm.periodExpenses.collectAsState()
    val netProfit        by vm.netProfit.collectAsState()
    val byCategory       by vm.expensesByCategory.collectAsState()

    var selectedTab      by remember { mutableIntStateOf(0) }
    var showAddSale      by remember { mutableStateOf(false) }
    var showAddExpense   by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title  = { Text("Finance") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor    = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        floatingActionButton = {
            when (selectedTab) {
                0 -> PrimaryFab("Add Sale",    Icons.Default.AttachMoney)  { showAddSale = true }
                1 -> PrimaryFab("Add Expense", Icons.Default.ShoppingCart) { showAddExpense = true }
                else -> {}
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding)) {

            // P&L Summary card
            Card(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                colors = CardDefaults.cardColors(containerColor = if (netProfit >= 0) Green50 else Red100)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("This Month", style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        PLColumn("Revenue",  revenue ?: 0.0, Green600)
                        PLColumn("Expenses", expense ?: 0.0, Red700)
                        PLColumn("Net",      netProfit, if (netProfit >= 0) Green800 else Red700)
                    }
                    // Profit bar
                    if ((revenue ?: 0.0) > 0) {
                        val profitRatio = (netProfit / (revenue ?: 1.0)).coerceIn(-1.0, 1.0).toFloat()
                        ProgressRow(
                            label      = "Profit margin",
                            value      = profitRatio.coerceAtLeast(0f),
                            valueLabel = "%.1f%%".format(if ((revenue ?: 0.0) > 0) netProfit / (revenue ?: 1.0) * 100 else 0.0),
                            color      = if (netProfit >= 0) Green600 else Red700
                        )
                    }
                }
            }

            TabRow(selectedTabIndex = selectedTab) {
                listOf("Sales", "Expenses", "Breakdown").forEachIndexed { i, t ->
                    Tab(selected = selectedTab == i, onClick = { selectedTab = i }, text = { Text(t) })
                }
            }

            LazyColumn(
                contentPadding      = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                when (selectedTab) {

                    // ── Sales ─────────────────────────────
                    0 -> {
                        if (sales.isEmpty()) {
                            item { EmptyState("No sales recorded yet", Icons.Default.AttachMoney) }
                        } else {
                            items(sales, key = { it.id }) { sale ->
                                SaleCard(sale, onDelete = { vm.deleteSale(sale) })
                            }
                        }
                    }

                    // ── Expenses ──────────────────────────
                    1 -> {
                        if (expenses.isEmpty()) {
                            item { EmptyState("No expenses recorded yet", Icons.Default.ShoppingCart) }
                        } else {
                            items(expenses, key = { it.id }) { exp ->
                                ExpenseCard(exp, onDelete = { vm.deleteExpense(exp) })
                            }
                        }
                    }

                    // ── Breakdown by category ─────────────
                    2 -> {
                        if (byCategory.isEmpty()) {
                            item { EmptyState("No expenses this period") }
                        } else {
                            val total = byCategory.sumOf { it.total }
                            item {
                                Card(
                                    Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                ) {
                                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("Expense Breakdown", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        byCategory.sortedByDescending { it.total }.forEach { cat ->
                                            val ratio = if (total > 0) (cat.total / total).toFloat() else 0f
                                            val catColor = categoryColor(cat.category)
                                            ProgressRow(
                                                label      = cat.category,
                                                value      = ratio,
                                                valueLabel = "%.0f (%.1f%%)".format(cat.total, ratio * 100),
                                                color      = catColor
                                            )
                                        }
                                        HorizontalDivider()
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("TOTAL", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                            Text("%.2f".format(total), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Red700)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                item { Spacer(Modifier.height(80.dp)) }
            }
        }
    }

    if (showAddSale)    AddSaleDialog(onDismiss = { showAddSale = false })    { vm.addSale(it);    showAddSale = false }
    if (showAddExpense) AddExpenseDialog(onDismiss = { showAddExpense = false }) { vm.addExpense(it); showAddExpense = false }
}

@Composable
private fun PLColumn(label: String, value: Double, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("%.0f".format(value), style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold, color = color)
        Text(label, style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
    }
}

@Composable
private fun SaleCard(s: SaleEntity, onDelete: () -> Unit) {
    var showDelete by remember { mutableStateOf(false) }
    Card(
        Modifier.fillMaxWidth(),
        colors    = CardDefaults.cardColors(containerColor = Green50),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(Modifier.padding(14.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.TrendingUp, null, tint = Green600, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(s.saleDate.toDateString(), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                Text("${s.saleType.name}${if (s.buyerName.isNotBlank()) " · ${s.buyerName}" else ""}", style = MaterialTheme.typography.bodySmall)
                if (s.weightKg > 0)
                    Text("%.1f kg @ %.2f/kg".format(s.weightKg, s.pricePerKg), style = MaterialTheme.typography.bodySmall)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("+%.2f".format(s.totalAmount), style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold, color = Green600)
                IconButton(onClick = { showDelete = true }, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Delete, null, tint = Red400, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
    if (showDelete) ConfirmDeleteDialog("sale record", onConfirm = { onDelete(); showDelete = false }, onDismiss = { showDelete = false })
}

@Composable
private fun ExpenseCard(e: ExpenseEntity, onDelete: () -> Unit) {
    var showDelete by remember { mutableStateOf(false) }
    val catColor = categoryColor(e.category.name)
    Card(
        Modifier.fillMaxWidth(),
        colors    = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(Modifier.padding(14.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).background(catColor, androidx.compose.foundation.shape.CircleShape))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(e.description.ifBlank { e.category.name }, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                Text("${e.category.name} · ${e.expenseDate.toDateString()}", style = MaterialTheme.typography.bodySmall)
                if (e.supplier.isNotBlank()) Text("Supplier: ${e.supplier}", style = MaterialTheme.typography.bodySmall)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("-%.2f".format(e.amount), style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold, color = Red700)
                IconButton(onClick = { showDelete = true }, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Delete, null, tint = Red400, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
    if (showDelete) ConfirmDeleteDialog("expense", onConfirm = { onDelete(); showDelete = false }, onDismiss = { showDelete = false })
}

@Composable
private fun ConfirmDeleteDialog(item: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Delete") },
        text  = { Text("Delete this $item?") },
        confirmButton = { TextButton(onClick = onConfirm) { Text("Delete", color = Red700) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

private fun categoryColor(cat: String): Color = when (cat.uppercase()) {
    "FEED"      -> Green600
    "MEDICINE"  -> Blue600
    "VACCINE"   -> Color(0xFF9C27B0)
    "LABOR"     -> Amber700
    "UTILITIES" -> Color(0xFF00BCD4)
    "EQUIPMENT" -> Brown700
    "TRANSPORT" -> Color(0xFF607D8B)
    else        -> ColorLow
}

// ── Add Sale dialog ───────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddSaleDialog(onDismiss: () -> Unit, onSave: (SaleEntity) -> Unit) {
    var weight    by remember { mutableStateOf("") }
    var pricePerKg by remember { mutableStateOf("") }
    var total     by remember { mutableStateOf("") }
    var buyer     by remember { mutableStateOf("") }
    var typeExpanded by remember { mutableStateOf(false) }
    var saleType  by remember { mutableStateOf(SaleType.LIVE) }

    // Auto-compute total
    LaunchedEffect(weight, pricePerKg) {
        val w = weight.toDoubleOrNull() ?: 0.0
        val p = pricePerKg.toDoubleOrNull() ?: 0.0
        if (w > 0 && p > 0) total = "%.2f".format(w * p)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Record Sale") },
        text  = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ExposedDropdownMenuBox(expanded = typeExpanded, onExpandedChange = { typeExpanded = it }) {
                    OutlinedTextField(value = saleType.name, onValueChange = {}, readOnly = true, label = { Text("Sale Type") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(typeExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = typeExpanded, onDismissRequest = { typeExpanded = false }) {
                        SaleType.entries.forEach { t -> DropdownMenuItem(text = { Text(t.name) }, onClick = { saleType = t; typeExpanded = false }) }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = weight, onValueChange = { weight = it }, label = { Text("Weight kg") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = pricePerKg, onValueChange = { pricePerKg = it }, label = { Text("Price/kg") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                OutlinedTextField(value = total, onValueChange = { total = it }, label = { Text("Total Amount *") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(value = buyer, onValueChange = { buyer = it }, label = { Text("Buyer Name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
        },
        confirmButton = {
            TextButton(enabled = total.isNotBlank(), onClick = {
                onSave(SaleEntity(farmId = 1L, saleType = saleType,
                    weightKg = weight.toDoubleOrNull() ?: 0.0,
                    pricePerKg = pricePerKg.toDoubleOrNull() ?: 0.0,
                    totalAmount = total.toDoubleOrNull() ?: 0.0,
                    buyerName = buyer))
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ── Add Expense dialog ────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddExpenseDialog(onDismiss: () -> Unit, onSave: (ExpenseEntity) -> Unit) {
    var amount      by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var supplier    by remember { mutableStateOf("") }
    var category    by remember { mutableStateOf(ExpenseCategory.FEED) }
    var catExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Record Expense") },
        text  = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ExposedDropdownMenuBox(expanded = catExpanded, onExpandedChange = { catExpanded = it }) {
                    OutlinedTextField(value = category.name, onValueChange = {}, readOnly = true, label = { Text("Category") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(catExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = catExpanded, onDismissRequest = { catExpanded = false }) {
                        ExpenseCategory.entries.forEach { c -> DropdownMenuItem(text = { Text(c.name) }, onClick = { category = c; catExpanded = false }) }
                    }
                }
                OutlinedTextField(value = amount, onValueChange = { amount = it }, label = { Text("Amount *") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Description") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = supplier, onValueChange = { supplier = it }, label = { Text("Supplier") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
        },
        confirmButton = {
            TextButton(enabled = amount.isNotBlank(), onClick = {
                onSave(ExpenseEntity(farmId = 1L, category = category,
                    amount = amount.toDoubleOrNull() ?: 0.0,
                    description = description, supplier = supplier))
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}


