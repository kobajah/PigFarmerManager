package com.pigfarm.manager.data.local.entity

import androidx.room.*

// ── ENUMS ────────────────────────────────────────────────
enum class PigSex       { SOW, BOAR, GILT, BARROW }
enum class PigStatus    { ACTIVE, SOLD, DECEASED, CULLED }
enum class BreedingMethod { NATURAL, AI }
enum class PregnancyStatus { SUSPECTED, CONFIRMED, OPEN, ABORTED }
enum class FarrowingEase { EASY, NORMAL, DIFFICULT, ASSISTED }
enum class PigletSex    { MALE, FEMALE, UNKNOWN }
enum class PigletStatus { ALIVE, DEAD, SOLD, WEANED }
enum class NotificationType {
    IRON_INJECTION, CASTRATION, REPEAT_BREEDING,
    FARROWING_DUE, VACCINATION_DUE, DEWORMING_DUE,
    WEANING_DUE, TREATMENT_FOLLOWUP, PREGNANCY_CHECK,
    HEAT_DETECTION, LOW_FEED_STOCK, SALE_REMINDER
}
enum class NotificationPriority { LOW, MEDIUM, HIGH, URGENT }
enum class ExpenseCategory { FEED, MEDICINE, VACCINE, LABOR, UTILITIES, EQUIPMENT, TRANSPORT, OTHER }
enum class SaleType { LIVE, SLAUGHTER, BREEDING }
enum class TargetGroup { GESTATION, LACTATION, NURSERY, GROWER, FINISHER, BOAR }
enum class TreatmentRoute { ORAL, INJECTION, TOPICAL, IV }

// ── TYPE CONVERTERS ──────────────────────────────────────
class Converters {
    @TypeConverter fun fromPigSex(v: PigSex)                 = v.name
    @TypeConverter fun toPigSex(v: String)                   = PigSex.valueOf(v)
    @TypeConverter fun fromPigStatus(v: PigStatus)           = v.name
    @TypeConverter fun toPigStatus(v: String)                = PigStatus.valueOf(v)
    @TypeConverter fun fromBreedingMethod(v: BreedingMethod) = v.name
    @TypeConverter fun toBreedingMethod(v: String)           = BreedingMethod.valueOf(v)
    @TypeConverter fun fromPregnancyStatus(v: PregnancyStatus) = v.name
    @TypeConverter fun toPregnancyStatus(v: String)          = PregnancyStatus.valueOf(v)
    @TypeConverter fun fromFarrowingEase(v: FarrowingEase?)  = v?.name
    @TypeConverter fun toFarrowingEase(v: String?)           = v?.let { FarrowingEase.valueOf(it) }
    @TypeConverter fun fromPigletSex(v: PigletSex?)          = v?.name
    @TypeConverter fun toPigletSex(v: String?)               = v?.let { PigletSex.valueOf(it) }
    @TypeConverter fun fromPigletStatus(v: PigletStatus)     = v.name
    @TypeConverter fun toPigletStatus(v: String)             = PigletStatus.valueOf(v)
    @TypeConverter fun fromNotificationType(v: NotificationType) = v.name
    @TypeConverter fun toNotificationType(v: String)         = NotificationType.valueOf(v)
    @TypeConverter fun fromNotificationPriority(v: NotificationPriority) = v.name
    @TypeConverter fun toNotificationPriority(v: String)     = NotificationPriority.valueOf(v)
    @TypeConverter fun fromExpenseCategory(v: ExpenseCategory) = v.name
    @TypeConverter fun toExpenseCategory(v: String)          = ExpenseCategory.valueOf(v)
    @TypeConverter fun fromSaleType(v: SaleType)             = v.name
    @TypeConverter fun toSaleType(v: String)                 = SaleType.valueOf(v)
    @TypeConverter fun fromTargetGroup(v: TargetGroup)       = v.name
    @TypeConverter fun toTargetGroup(v: String)              = TargetGroup.valueOf(v)
    @TypeConverter fun fromTreatmentRoute(v: TreatmentRoute?) = v?.name
    @TypeConverter fun toTreatmentRoute(v: String?)          = v?.let { TreatmentRoute.valueOf(it) }
}

// ── FARM ─────────────────────────────────────────────────
@Entity(tableName = "farms")
data class FarmEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val location: String = "",
    val contactPhone: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

// ── BUILDING ──────────────────────────────────────────────
@Entity(
    tableName = "buildings",
    foreignKeys = [ForeignKey(entity = FarmEntity::class, parentColumns = ["id"], childColumns = ["farmId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("farmId")]
)
data class BuildingEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val farmId: Long,
    val name: String,
    val type: String = "",  // FARROWING | NURSERY | GROW_FINISH | GESTATION | BOAR | STORAGE
    val capacity: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

// ── PEN ───────────────────────────────────────────────────
@Entity(
    tableName = "pens",
    foreignKeys = [
        ForeignKey(entity = BuildingEntity::class, parentColumns = ["id"], childColumns = ["buildingId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = FarmEntity::class,     parentColumns = ["id"], childColumns = ["farmId"],     onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("buildingId"), Index("farmId")]
)
data class PenEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val buildingId: Long,
    val farmId: Long,
    val name: String,
    val capacity: Int = 0,
    val currentOccupancy: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

// ── PIG ───────────────────────────────────────────────────
@Entity(
    tableName = "pigs",
    foreignKeys = [
        ForeignKey(entity = FarmEntity::class, parentColumns = ["id"], childColumns = ["farmId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = PenEntity::class,  parentColumns = ["id"], childColumns = ["penId"],  onDelete = ForeignKey.SET_NULL)
    ],
    indices = [Index("farmId"), Index("penId"), Index("status")]
)
data class PigEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val farmId: Long,
    val penId: Long? = null,
    val tagNumber: String,
    val name: String = "",
    val sex: PigSex,
    val breed: String = "",
    val birthDate: Long? = null,           // epoch ms
    val entryDate: Long = System.currentTimeMillis(),
    val entryWeight: Double = 0.0,
    val status: PigStatus = PigStatus.ACTIVE,
    val damId: Long? = null,               // mother pig id
    val sireId: Long? = null,              // father pig id
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

// ── WEIGHT RECORD ─────────────────────────────────────────
@Entity(
    tableName = "weight_records",
    foreignKeys = [ForeignKey(entity = PigEntity::class, parentColumns = ["id"], childColumns = ["pigId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("pigId")]
)
data class WeightRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val pigId: Long,
    val farmId: Long,
    val weightKg: Double,
    val recordedDate: Long = System.currentTimeMillis(),
    val recordedBy: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

// ── TREATMENT ─────────────────────────────────────────────
@Entity(
    tableName = "treatments",
    foreignKeys = [ForeignKey(entity = PigEntity::class, parentColumns = ["id"], childColumns = ["pigId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("pigId"), Index("farmId")]
)
data class TreatmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val pigId: Long,
    val farmId: Long,
    val treatmentDate: Long = System.currentTimeMillis(),
    val diagnosis: String = "",
    val medicine: String,
    val dose: String = "",
    val route: TreatmentRoute? = null,
    val durationDays: Int = 1,
    val followUpDate: Long? = null,
    val treatedBy: String = "",
    val cost: Double = 0.0,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

// ── VACCINATION ───────────────────────────────────────────
@Entity(
    tableName = "vaccinations",
    foreignKeys = [ForeignKey(entity = PigEntity::class, parentColumns = ["id"], childColumns = ["pigId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("pigId"), Index("farmId")]
)
data class VaccinationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val pigId: Long,
    val farmId: Long,
    val vaccineName: String,
    val vaccinationDate: Long = System.currentTimeMillis(),
    val nextDueDate: Long? = null,
    val dose: String = "",
    val administeredBy: String = "",
    val batchNumber: String = "",
    val cost: Double = 0.0,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

// ── DEWORMING ─────────────────────────────────────────────
@Entity(
    tableName = "deworming",
    foreignKeys = [ForeignKey(entity = PigEntity::class, parentColumns = ["id"], childColumns = ["pigId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("pigId"), Index("farmId")]
)
data class DewormingEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val pigId: Long,
    val farmId: Long,
    val product: String,
    val dewormingDate: Long = System.currentTimeMillis(),
    val nextDueDate: Long? = null,
    val dose: String = "",
    val administeredBy: String = "",
    val cost: Double = 0.0,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

// ── MOVEMENT ──────────────────────────────────────────────
@Entity(
    tableName = "movements",
    foreignKeys = [ForeignKey(entity = PigEntity::class, parentColumns = ["id"], childColumns = ["pigId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("pigId"), Index("farmId")]
)
data class MovementEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val pigId: Long,
    val farmId: Long,
    val fromPenId: Long? = null,
    val toPenId: Long? = null,
    val movementDate: Long = System.currentTimeMillis(),
    val reason: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

// ── BREEDING ──────────────────────────────────────────────
@Entity(
    tableName = "breedings",
    foreignKeys = [
        ForeignKey(entity = FarmEntity::class, parentColumns = ["id"], childColumns = ["farmId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = PigEntity::class,  parentColumns = ["id"], childColumns = ["sowId"],  onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("farmId"), Index("sowId"), Index("breedingDate")]
)
data class BreedingEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val farmId: Long,
    val sowId: Long,
    val boarId: Long? = null,
    val breedingDate: Long = System.currentTimeMillis(),
    val method: BreedingMethod = BreedingMethod.NATURAL,
    val aiBatch: String = "",
    val heatDetectionDate: Long? = null,
    // D+21 = repeat heat check; D+114 = expected farrowing — computed in code
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    val repeatDueDate: Long get() = breedingDate + 21L * 24 * 60 * 60 * 1000
    val expectedFarrowingDate: Long get() = breedingDate + 114L * 24 * 60 * 60 * 1000
}

// ── PREGNANCY ─────────────────────────────────────────────
@Entity(
    tableName = "pregnancies",
    foreignKeys = [
        ForeignKey(entity = FarmEntity::class,  parentColumns = ["id"], childColumns = ["farmId"],    onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = BreedingEntity::class, parentColumns = ["id"], childColumns = ["breedingId"], onDelete = ForeignKey.SET_NULL)
    ],
    indices = [Index("farmId"), Index("sowId"), Index("status"), Index("breedingId")]
)
data class PregnancyEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val farmId: Long,
    val sowId: Long,
    val breedingId: Long? = null,
    val confirmationDate: Long? = null,
    val expectedFarrowingDate: Long? = null,
    val status: PregnancyStatus = PregnancyStatus.SUSPECTED,
    val confirmedBy: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

// ── FARROWING ─────────────────────────────────────────────
@Entity(
    tableName = "farrowings",
    foreignKeys = [
        ForeignKey(entity = FarmEntity::class, parentColumns = ["id"], childColumns = ["farmId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = PigEntity::class,  parentColumns = ["id"], childColumns = ["sowId"],  onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("farmId"), Index("sowId"), Index("farrowingDate")]
)
data class FarrowingEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val farmId: Long,
    val sowId: Long,
    val pregnancyId: Long? = null,
    val farrowingDate: Long = System.currentTimeMillis(),
    val totalBorn: Int = 0,
    val bornAlive: Int = 0,
    val stillborn: Int = 0,
    val mummies: Int = 0,
    val farrowingEase: FarrowingEase? = null,
    val durationHours: Double = 0.0,
    val penId: Long? = null,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

// ── LITTER ────────────────────────────────────────────────
@Entity(
    tableName = "litters",
    foreignKeys = [
        ForeignKey(entity = FarrowingEntity::class, parentColumns = ["id"], childColumns = ["farrowingId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = FarmEntity::class,      parentColumns = ["id"], childColumns = ["farmId"],      onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("farrowingId"), Index("sowId"), Index("farmId")]
)
data class LitterEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val farmId: Long,
    val farrowingId: Long,
    val sowId: Long,
    val litterNumber: Int = 1,             // parity
    val weaningDate: Long? = null,
    val weaningWeightAvg: Double = 0.0,
    val pigletsWeaned: Int = 0,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

// ── PIGLET ────────────────────────────────────────────────
@Entity(
    tableName = "piglets",
    foreignKeys = [
        ForeignKey(entity = LitterEntity::class, parentColumns = ["id"], childColumns = ["litterId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = FarmEntity::class,   parentColumns = ["id"], childColumns = ["farmId"],   onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("litterId"), Index("farmId")]
)
data class PigletEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val litterId: Long,
    val farmId: Long,
    val tagNumber: String = "",
    val sex: PigletSex? = PigletSex.UNKNOWN,
    val birthWeight: Double = 0.0,
    val birthDate: Long? = null,
    val status: PigletStatus = PigletStatus.ALIVE,
    val deathDate: Long? = null,
    val deathCause: String = "",
    val ironInjectionDate: Long? = null,
    val castrationDate: Long? = null,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

// ── FEED FORMULA ──────────────────────────────────────────
@Entity(
    tableName = "feed_formulas",
    foreignKeys = [ForeignKey(entity = FarmEntity::class, parentColumns = ["id"], childColumns = ["farmId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("farmId")]
)
data class FeedFormulaEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val farmId: Long,
    val name: String,
    val targetGroup: TargetGroup,
    val description: String = "",
    val totalCostPerKg: Double = 0.0,
    val crudeProtein: Double = 0.0,
    val energyMj: Double = 0.0,
    val lysinePct: Double = 0.0,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

// ── FORMULA INGREDIENT ────────────────────────────────────
@Entity(
    tableName = "formula_ingredients",
    foreignKeys = [ForeignKey(entity = FeedFormulaEntity::class, parentColumns = ["id"], childColumns = ["formulaId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("formulaId")]
)
data class FormulaIngredientEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val formulaId: Long,
    val ingredientName: String,
    val percentage: Double,     // % of formula
    val costPerKg: Double = 0.0,
    val cpPercent: Double = 0.0,
    val deMjPerKg: Double = 0.0,
    val lysinePct: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis()
)

// ── FEED INVENTORY ────────────────────────────────────────
@Entity(
    tableName = "feed_inventory",
    foreignKeys = [ForeignKey(entity = FarmEntity::class, parentColumns = ["id"], childColumns = ["farmId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("farmId")]
)
data class FeedInventoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val farmId: Long,
    val ingredientName: String,
    val quantityKg: Double = 0.0,
    val unitCost: Double = 0.0,
    val supplier: String = "",
    val lastPurchaseDate: Long? = null,
    val reorderLevelKg: Double = 0.0,
    val notes: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)

// ── FEEDING PLAN ──────────────────────────────────────────
@Entity(
    tableName = "feeding_plans",
    foreignKeys = [ForeignKey(entity = FarmEntity::class, parentColumns = ["id"], childColumns = ["farmId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("farmId")]
)
data class FeedingPlanEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val farmId: Long,
    val formulaId: Long? = null,
    val targetGroup: TargetGroup,
    val dailyAmountKg: Double,
    val feedingFrequency: Int = 2,
    val startDate: Long? = null,
    val endDate: Long? = null,
    val isActive: Boolean = true,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

// ── FEED CONSUMPTION ──────────────────────────────────────
@Entity(
    tableName = "feed_consumption",
    foreignKeys = [ForeignKey(entity = FarmEntity::class, parentColumns = ["id"], childColumns = ["farmId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("farmId"), Index("consumptionDate")]
)
data class FeedConsumptionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val farmId: Long,
    val formulaId: Long? = null,
    val consumptionDate: Long = System.currentTimeMillis(),
    val targetGroup: TargetGroup,
    val amountKg: Double,
    val pigCount: Int = 0,
    val recordedBy: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

// ── SALE ──────────────────────────────────────────────────
@Entity(
    tableName = "sales",
    foreignKeys = [ForeignKey(entity = FarmEntity::class, parentColumns = ["id"], childColumns = ["farmId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("farmId"), Index("saleDate")]
)
data class SaleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val farmId: Long,
    val pigId: Long? = null,
    val saleDate: Long = System.currentTimeMillis(),
    val weightKg: Double = 0.0,
    val pricePerKg: Double = 0.0,
    val totalAmount: Double,
    val buyerName: String = "",
    val buyerContact: String = "",
    val saleType: SaleType = SaleType.LIVE,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

// ── EXPENSE ───────────────────────────────────────────────
@Entity(
    tableName = "expenses",
    foreignKeys = [ForeignKey(entity = FarmEntity::class, parentColumns = ["id"], childColumns = ["farmId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("farmId"), Index("expenseDate")]
)
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val farmId: Long,
    val expenseDate: Long = System.currentTimeMillis(),
    val category: ExpenseCategory,
    val amount: Double,
    val description: String = "",
    val supplier: String = "",
    val invoiceNumber: String = "",
    val recordedBy: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

// ── FARM NOTIFICATION ─────────────────────────────────────
@Entity(
    tableName = "farm_notifications",
    foreignKeys = [ForeignKey(entity = FarmEntity::class, parentColumns = ["id"], childColumns = ["farmId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("farmId"), Index("dueDate"), Index("isRead")]
)
data class FarmNotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val farmId: Long,
    val pigId: Long? = null,
    val litterId: Long? = null,
    val type: NotificationType,
    val title: String,
    val message: String = "",
    val dueDate: Long,
    val priority: NotificationPriority = NotificationPriority.MEDIUM,
    val isRead: Boolean = false,
    val isCompleted: Boolean = false,
    val completedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

// ── JOIN DATA CLASSES (for queries with multiple tables) ──
data class PigWithPen(
    @Embedded val pig: PigEntity,
    @Relation(parentColumn = "penId", entityColumn = "id") val pen: PenEntity?
)

data class PigWithHealth(
    @Embedded val pig: PigEntity,
    @Relation(parentColumn = "id", entityColumn = "pigId") val weights: List<WeightRecordEntity>,
    @Relation(parentColumn = "id", entityColumn = "pigId") val treatments: List<TreatmentEntity>,
    @Relation(parentColumn = "id", entityColumn = "pigId") val vaccinations: List<VaccinationEntity>,
    @Relation(parentColumn = "id", entityColumn = "pigId") val deworming: List<DewormingEntity>
)

data class BreedingWithSow(
    @Embedded val breeding: BreedingEntity,
    @Relation(parentColumn = "sowId", entityColumn = "id") val sow: PigEntity?
)

data class PregnancyWithSow(
    @Embedded val pregnancy: PregnancyEntity,
    @Relation(parentColumn = "sowId", entityColumn = "id") val sow: PigEntity?
)

data class FarrowingWithSow(
    @Embedded val farrowing: FarrowingEntity,
    @Relation(parentColumn = "sowId", entityColumn = "id") val sow: PigEntity?
)

data class LitterWithPiglets(
    @Embedded val litter: LitterEntity,
    @Relation(parentColumn = "id", entityColumn = "litterId") val piglets: List<PigletEntity>,
    @Relation(parentColumn = "sowId", entityColumn = "id")    val sow: PigEntity?
)

data class FormulaWithIngredients(
    @Embedded val formula: FeedFormulaEntity,
    @Relation(parentColumn = "id", entityColumn = "formulaId") val ingredients: List<FormulaIngredientEntity>
)
