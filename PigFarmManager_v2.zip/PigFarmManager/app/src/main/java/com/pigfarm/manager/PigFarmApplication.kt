package com.pigfarm.manager

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.*
import com.pigfarm.manager.worker.NotificationWorker
import dagger.hilt.android.HiltAndroidApp
import java.util.concurrent.TimeUnit
import javax.inject.Inject

@HiltAndroidApp
class PigFarmApplication : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory: HiltWorkerFactory

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
        scheduleNotificationWorker()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)

            listOf(
                NotificationChannel(CHANNEL_URGENT, "Urgent Alerts",    NotificationManager.IMPORTANCE_HIGH).also   { it.description = "Farrowing, heat checks, emergencies" },
                NotificationChannel(CHANNEL_HEALTH,  "Health Reminders", NotificationManager.IMPORTANCE_DEFAULT).also { it.description = "Vaccines, deworming, treatments" },
                NotificationChannel(CHANNEL_FEED,    "Feed Alerts",     NotificationManager.IMPORTANCE_LOW).also    { it.description = "Low stock, feeding schedule" },
                NotificationChannel(CHANNEL_GENERAL, "General",         NotificationManager.IMPORTANCE_LOW).also    { it.description = "General farm notifications" }
            ).forEach { manager.createNotificationChannel(it) }
        }
    }

    private fun scheduleNotificationWorker() {
        val request = PeriodicWorkRequestBuilder<NotificationWorker>(6, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiresBatteryNotLow(false).build())
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            NotificationWorker.WORK_NAME,
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }

    companion object {
        const val CHANNEL_URGENT  = "pig_farm_urgent"
        const val CHANNEL_HEALTH  = "pig_farm_health"
        const val CHANNEL_FEED    = "pig_farm_feed"
        const val CHANNEL_GENERAL = "pig_farm_general"
    }
}
