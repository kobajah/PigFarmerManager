package com.pigfarm.manager.ui.screens.farrowing

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.pigfarm.manager.data.local.entity.*
import com.pigfarm.manager.ui.components.*
import com.pigfarm.manager.ui.theme.*
import com.pigfarm.manager.viewmodel.FarrowingViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FarrowingScreen(
    navController: NavController,
    vm: FarrowingViewModel = hiltViewModel()
) {
    val farrowings      by vm.farrowingsWithSow.collectAsState()
    val litters         by vm.littersWithPiglets.collectAsState()
    val topLitters      by vm.topLitters.collectAsState()
    val pigletsNeedIron by vm.pigletsNeedingIron.collectAsState()
    val avgBornAlive    by vm.avgBornAlive.collectAsState()
    val activeSows      by vm.activeSows.collectAsState()

    var selectedTab     by remember { mutableIntStateOf(0) }
    var showAddFarrowing by remember { mutableStateOf(false) }
    var expandedLitter  by remember { mutableStateOf<Long?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Farrowing & Litters") },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary)
            )
        },
        floatingActionButton = {
            if (selectedTab == 0) PrimaryFab("Record Farrowing", Icons.Default.ChildCare) { showAddFarrowing = true }
        }
    ) { padding ->
        Column(Modifier.padding(padding)) {
            // Summary bar
            Card(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                colors = CardDefaults.cardColors(containerColor = Green50)
            ) {
                Row(
                    Modifier.padding(12.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(farrowings.size.toString(), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Green600)
                        Text("Total Farrowings", style = MaterialTheme.typography.bodySmall)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("%.1f".format(avgBornAlive), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Blue600)
                        Text("Avg Born Alive", style = MaterialTheme.typography.bodySmall)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(pigletsNeedIron.size.toString(), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Amber700)
                        Text("Need Iron Inj.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            TabRow(selectedTabIndex = selectedTab) {
                listOf("Farrowings", "Litters", "Piglets", "Top Litters").forEachIndexed { i, t ->
                    Tab(selected = selectedTab == i, onClick = { selectedTab = i }, text = { Text(t) })
                }
            }

            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                when (selectedTab) {
                    // ── Farrowings ──────────────────────
                    0 -> {
                        if (farrowings.isEmpty()) {
                            item { EmptyState("No farrowing records yet", Icons.Default.ChildCare) }
                        } else {
                            items(farrowings, key = { it.farrowing.id }) { fws ->
                                FarrowingCard(fws)
                            }
                        }
                    }
                    // ── Litters ─────────────────────────
                    1 -> {
                        if (litters.isEmpty()) {
                            item { EmptyState("No litters recorded") }
                        } else {
                            items(litters, key = { it.litter.id }) { lws ->
                                LitterCard(
                                    lws        = lws,
                                    isExpanded = expandedLitter == lws.litter.id,
                                    onToggle   = {
                                        expandedLitter = if (expandedLitter == lws.litter.id) null else lws.litter.id
                                    },
                                    onMarkIron = vm::markIronInjection,
                                    onPigletDied = { pid -> vm.markPigletDeath(pid, "Unknown") }
                                )
                            }
                        }
                    }
                    // ── Iron Injection ──────────────────
                    2 -> {
                        if (pigletsNeedIron.isEmpty()) {
                            item {
                                Card(
                                    Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = Green50)
                                ) {
                                    Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Icon(Icons.Default.CheckCircle, null, tint = Green600)
                                        Text("All piglets have received iron injection", color = Green600)
                                    }
                                }
                            }
                        } else {
                            item {
                                Card(
                                    Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = Amber100)
                                ) {
                                    Column(Modifier.padding(12.dp)) {
                                        Text("${pigletsNeedIron.size} piglets need iron injection",
                                            style = MaterialTheme.typography.titleMedium, color = Amber700)
                                        Text("Born 3+ days ago, injection not yet recorded",
                                            style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                            items(pigletsNeedIron, key = { it.id }) { piglet ->
                                PigletActionCard(
                                    piglet   = piglet,
                                    action   = "Inject Iron",
                                    actionColor = Amber700,
                                    onAction = { vm.markIronInjection(piglet.id) }
                                )
                            }
                        }
                    }
                    // ── Top Litters ─────────────────────
                    3 -> {
                        if (topLitters.isEmpty()) {
                            item { EmptyState("No completed litters yet") }
                        } else {
                            items(topLitters.take(10).mapIndexed { i, l -> Pair(i + 1, l) }) { (rank, litter) ->
                                TopLitterRow(rank = rank, litter = litter)
                            }
                        }
                    }
                }
                item { Spacer(Modifier.height(80.dp)) }
            }
        }
    }

    if (showAddFarrowing) {
        AddFarrowingDialog(
            sows      = activeSows,
            onDismiss = { showAddFarrowing = false }
        ) { farrowing ->
            vm.addFarrowing(farrowing)
            showAddFarrowing = false
        }
    }
}

@Composable
private fun FarrowingCard(fws: FarrowingWithSow) {
    val f = fws.farrowing
    Card(
        Modifier.fillMaxWidth(),
        colors    = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text(fws.sow?.tagNumber ?: "—", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(f.farrowingDate.toDateString(), style = MaterialTheme.typography.bodySmall)
                }
                f.farrowingEase?.let {
                    val color = when (it) {
                        FarrowingEase.EASY -> Green600
                        FarrowingEase.NORMAL -> Blue600
                        FarrowingEase.DIFFICULT, FarrowingEase.ASSISTED -> Red700
                    }
                    Text(it.name, style = MaterialTheme.typography.labelMedium, color = color)
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                StatBadge("Total", f.totalBorn.toString(), MaterialTheme.colorScheme.onSurface)
                StatBadge("Alive", f.bornAlive.toString(), Green600)
                StatBadge("Stillborn", f.stillborn.toString(), if (f.stillborn > 0) Red700 else ColorLow)
                StatBadge("Mummies", f.mummies.toString(), if (f.mummies > 0) Amber700 else ColorLow)
            }
        }
    }
}

@Composable
private fun StatBadge(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = color)
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
    }
}

@Composable
private fun LitterCard(
    lws: LitterWithPiglets,
    isExpanded: Boolean,
    onToggle: () -> Unit,
    onMarkIron: (Long) -> Unit,
    onPigletDied: (Long) -> Unit
) {
    val litter  = lws.litter
    val piglets = lws.piglets
    val alive   = piglets.count { it.status == PigletStatus.ALIVE }
    val dead    = piglets.count { it.status == PigletStatus.DEAD }
    val noIron  = piglets.count { it.ironInjectionDate == null && it.status == PigletStatus.ALIVE }

    Card(
        Modifier.fillMaxWidth(),
        colors    = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment     = Alignment.CenterVertically
            ) {
                Column {
                    Text("Litter #${litter.litterNumber} · Sow ${litter.sowId}", style = MaterialTheme.typography.titleMedium)
                    Text("$alive alive · $dead dead${if (noIron > 0) " · $noIron need iron" else ""}", style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = onToggle) {
                    Icon(if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null)
                }
            }
            if (litter.weaningDate != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    LabeledField("Weaned", litter.weaningDate!!.toDateString())
                    LabeledField("Avg Wean Wt", "%.1f kg".format(litter.weaningWeightAvg))
                    LabeledField("Weaned", litter.pigletsWeaned.toString())
                }
            }
            if (isExpanded && piglets.isNotEmpty()) {
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                piglets.forEach { piglet ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment     = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(piglet.tagNumber.ifBlank { "Piglet #${piglet.id}" }, style = MaterialTheme.typography.bodyMedium)
                            Text(
                                "${piglet.sex?.name ?: "?"} · ${if (piglet.ironInjectionDate != null) "✓ Iron" else "⚠ No iron"}",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (piglet.ironInjectionDate == null && piglet.status == PigletStatus.ALIVE) Amber700 else ColorLow
                            )
                        }
                        Row {
                            if (piglet.ironInjectionDate == null && piglet.status == PigletStatus.ALIVE) {
                                IconButton(onClick = { onMarkIron(piglet.id) }) {
                                    Icon(Icons.Default.Vaccines, null, tint = Amber700, modifier = Modifier.size(20.dp))
                                }
                            }
                            if (piglet.status == PigletStatus.ALIVE) {
                                IconButton(onClick = { onPigletDied(piglet.id) }) {
                                    Icon(Icons.Default.Close, null, tint = Red400, modifier = Modifier.size(20.dp))
                                }
                            } else {
                                Text(piglet.status.name, style = MaterialTheme.typography.labelSmall, color = ColorLow)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PigletActionCard(piglet: PigletEntity, action: String, actionColor: Color, onAction: () -> Unit) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            Modifier.padding(12.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(piglet.tagNumber.ifBlank { "Piglet #${piglet.id}" }, style = MaterialTheme.typography.bodyMedium)
                piglet.birthDate?.let {
                    Text("Born ${it.daysAgo()}d ago · ${piglet.sex?.name ?: "?"}", style = MaterialTheme.typography.bodySmall)
                }
            }
            Button(
                onClick = onAction,
                colors  = ButtonDefaults.buttonColors(containerColor = actionColor)
            ) { Text(action) }
        }
    }
}

@Composable
private fun TopLitterRow(rank: Int, litter: LitterEntity) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = if (rank == 1) Amber100 else MaterialTheme.colorScheme.surface)
    ) {
        Row(Modifier.padding(14.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "#$rank",
                style     = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color     = if (rank == 1) Amber700 else ColorLow,
                modifier  = Modifier.width(36.dp)
            )
            Column(Modifier.weight(1f)) {
                Text("Litter #${litter.litterNumber} · Sow ${litter.sowId}", style = MaterialTheme.typography.titleMedium)
                Text("Weaned: ${litter.pigletsWeaned} · Avg wt: %.1f kg".format(litter.weaningWeightAvg),
                    style = MaterialTheme.typography.bodySmall)
            }
            Text("%.1f kg".format(litter.weaningWeightAvg * litter.pigletsWeaned),
                style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Green600)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddFarrowingDialog(
    sows: List<PigEntity>,
    onDismiss: () -> Unit,
    onSave: (FarrowingEntity) -> Unit
) {
    var selectedSow  by remember { mutableStateOf<Long?>(null) }
    var totalBorn    by remember { mutableStateOf("") }
    var bornAlive    by remember { mutableStateOf("") }
    var stillborn    by remember { mutableStateOf("") }
    var mummies      by remember { mutableStateOf("") }
    var ease         by remember { mutableStateOf(FarrowingEase.NORMAL) }
    var sowExpanded  by remember { mutableStateOf(false) }
    var easeExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Record Farrowing") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                ExposedDropdownMenuBox(expanded = sowExpanded, onExpandedChange = { sowExpanded = it }) {
                    OutlinedTextField(
                        value = sows.find { it.id == selectedSow }?.tagNumber ?: "Select Sow *",
                        onValueChange = {}, readOnly = true, label = { Text("Sow") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(sowExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = sowExpanded, onDismissRequest = { sowExpanded = false }) {
                        sows.forEach { s ->
                            DropdownMenuItem(text = { Text(s.tagNumber) }, onClick = { selectedSow = s.id; sowExpanded = false })
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = totalBorn, onValueChange = { totalBorn = it }, label = { Text("Total Born") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = bornAlive, onValueChange = { bornAlive = it }, label = { Text("Alive") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = stillborn, onValueChange = { stillborn = it }, label = { Text("Stillborn") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = mummies, onValueChange = { mummies = it }, label = { Text("Mummies") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                ExposedDropdownMenuBox(expanded = easeExpanded, onExpandedChange = { easeExpanded = it }) {
                    OutlinedTextField(
                        value = ease.name, onValueChange = {}, readOnly = true, label = { Text("Ease of Farrowing") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(easeExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = easeExpanded, onDismissRequest = { easeExpanded = false }) {
                        FarrowingEase.entries.forEach { e ->
                            DropdownMenuItem(text = { Text(e.name) }, onClick = { ease = e; easeExpanded = false })
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    selectedSow?.let { sowId ->
                        onSave(FarrowingEntity(
                            farmId       = 1L, sowId = sowId,
                            totalBorn    = totalBorn.toIntOrNull() ?: 0,
                            bornAlive    = bornAlive.toIntOrNull() ?: 0,
                            stillborn    = stillborn.toIntOrNull() ?: 0,
                            mummies      = mummies.toIntOrNull() ?: 0,
                            farrowingEase = ease
                        ))
                    }
                },
                enabled = selectedSow != null
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
