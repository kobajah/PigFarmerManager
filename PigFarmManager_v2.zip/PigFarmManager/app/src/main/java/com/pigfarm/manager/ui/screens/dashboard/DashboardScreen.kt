package com.pigfarm.manager.ui.screens.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.pigfarm.manager.ui.components.*
import com.pigfarm.manager.ui.navigation.Screen
import com.pigfarm.manager.ui.theme.*
import com.pigfarm.manager.viewmodel.DashboardViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    navController: NavController,
    vm: DashboardViewModel = hiltViewModel()
) {
    val state      by vm.uiState.collectAsState()
    val lowStock   by vm.lowStockItems.collectAsState()
    val today = SimpleDateFormat("EEE, d MMM yyyy", Locale.getDefault()).format(Date())

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Pig Farm Manager", style = MaterialTheme.typography.titleLarge)
                        Text(today, style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.75f))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                ),
                actions = {
                    BadgedBox(badge = {
                        if (state.unreadAlerts > 0) Badge { Text(state.unreadAlerts.toString()) }
                    }) {
                        IconButton(onClick = { navController.navigate(Screen.Notifications.route) }) {
                            Icon(Icons.Default.Notifications, contentDescription = "Alerts",
                                tint = MaterialTheme.colorScheme.onPrimary)
                        }
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.padding(padding)
        ) {

            // ── KPI Grid ────────────────────────────────
            item {
                SectionHeader("Overview")
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    KpiCard("Active Pigs", state.activePigCount.toString(),
                        Icons.Default.Pets, Green600, modifier = Modifier.weight(1f),
                        onClick = { navController.navigate(Screen.Pigs.route) })
                    KpiCard("Pregnant Sows", state.pregnantSowCount.toString(),
                        Icons.Default.Favorite, ColorUrgent, modifier = Modifier.weight(1f),
                        onClick = { navController.navigate(Screen.Breeding.route) })
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    KpiCard("Farrowings", state.farrowingsCount.toString(),
                        Icons.Default.ChildCare, Blue600, modifier = Modifier.weight(1f),
                        onClick = { navController.navigate(Screen.Farrowing.route) })
                    KpiCard("Mortality", "%.1f%%".format(state.mortalityRate),
                        Icons.Default.TrendingDown,
                        if (state.mortalityRate > 10) Red700 else ColorLow,
                        subtitle = "Avg born alive: %.1f".format(state.avgBornAlive),
                        modifier = Modifier.weight(1f),
                        onClick = { navController.navigate(Screen.Reports.route) })
                }
            }

            // ── Today's Tasks ────────────────────────────
            if (state.todayNotifications.isNotEmpty()) {
                item { SectionHeader("Today's Tasks", "See all") { navController.navigate(Screen.Notifications.route) } }
                items(state.todayNotifications.take(5)) { notif ->
                    AlertBanner(notif, onComplete = { vm.markNotificationCompleted(notif.id) })
                }
            }

            // ── Sows Due for Farrowing ────────────────────
            if (state.sowsDueSoon.isNotEmpty()) {
                item { SectionHeader("🐷 Farrowing Soon", "Breeding") { navController.navigate(Screen.Breeding.route) } }
                items(state.sowsDueSoon) { ps ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors   = CardDefaults.cardColors(containerColor = Red100)
                    ) {
                        Row(
                            Modifier.padding(12.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(ps.sow?.tagNumber ?: "—", style = MaterialTheme.typography.titleMedium)
                                Text(ps.sow?.name ?: "", style = MaterialTheme.typography.bodySmall)
                            }
                            Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                                val days = ps.pregnancy.expectedFarrowingDate?.daysUntil() ?: 0
                                Text(
                                    if (days <= 0) "DUE TODAY" else "In $days days",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (days <= 0) Red700 else Amber700
                                )
                                ps.pregnancy.expectedFarrowingDate?.let {
                                    Text(it.toDateString(), style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            }

            // ── Piglets Needing Iron Injection ──────────
            if (state.pigletsNeedingIron.isNotEmpty()) {
                item {
                    SectionHeader("💉 Iron Injection Due", "${state.pigletsNeedingIron.size} piglets") {
                        navController.navigate(Screen.Farrowing.route)
                    }
                }
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors   = CardDefaults.cardColors(containerColor = Amber100)
                    ) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("${state.pigletsNeedingIron.size} piglets need iron injection",
                                style = MaterialTheme.typography.bodyMedium)
                            Text("Born 3+ days ago — iron injection overdue",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                            TextButton(onClick = { navController.navigate(Screen.Farrowing.route) }) {
                                Text("Manage Litters →")
                            }
                        }
                    }
                }
            }

            // ── Heat Check Due ───────────────────────────
            if (state.sowsDueForHeatCheck.isNotEmpty()) {
                item { SectionHeader("🔁 Return to Heat Check", "${state.sowsDueForHeatCheck.size} sows") }
                items(state.sowsDueForHeatCheck) { breeding ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors   = CardDefaults.cardColors(containerColor = Blue100)
                    ) {
                        Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("Sow #${breeding.sowId}", style = MaterialTheme.typography.titleMedium)
                                Text("Bred: ${breeding.breedingDate.toDateString()}", style = MaterialTheme.typography.bodySmall)
                            }
                            Text(
                                "${breeding.breedingDate.daysAgo()} days since breeding",
                                style = MaterialTheme.typography.bodySmall,
                                color = Blue600
                            )
                        }
                    }
                }
            }

            // ── Low Feed Stock ───────────────────────────
            if (lowStock.isNotEmpty()) {
                item { SectionHeader("⚠️ Low Feed Stock", "Inventory") { navController.navigate(Screen.Feed.route) } }
                items(lowStock) { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors   = CardDefaults.cardColors(containerColor = Red100)
                    ) {
                        Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(item.ingredientName, style = MaterialTheme.typography.bodyMedium)
                            Text("%.1f kg left".format(item.quantityKg),
                                style = MaterialTheme.typography.bodySmall, color = Red700)
                        }
                    }
                }
            }

            // ── Quick Nav Cards ──────────────────────────
            item {
                SectionHeader("Quick Access")
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    QuickNavCard("Health", Icons.Default.LocalHospital, Green200, Modifier.weight(1f)) {
                        navController.navigate(Screen.Health.route)
                    }
                    QuickNavCard("Finance", Icons.Default.AccountBalance, Blue100, Modifier.weight(1f)) {
                        navController.navigate(Screen.Finance.route)
                    }
                    QuickNavCard("Reports", Icons.Default.BarChart, Amber100, Modifier.weight(1f)) {
                        navController.navigate(Screen.Reports.route)
                    }
                }
            }
            item { Spacer(Modifier.height(80.dp)) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun QuickNavCard(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, bg: androidx.compose.ui.graphics.Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier = modifier, shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = bg),
        onClick = onClick) {
        Column(
            Modifier.padding(12.dp).fillMaxWidth(),
            horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(icon, contentDescription = label, modifier = Modifier.size(26.dp), tint = Green800)
            Text(label, style = MaterialTheme.typography.labelLarge)
        }
    }
}
