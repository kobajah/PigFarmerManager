package com.pigfarm.manager.data.local.dao

import androidx.room.*
import com.pigfarm.manager.data.local.entity.*
import kotlinx.coroutines.flow.Flow

// ══════════════════════════════════════════════════════════
//  FARM DAO
// ══════════════════════════════════════════════════════════
@Dao
interface FarmDao {
    @Query("SELECT * FROM farms ORDER BY name")
    fun getAllFarms(): Flow<List<FarmEntity>>

    @Query("SELECT * FROM farms WHERE id = :id")
    suspend fun getFarmById(id: Long): FarmEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFarm(farm: FarmEntity): Long

    @Update
    suspend fun updateFarm(farm: FarmEntity)

    @Delete
    suspend fun deleteFarm(farm: FarmEntity)
}

// ══════════════════════════════════════════════════════════
//  BUILDING + PEN DAOs
// ══════════════════════════════════════════════════════════
@Dao
interface BuildingDao {
    @Query("SELECT * FROM buildings WHERE farmId = :farmId ORDER BY name")
    fun getBuildingsByFarm(farmId: Long): Flow<List<BuildingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(b: BuildingEntity): Long

    @Update  suspend fun update(b: BuildingEntity)
    @Delete  suspend fun delete(b: BuildingEntity)
}

@Dao
interface PenDao {
    @Query("SELECT * FROM pens WHERE farmId = :farmId ORDER BY name")
    fun getPensByFarm(farmId: Long): Flow<List<PenEntity>>

    @Query("SELECT * FROM pens WHERE buildingId = :buildingId ORDER BY name")
    fun getPensByBuilding(buildingId: Long): Flow<List<PenEntity>>

    @Query("SELECT * FROM pens WHERE id = :id")
    suspend fun getPenById(id: Long): PenEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(pen: PenEntity): Long

    @Update  suspend fun update(pen: PenEntity)
    @Delete  suspend fun delete(pen: PenEntity)
}

// ══════════════════════════════════════════════════════════
//  PIG DAO
// ══════════════════════════════════════════════════════════
@Dao
interface PigDao {
    @Query("SELECT * FROM pigs WHERE farmId = :farmId AND status = 'ACTIVE' ORDER BY tagNumber")
    fun getActivePigs(farmId: Long): Flow<List<PigEntity>>

    @Query("SELECT * FROM pigs WHERE farmId = :farmId ORDER BY tagNumber")
    fun getAllPigs(farmId: Long): Flow<List<PigEntity>>

    @Query("SELECT * FROM pigs WHERE farmId = :farmId AND sex IN ('SOW','GILT') AND status = 'ACTIVE' ORDER BY tagNumber")
    fun getActiveFemales(farmId: Long): Flow<List<PigEntity>>

    @Query("SELECT * FROM pigs WHERE farmId = :farmId AND sex = 'BOAR' AND status = 'ACTIVE' ORDER BY tagNumber")
    fun getActiveBoars(farmId: Long): Flow<List<PigEntity>>

    @Query("SELECT * FROM pigs WHERE id = :id")
    suspend fun getPigById(id: Long): PigEntity?

    @Query("SELECT COUNT(*) FROM pigs WHERE farmId = :farmId AND status = 'ACTIVE'")
    fun getActivePigCount(farmId: Long): Flow<Int>

    @Query("SELECT COUNT(*) FROM pigs WHERE farmId = :farmId AND status = 'DECEASED'")
    fun getDeceasedCount(farmId: Long): Flow<Int>

    @Query("SELECT COUNT(*) FROM pigs WHERE farmId = :farmId")
    fun getTotalPigCount(farmId: Long): Flow<Int>

    @Transaction
    @Query("SELECT * FROM pigs WHERE id = :pigId")
    fun getPigWithHealth(pigId: Long): Flow<PigWithHealth>

    @Transaction
    @Query("SELECT * FROM pigs WHERE farmId = :farmId AND status = 'ACTIVE'")
    fun getActivePigsWithPens(farmId: Long): Flow<List<PigWithPen>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(pig: PigEntity): Long

    @Update  suspend fun update(pig: PigEntity)
    @Delete  suspend fun delete(pig: PigEntity)

    @Query("UPDATE pigs SET status = :status, updatedAt = :now WHERE id = :pigId")
    suspend fun updateStatus(pigId: Long, status: PigStatus, now: Long = System.currentTimeMillis())

    @Query("UPDATE pigs SET penId = :penId, updatedAt = :now WHERE id = :pigId")
    suspend fun updatePen(pigId: Long, penId: Long?, now: Long = System.currentTimeMillis())
}

// ══════════════════════════════════════════════════════════
//  HEALTH DAOs
// ══════════════════════════════════════════════════════════
@Dao
interface WeightRecordDao {
    @Query("SELECT * FROM weight_records WHERE pigId = :pigId ORDER BY recordedDate DESC")
    fun getWeightsByPig(pigId: Long): Flow<List<WeightRecordEntity>>

    @Query("SELECT * FROM weight_records WHERE pigId = :pigId ORDER BY recordedDate DESC LIMIT 1")
    suspend fun getLatestWeight(pigId: Long): WeightRecordEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(w: WeightRecordEntity): Long

    @Delete  suspend fun delete(w: WeightRecordEntity)
}

@Dao
interface TreatmentDao {
    @Query("SELECT * FROM treatments WHERE pigId = :pigId ORDER BY treatmentDate DESC")
    fun getTreatmentsByPig(pigId: Long): Flow<List<TreatmentEntity>>

    @Query("SELECT * FROM treatments WHERE farmId = :farmId AND followUpDate IS NOT NULL AND followUpDate <= :threshold ORDER BY followUpDate")
    fun getPendingFollowUps(farmId: Long, threshold: Long): Flow<List<TreatmentEntity>>

    @Query("SELECT * FROM treatments WHERE farmId = :farmId ORDER BY treatmentDate DESC")
    fun getAllTreatments(farmId: Long): Flow<List<TreatmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(t: TreatmentEntity): Long

    @Update  suspend fun update(t: TreatmentEntity)
    @Delete  suspend fun delete(t: TreatmentEntity)
}

@Dao
interface VaccinationDao {
    @Query("SELECT * FROM vaccinations WHERE pigId = :pigId ORDER BY vaccinationDate DESC")
    fun getVaccinationsByPig(pigId: Long): Flow<List<VaccinationEntity>>

    @Query("SELECT * FROM vaccinations WHERE farmId = :farmId AND nextDueDate IS NOT NULL AND nextDueDate <= :threshold ORDER BY nextDueDate")
    fun getUpcomingVaccinations(farmId: Long, threshold: Long): Flow<List<VaccinationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(v: VaccinationEntity): Long

    @Delete  suspend fun delete(v: VaccinationEntity)
}

@Dao
interface DewormingDao {
    @Query("SELECT * FROM deworming WHERE pigId = :pigId ORDER BY dewormingDate DESC")
    fun getDewormingByPig(pigId: Long): Flow<List<DewormingEntity>>

    @Query("SELECT * FROM deworming WHERE farmId = :farmId AND nextDueDate IS NOT NULL AND nextDueDate <= :threshold ORDER BY nextDueDate")
    fun getUpcomingDeworming(farmId: Long, threshold: Long): Flow<List<DewormingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(d: DewormingEntity): Long

    @Delete  suspend fun delete(d: DewormingEntity)
}

@Dao
interface MovementDao {
    @Query("SELECT * FROM movements WHERE pigId = :pigId ORDER BY movementDate DESC")
    fun getMovementsByPig(pigId: Long): Flow<List<MovementEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(m: MovementEntity): Long
}

// ══════════════════════════════════════════════════════════
//  BREEDING DAO
// ══════════════════════════════════════════════════════════
@Dao
interface BreedingDao {
    @Query("SELECT * FROM breedings WHERE farmId = :farmId ORDER BY breedingDate DESC")
    fun getAllBreedings(farmId: Long): Flow<List<BreedingEntity>>

    @Query("SELECT * FROM breedings WHERE sowId = :sowId ORDER BY breedingDate DESC")
    fun getBreedingsBySow(sowId: Long): Flow<List<BreedingEntity>>

    @Query("SELECT * FROM breedings WHERE sowId = :sowId ORDER BY breedingDate DESC LIMIT 1")
    suspend fun getLastBreedingForSow(sowId: Long): BreedingEntity?

    // Sows that were bred 18-24 days ago and have no confirmed pregnancy → check for return to heat
    @Query("""
        SELECT b.* FROM breedings b
        LEFT JOIN pregnancies p ON p.breedingId = b.id AND p.status = 'CONFIRMED'
        WHERE b.farmId = :farmId
          AND p.id IS NULL
          AND b.breedingDate BETWEEN :from AND :to
        ORDER BY b.breedingDate
    """)
    fun getSowsDueForHeatCheck(farmId: Long, from: Long, to: Long): Flow<List<BreedingEntity>>

    @Transaction
    @Query("SELECT * FROM breedings WHERE farmId = :farmId ORDER BY breedingDate DESC")
    fun getBreedingsWithSow(farmId: Long): Flow<List<BreedingWithSow>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(b: BreedingEntity): Long

    @Update  suspend fun update(b: BreedingEntity)
    @Delete  suspend fun delete(b: BreedingEntity)
}

// ══════════════════════════════════════════════════════════
//  PREGNANCY DAO
// ══════════════════════════════════════════════════════════
@Dao
interface PregnancyDao {
    @Query("SELECT * FROM pregnancies WHERE farmId = :farmId ORDER BY expectedFarrowingDate")
    fun getAllPregnancies(farmId: Long): Flow<List<PregnancyEntity>>

    @Query("SELECT * FROM pregnancies WHERE farmId = :farmId AND status = 'CONFIRMED' ORDER BY expectedFarrowingDate")
    fun getConfirmedPregnancies(farmId: Long): Flow<List<PregnancyEntity>>

    @Query("SELECT COUNT(*) FROM pregnancies WHERE farmId = :farmId AND status = 'CONFIRMED'")
    fun getConfirmedPregnancyCount(farmId: Long): Flow<Int>

    // Sows farrowing within next N days
    @Query("""
        SELECT * FROM pregnancies
        WHERE farmId = :farmId
          AND status = 'CONFIRMED'
          AND expectedFarrowingDate BETWEEN :fromMs AND :toMs
        ORDER BY expectedFarrowingDate
    """)
    fun getPregnanciesDueSoon(farmId: Long, fromMs: Long, toMs: Long): Flow<List<PregnancyEntity>>

    @Query("SELECT * FROM pregnancies WHERE sowId = :sowId ORDER BY createdAt DESC LIMIT 1")
    suspend fun getLatestPregnancyForSow(sowId: Long): PregnancyEntity?

    @Transaction
    @Query("SELECT * FROM pregnancies WHERE farmId = :farmId AND status = 'CONFIRMED' ORDER BY expectedFarrowingDate")
    fun getConfirmedPregnanciesWithSow(farmId: Long): Flow<List<PregnancyWithSow>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(p: PregnancyEntity): Long

    @Update  suspend fun update(p: PregnancyEntity)
    @Delete  suspend fun delete(p: PregnancyEntity)
}

// ══════════════════════════════════════════════════════════
//  FARROWING DAO
// ══════════════════════════════════════════════════════════
@Dao
interface FarrowingDao {
    @Query("SELECT * FROM farrowings WHERE farmId = :farmId ORDER BY farrowingDate DESC")
    fun getAllFarrowings(farmId: Long): Flow<List<FarrowingEntity>>

    @Query("SELECT * FROM farrowings WHERE sowId = :sowId ORDER BY farrowingDate DESC")
    fun getFarrowingsBySow(sowId: Long): Flow<List<FarrowingEntity>>

    @Query("SELECT COUNT(*) FROM farrowings WHERE farmId = :farmId")
    fun getFarrowingCount(farmId: Long): Flow<Int>

    @Query("SELECT AVG(bornAlive) FROM farrowings WHERE farmId = :farmId")
    fun getAvgBornAlive(farmId: Long): Flow<Double?>

    @Transaction
    @Query("SELECT * FROM farrowings WHERE farmId = :farmId ORDER BY farrowingDate DESC")
    fun getFarrowingsWithSow(farmId: Long): Flow<List<FarrowingWithSow>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(f: FarrowingEntity): Long

    @Update  suspend fun update(f: FarrowingEntity)
    @Delete  suspend fun delete(f: FarrowingEntity)
}

// ══════════════════════════════════════════════════════════
//  LITTER + PIGLET DAOs
// ══════════════════════════════════════════════════════════
@Dao
interface LitterDao {
    @Query("SELECT * FROM litters WHERE farmId = :farmId ORDER BY createdAt DESC")
    fun getAllLitters(farmId: Long): Flow<List<LitterEntity>>

    @Query("SELECT * FROM litters WHERE farrowingId = :farrowingId")
    suspend fun getLitterByFarrowing(farrowingId: Long): LitterEntity?

    @Transaction
    @Query("SELECT * FROM litters WHERE farmId = :farmId ORDER BY createdAt DESC")
    fun getLittersWithPiglets(farmId: Long): Flow<List<LitterWithPiglets>>

    @Transaction
    @Query("SELECT * FROM litters WHERE id = :litterId")
    fun getLitterDetail(litterId: Long): Flow<LitterWithPiglets>

    // Best performing litters by weaning weight * piglets weaned
    @Query("""
        SELECT * FROM litters
        WHERE farmId = :farmId AND weaningDate IS NOT NULL
        ORDER BY (weaningWeightAvg * pigletsWeaned) DESC
        LIMIT :limit
    """)
    fun getTopPerformingLitters(farmId: Long, limit: Int = 10): Flow<List<LitterEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(l: LitterEntity): Long

    @Update  suspend fun update(l: LitterEntity)
    @Delete  suspend fun delete(l: LitterEntity)
}

@Dao
interface PigletDao {
    @Query("SELECT * FROM piglets WHERE litterId = :litterId ORDER BY tagNumber")
    fun getPigletsByLitter(litterId: Long): Flow<List<PigletEntity>>

    @Query("SELECT COUNT(*) FROM piglets WHERE litterId = :litterId AND status = 'ALIVE'")
    fun getAliveCountByLitter(litterId: Long): Flow<Int>

    @Query("SELECT COUNT(*) FROM piglets WHERE litterId = :litterId AND status = 'DEAD'")
    fun getDeadCountByLitter(litterId: Long): Flow<Int>

    // Piglets that need iron injection (born >3 days ago, no injection yet)
    @Query("""
        SELECT * FROM piglets
        WHERE farmId = :farmId
          AND status = 'ALIVE'
          AND ironInjectionDate IS NULL
          AND birthDate IS NOT NULL
          AND birthDate <= :threeDaysAgoMs
    """)
    fun getPigletsNeedingIronInjection(farmId: Long, threeDaysAgoMs: Long): Flow<List<PigletEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(p: PigletEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(piglets: List<PigletEntity>)

    @Update  suspend fun update(p: PigletEntity)
    @Delete  suspend fun delete(p: PigletEntity)

    @Query("UPDATE piglets SET ironInjectionDate = :date WHERE id = :pigletId")
    suspend fun markIronInjection(pigletId: Long, date: Long)

    @Query("UPDATE piglets SET castrationDate = :date WHERE id = :pigletId")
    suspend fun markCastration(pigletId: Long, date: Long)

    @Query("UPDATE piglets SET status = :status, deathDate = :deathDate, deathCause = :cause WHERE id = :pigletId")
    suspend fun markDeath(pigletId: Long, status: PigletStatus, deathDate: Long, cause: String)
}

// ══════════════════════════════════════════════════════════
//  FEED DAOs
// ══════════════════════════════════════════════════════════
@Dao
interface FeedFormulaDao {
    @Query("SELECT * FROM feed_formulas WHERE farmId = :farmId AND isActive = 1 ORDER BY name")
    fun getActiveFormulas(farmId: Long): Flow<List<FeedFormulaEntity>>

    @Query("SELECT * FROM feed_formulas WHERE farmId = :farmId ORDER BY name")
    fun getAllFormulas(farmId: Long): Flow<List<FeedFormulaEntity>>

    @Transaction
    @Query("SELECT * FROM feed_formulas WHERE id = :formulaId")
    fun getFormulaWithIngredients(formulaId: Long): Flow<FormulaWithIngredients>

    @Transaction
    @Query("SELECT * FROM feed_formulas WHERE farmId = :farmId AND isActive = 1")
    fun getActiveFormulasWithIngredients(farmId: Long): Flow<List<FormulaWithIngredients>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(f: FeedFormulaEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIngredients(ingredients: List<FormulaIngredientEntity>)

    @Update  suspend fun update(f: FeedFormulaEntity)
    @Delete  suspend fun delete(f: FeedFormulaEntity)

    @Query("DELETE FROM formula_ingredients WHERE formulaId = :formulaId")
    suspend fun deleteIngredientsByFormula(formulaId: Long)
}

@Dao
interface FeedInventoryDao {
    @Query("SELECT * FROM feed_inventory WHERE farmId = :farmId ORDER BY ingredientName")
    fun getInventory(farmId: Long): Flow<List<FeedInventoryEntity>>

    // Items below reorder level
    @Query("SELECT * FROM feed_inventory WHERE farmId = :farmId AND reorderLevelKg > 0 AND quantityKg <= reorderLevelKg")
    fun getLowStockItems(farmId: Long): Flow<List<FeedInventoryEntity>>

    @Query("SELECT SUM(quantityKg * unitCost) FROM feed_inventory WHERE farmId = :farmId")
    fun getTotalInventoryValue(farmId: Long): Flow<Double?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(i: FeedInventoryEntity): Long

    @Update  suspend fun update(i: FeedInventoryEntity)
    @Delete  suspend fun delete(i: FeedInventoryEntity)

    @Query("UPDATE feed_inventory SET quantityKg = quantityKg + :amount, updatedAt = :now WHERE id = :id")
    suspend fun addStock(id: Long, amount: Double, now: Long = System.currentTimeMillis())

    @Query("UPDATE feed_inventory SET quantityKg = quantityKg - :amount, updatedAt = :now WHERE id = :id")
    suspend fun removeStock(id: Long, amount: Double, now: Long = System.currentTimeMillis())
}

@Dao
interface FeedingPlanDao {
    @Query("SELECT * FROM feeding_plans WHERE farmId = :farmId AND isActive = 1")
    fun getActivePlans(farmId: Long): Flow<List<FeedingPlanEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(p: FeedingPlanEntity): Long

    @Update  suspend fun update(p: FeedingPlanEntity)
    @Delete  suspend fun delete(p: FeedingPlanEntity)
}

@Dao
interface FeedConsumptionDao {
    @Query("SELECT * FROM feed_consumption WHERE farmId = :farmId ORDER BY consumptionDate DESC")
    fun getAllConsumption(farmId: Long): Flow<List<FeedConsumptionEntity>>

    @Query("SELECT * FROM feed_consumption WHERE farmId = :farmId AND consumptionDate >= :fromMs ORDER BY consumptionDate DESC")
    fun getConsumptionSince(farmId: Long, fromMs: Long): Flow<List<FeedConsumptionEntity>>

    @Query("SELECT SUM(amountKg) FROM feed_consumption WHERE farmId = :farmId AND consumptionDate BETWEEN :from AND :to")
    fun getTotalConsumption(farmId: Long, from: Long, to: Long): Flow<Double?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(c: FeedConsumptionEntity): Long

    @Delete  suspend fun delete(c: FeedConsumptionEntity)
}

// ══════════════════════════════════════════════════════════
//  FINANCE DAOs
// ══════════════════════════════════════════════════════════
@Dao
interface SaleDao {
    @Query("SELECT * FROM sales WHERE farmId = :farmId ORDER BY saleDate DESC")
    fun getAllSales(farmId: Long): Flow<List<SaleEntity>>

    @Query("SELECT * FROM sales WHERE farmId = :farmId AND saleDate >= :fromMs ORDER BY saleDate DESC")
    fun getSalesSince(farmId: Long, fromMs: Long): Flow<List<SaleEntity>>

    @Query("SELECT SUM(totalAmount) FROM sales WHERE farmId = :farmId AND saleDate BETWEEN :from AND :to")
    fun getTotalRevenue(farmId: Long, from: Long, to: Long): Flow<Double?>

    @Query("SELECT SUM(totalAmount) FROM sales WHERE farmId = :farmId AND pigId = :pigId")
    suspend fun getRevenueByPig(farmId: Long, pigId: Long): Double?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(s: SaleEntity): Long

    @Update  suspend fun update(s: SaleEntity)
    @Delete  suspend fun delete(s: SaleEntity)
}

@Dao
interface ExpenseDao {
    @Query("SELECT * FROM expenses WHERE farmId = :farmId ORDER BY expenseDate DESC")
    fun getAllExpenses(farmId: Long): Flow<List<ExpenseEntity>>

    @Query("SELECT * FROM expenses WHERE farmId = :farmId AND expenseDate >= :fromMs ORDER BY expenseDate DESC")
    fun getExpensesSince(farmId: Long, fromMs: Long): Flow<List<ExpenseEntity>>

    @Query("SELECT SUM(amount) FROM expenses WHERE farmId = :farmId AND expenseDate BETWEEN :from AND :to")
    fun getTotalExpenses(farmId: Long, from: Long, to: Long): Flow<Double?>

    @Query("SELECT category, SUM(amount) as total FROM expenses WHERE farmId = :farmId AND expenseDate BETWEEN :from AND :to GROUP BY category")
    fun getExpensesByCategory(farmId: Long, from: Long, to: Long): Flow<List<CategoryTotal>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(e: ExpenseEntity): Long

    @Update  suspend fun update(e: ExpenseEntity)
    @Delete  suspend fun delete(e: ExpenseEntity)
}

data class CategoryTotal(val category: String, val total: Double)

// ══════════════════════════════════════════════════════════
//  NOTIFICATION DAO
// ══════════════════════════════════════════════════════════
@Dao
interface NotificationDao {
    @Query("SELECT * FROM farm_notifications WHERE farmId = :farmId ORDER BY dueDate, priority DESC")
    fun getAllNotifications(farmId: Long): Flow<List<FarmNotificationEntity>>

    @Query("SELECT * FROM farm_notifications WHERE farmId = :farmId AND isRead = 0 ORDER BY dueDate")
    fun getUnreadNotifications(farmId: Long): Flow<List<FarmNotificationEntity>>

    @Query("SELECT COUNT(*) FROM farm_notifications WHERE farmId = :farmId AND isRead = 0 AND isCompleted = 0")
    fun getUnreadCount(farmId: Long): Flow<Int>

    @Query("SELECT * FROM farm_notifications WHERE farmId = :farmId AND dueDate <= :todayMs AND isCompleted = 0 ORDER BY priority DESC, dueDate")
    fun getDueToday(farmId: Long, todayMs: Long): Flow<List<FarmNotificationEntity>>

    @Query("SELECT * FROM farm_notifications WHERE farmId = :farmId AND priority IN ('HIGH','URGENT') AND isCompleted = 0 ORDER BY dueDate")
    fun getUrgentNotifications(farmId: Long): Flow<List<FarmNotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(n: FarmNotificationEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(notifications: List<FarmNotificationEntity>)

    @Query("UPDATE farm_notifications SET isRead = 1 WHERE id = :id")
    suspend fun markRead(id: Long)

    @Query("UPDATE farm_notifications SET isRead = 1 WHERE farmId = :farmId")
    suspend fun markAllRead(farmId: Long)

    @Query("UPDATE farm_notifications SET isCompleted = 1, completedAt = :now WHERE id = :id")
    suspend fun markCompleted(id: Long, now: Long = System.currentTimeMillis())

    @Delete  suspend fun delete(n: FarmNotificationEntity)

    @Query("DELETE FROM farm_notifications WHERE farmId = :farmId AND isCompleted = 1")
    suspend fun deleteCompleted(farmId: Long)
}
