package com.pigfarm.manager.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pigfarm.manager.data.local.entity.*
import com.pigfarm.manager.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

// ── Date helpers ──────────────────────────────────────────
fun Long.toDateString(pattern: String = "dd/MM/yyyy"): String =
    SimpleDateFormat(pattern, Locale.getDefault()).format(Date(this))

fun Long.daysUntil(): Long =
    (this - System.currentTimeMillis()) / 86_400_000L

fun Long.daysAgo(): Long =
    (System.currentTimeMillis() - this) / 86_400_000L

// ── KPI Card ──────────────────────────────────────────────
@Composable
fun KpiCard(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    subtitle: String = "",
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    Card(
        modifier = modifier
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        shape    = RoundedCornerShape(16.dp),
        colors   = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    Modifier
                        .size(40.dp)
                        .background(color.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(22.dp))
                }
                Text(title, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
            }
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = color)
            if (subtitle.isNotBlank())
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
        }
    }
}

// ── Alert Banner ──────────────────────────────────────────
@Composable
fun AlertBanner(notification: FarmNotificationEntity, onComplete: () -> Unit) {
    val (bgColor, iconColor, icon) = when (notification.priority) {
        NotificationPriority.URGENT -> Triple(Red100, Red700, Icons.Default.Warning)
        NotificationPriority.HIGH   -> Triple(Amber100, Amber700, Icons.Default.Notifications)
        NotificationPriority.MEDIUM -> Triple(Blue100, Blue600, Icons.Default.Info)
        else                        -> Triple(Color(0xFFF5F5F5), ColorLow, Icons.Default.NotificationsNone)
    }
    Row(
        Modifier
            .fillMaxWidth()
            .background(bgColor, RoundedCornerShape(12.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(20.dp))
        Column(Modifier.weight(1f)) {
            Text(notification.title, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, color = iconColor)
            if (notification.message.isNotBlank())
                Text(notification.message, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text("Due: ${notification.dueDate.toDateString()}", style = MaterialTheme.typography.bodySmall, color = iconColor.copy(alpha = 0.7f))
        }
        IconButton(onClick = onComplete, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.CheckCircle, contentDescription = "Complete", tint = ColorSuccess, modifier = Modifier.size(20.dp))
        }
    }
}

// ── Pig Tag Chip ──────────────────────────────────────────
@Composable
fun PigChip(tag: String, sex: PigSex, status: PigStatus = PigStatus.ACTIVE, onClick: () -> Unit = {}) {
    val sexColor = when (sex) {
        PigSex.SOW, PigSex.GILT -> Color(0xFFE91E63)
        PigSex.BOAR              -> Blue600
        PigSex.BARROW            -> Brown700
    }
    AssistChip(
        onClick = onClick,
        label   = { Text(tag, style = MaterialTheme.typography.bodySmall) },
        leadingIcon = {
            Box(Modifier.size(8.dp).background(sexColor, CircleShape))
        },
        colors = AssistChipDefaults.assistChipColors(
            containerColor = if (status == PigStatus.ACTIVE) sexColor.copy(alpha = 0.1f) else Color(0xFFEEEEEE)
        )
    )
}

// ── Section Header ────────────────────────────────────────
@Composable
fun SectionHeader(title: String, actionLabel: String = "", onAction: () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (actionLabel.isNotBlank())
            TextButton(onClick = onAction) { Text(actionLabel, style = MaterialTheme.typography.labelLarge) }
    }
}

// ── Empty State ───────────────────────────────────────────
@Composable
fun EmptyState(message: String, icon: ImageVector = Icons.Default.Inventory2) {
    Column(
        Modifier.fillMaxWidth().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(64.dp),
            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.25f))
        Text(message, style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
    }
}

// ── Labeled Field ─────────────────────────────────────────
@Composable
fun LabeledField(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}

// ── Priority Badge ────────────────────────────────────────
@Composable
fun PriorityBadge(priority: NotificationPriority) {
    val (color, label) = when (priority) {
        NotificationPriority.URGENT -> Pair(Red700, "URGENT")
        NotificationPriority.HIGH   -> Pair(Amber700, "HIGH")
        NotificationPriority.MEDIUM -> Pair(Blue600, "MEDIUM")
        NotificationPriority.LOW    -> Pair(ColorLow, "LOW")
    }
    Box(
        Modifier.background(color.copy(alpha = 0.15f), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = color, fontWeight = FontWeight.Bold)
    }
}

// ── Progress Row ──────────────────────────────────────────
@Composable
fun ProgressRow(label: String, value: Float, valueLabel: String, color: Color = Green600) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodySmall)
            Text(valueLabel, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, color = color)
        }
        LinearProgressIndicator(
            progress = { value.coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(6.dp),
            color    = color,
            trackColor = color.copy(alpha = 0.2f)
        )
    }
}

// ── FAB with label ────────────────────────────────────────
@Composable
fun PrimaryFab(label: String, icon: ImageVector = Icons.Default.Add, onClick: () -> Unit) {
    ExtendedFloatingActionButton(
        onClick = onClick,
        icon    = { Icon(icon, contentDescription = null) },
        text    = { Text(label) },
        containerColor = MaterialTheme.colorScheme.primary,
        contentColor   = MaterialTheme.colorScheme.onPrimary
    )
}

// ── Number picker row ─────────────────────────────────────
@Composable
fun NumberField(label: String, value: Int, onValueChange: (Int) -> Unit) {
    OutlinedTextField(
        value         = if (value == 0) "" else value.toString(),
        onValueChange = { onValueChange(it.toIntOrNull() ?: 0) },
        label         = { Text(label) },
        singleLine    = true,
        modifier      = Modifier.fillMaxWidth()
    )
}

// ── Notification type icon ────────────────────────────────
fun notificationIcon(type: NotificationType): ImageVector = when (type) {
    NotificationType.IRON_INJECTION    -> Icons.Default.Healing
    NotificationType.CASTRATION        -> Icons.Default.ContentCut
    NotificationType.REPEAT_BREEDING   -> Icons.Default.Repeat
    NotificationType.FARROWING_DUE     -> Icons.Default.ChildCare
    NotificationType.VACCINATION_DUE   -> Icons.Default.Vaccines
    NotificationType.DEWORMING_DUE     -> Icons.Default.Medication
    NotificationType.WEANING_DUE       -> Icons.Default.FamilyRestroom
    NotificationType.TREATMENT_FOLLOWUP -> Icons.Default.MonitorHeart
    NotificationType.PREGNANCY_CHECK   -> Icons.Default.Search
    NotificationType.HEAT_DETECTION    -> Icons.Default.Thermostat
    NotificationType.LOW_FEED_STOCK    -> Icons.Default.Inventory
    NotificationType.SALE_REMINDER     -> Icons.Default.AttachMoney
}
