package com.pigfarm.manager.ui.screens.pigs

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.pigfarm.manager.data.local.entity.*
import com.pigfarm.manager.ui.components.*
import com.pigfarm.manager.ui.theme.*
import com.pigfarm.manager.viewmodel.PigsViewModel

// ══════════════════════════════════════════════════════════
//  PIGS LIST SCREEN
// ══════════════════════════════════════════════════════════
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PigsScreen(
    navController: NavController,
    vm: PigsViewModel = hiltViewModel()
) {
    val pigs        by vm.pigs.collectAsState()
    val searchQuery by vm.searchQuery.collectAsState()
    val filterSex   by vm.filterSex.collectAsState()
    val pens        by vm.pens.collectAsState()
    val buildings   by vm.buildings.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var showInfraDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Pigs (${pigs.size})") },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary),
                actions = {
                    IconButton(onClick = { showInfraDialog = true }) {
                        Icon(Icons.Default.Business, contentDescription = "Buildings", tint = MaterialTheme.colorScheme.onPrimary)
                    }
                }
            )
        },
        floatingActionButton = {
            PrimaryFab("Add Pig", Icons.Default.Add) { showAddDialog = true }
        }
    ) { padding ->
        Column(Modifier.padding(padding)) {
            // Search bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = vm::setSearchQuery,
                placeholder   = { Text("Search by tag or name…") },
                leadingIcon   = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier      = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                singleLine    = true,
                shape         = RoundedCornerShape(12.dp)
            )
            // Sex filter chips
            LazyRow(
                contentPadding  = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(selected = filterSex == null, onClick = { vm.setFilterSex(null) }, label = { Text("All") })
                }
                items(PigSex.entries) { sex ->
                    FilterChip(
                        selected = filterSex == sex,
                        onClick  = { vm.setFilterSex(if (filterSex == sex) null else sex) },
                        label    = { Text(sex.name) }
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
            if (pigs.isEmpty()) {
                EmptyState("No pigs found. Add your first pig!", Icons.Default.Pets)
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(pigs, key = { it.pig.id }) { pwp ->
                        PigListItem(pwp) {
                            navController.navigate("pigs/${pwp.pig.id}")
                        }
                    }
                    item { Spacer(Modifier.height(80.dp)) }
                }
            }
        }
    }

    if (showAddDialog) {
        AddPigDialog(pens = pens, onDismiss = { showAddDialog = false }) { pig ->
            vm.addPig(pig)
            showAddDialog = false
        }
    }
    if (showInfraDialog) {
        AddInfraDialog(buildings, pens,
            onAddBuilding = vm::addBuilding,
            onAddPen      = vm::addPen,
            onDismiss     = { showInfraDialog = false }
        )
    }
}

@Composable
private fun PigListItem(pwp: PigWithPen, onClick: () -> Unit) {
    val pig = pwp.pig
    val sexColor = when (pig.sex) {
        PigSex.SOW, PigSex.GILT -> Color(0xFFE91E63)
        PigSex.BOAR              -> Blue600
        PigSex.BARROW            -> Brown700
    }
    Card(
        onClick  = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors   = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            // Sex indicator strip
            Box(Modifier.width(5.dp).height(52.dp).background(sexColor, RoundedCornerShape(4.dp)))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(pig.tagNumber, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    if (pig.name.isNotBlank())
                        Text("· ${pig.name}", style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(pig.sex.name, style = MaterialTheme.typography.bodySmall, color = sexColor)
                    if (pig.breed.isNotBlank()) Text("• ${pig.breed}", style = MaterialTheme.typography.bodySmall)
                    pwp.pen?.let { Text("• ${it.name}", style = MaterialTheme.typography.bodySmall) }
                }
                pig.birthDate?.let {
                    Text("Born: ${it.toDateString()}", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f))
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                val statusColor = if (pig.status == PigStatus.ACTIVE) ColorSuccess else ColorLow
                Text(pig.status.name, style = MaterialTheme.typography.labelSmall, color = statusColor)
            }
        }
    }
}

// ══════════════════════════════════════════════════════════
//  ADD PIG DIALOG
// ══════════════════════════════════════════════════════════
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddPigDialog(pens: List<PenEntity>, onDismiss: () -> Unit, onSave: (PigEntity) -> Unit) {
    var tag     by remember { mutableStateOf("") }
    var name    by remember { mutableStateOf("") }
    var breed   by remember { mutableStateOf("") }
    var sex     by remember { mutableStateOf(PigSex.SOW) }
    var penId   by remember { mutableStateOf<Long?>(null) }
    var sexExpanded by remember { mutableStateOf(false) }
    var penExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add New Pig") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = tag, onValueChange = { tag = it }, label = { Text("Tag Number *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = breed, onValueChange = { breed = it }, label = { Text("Breed") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                // Sex dropdown
                ExposedDropdownMenuBox(expanded = sexExpanded, onExpandedChange = { sexExpanded = it }) {
                    OutlinedTextField(
                        value = sex.name, onValueChange = {}, readOnly = true,
                        label = { Text("Sex") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = sexExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = sexExpanded, onDismissRequest = { sexExpanded = false }) {
                        PigSex.entries.forEach { s ->
                            DropdownMenuItem(text = { Text(s.name) }, onClick = { sex = s; sexExpanded = false })
                        }
                    }
                }
                // Pen dropdown
                if (pens.isNotEmpty()) {
                    ExposedDropdownMenuBox(expanded = penExpanded, onExpandedChange = { penExpanded = it }) {
                        OutlinedTextField(
                            value = pens.find { it.id == penId }?.name ?: "No pen",
                            onValueChange = {}, readOnly = true,
                            label = { Text("Pen") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = penExpanded) },
                            modifier = Modifier.menuAnchor().fillMaxWidth()
                        )
                        ExposedDropdownMenu(expanded = penExpanded, onDismissRequest = { penExpanded = false }) {
                            DropdownMenuItem(text = { Text("No pen") }, onClick = { penId = null; penExpanded = false })
                            pens.forEach { pen ->
                                DropdownMenuItem(text = { Text(pen.name) }, onClick = { penId = pen.id; penExpanded = false })
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (tag.isNotBlank()) onSave(PigEntity(farmId = 1L, tagNumber = tag, name = name, sex = sex, breed = breed, penId = penId))
                },
                enabled = tag.isNotBlank()
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ══════════════════════════════════════════════════════════
//  ADD INFRASTRUCTURE DIALOG
// ══════════════════════════════════════════════════════════
@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun AddInfraDialog(
    buildings: List<BuildingEntity>,
    pens: List<PenEntity>,
    onAddBuilding: (BuildingEntity) -> Unit,
    onAddPen: (PenEntity) -> Unit,
    onDismiss: () -> Unit
) {
    var tab       by remember { mutableIntStateOf(0) }
    var bName     by remember { mutableStateOf("") }
    var bType     by remember { mutableStateOf("") }
    var pName     by remember { mutableStateOf("") }
    var pCap      by remember { mutableStateOf("") }
    var selectedB by remember { mutableStateOf<Long?>(null) }
    var bExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Farm Infrastructure") },
        text = {
            Column {
                TabRow(selectedTabIndex = tab) {
                    Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Building") })
                    Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Pen") })
                }
                Spacer(Modifier.height(12.dp))
                when (tab) {
                    0 -> {
                        OutlinedTextField(value = bName, onValueChange = { bName = it }, label = { Text("Building Name") }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = bType, onValueChange = { bType = it }, label = { Text("Type (Farrowing / Nursery…)") }, modifier = Modifier.fillMaxWidth())
                    }
                    1 -> {
                        ExposedDropdownMenuBox(expanded = bExpanded, onExpandedChange = { bExpanded = it }) {
                            OutlinedTextField(
                                value = buildings.find { it.id == selectedB }?.name ?: "Select Building",
                                onValueChange = {}, readOnly = true,
                                label = { Text("Building") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(bExpanded) },
                                modifier = Modifier.menuAnchor().fillMaxWidth()
                            )
                            ExposedDropdownMenu(expanded = bExpanded, onDismissRequest = { bExpanded = false }) {
                                buildings.forEach { b ->
                                    DropdownMenuItem(text = { Text(b.name) }, onClick = { selectedB = b.id; bExpanded = false })
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = pName, onValueChange = { pName = it }, label = { Text("Pen Name") }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = pCap, onValueChange = { pCap = it }, label = { Text("Capacity") }, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when (tab) {
                    0 -> if (bName.isNotBlank()) { onAddBuilding(BuildingEntity(farmId = 1L, name = bName, type = bType)); onDismiss() }
                    1 -> if (pName.isNotBlank() && selectedB != null) { onAddPen(PenEntity(farmId = 1L, buildingId = selectedB!!, name = pName, capacity = pCap.toIntOrNull() ?: 0)); onDismiss() }
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ══════════════════════════════════════════════════════════
//  PIG DETAIL SCREEN
// ══════════════════════════════════════════════════════════
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PigDetailScreen(
    pigId: Long,
    navController: NavController,
    vm: PigsViewModel = hiltViewModel()
) {
    val detail by vm.getPigDetail(pigId).collectAsState(initial = null)
    val pig    = detail?.pig
    var selectedTab by remember { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(pig?.tagNumber ?: "Pig Detail") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, "Back", tint = MaterialTheme.colorScheme.onPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { padding ->
        if (pig == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }
        Column(Modifier.padding(padding)) {
            // Header card
            Card(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                colors   = CardDefaults.cardColors(containerColor = Green50)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(pig.tagNumber, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            if (pig.name.isNotBlank()) Text(pig.name, style = MaterialTheme.typography.bodyMedium)
                        }
                        PigChip(pig.sex.name, pig.sex, pig.status)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                        LabeledField("Breed", pig.breed.ifBlank { "Unknown" })
                        pig.birthDate?.let { LabeledField("Born", it.toDateString()) }
                        LabeledField("Status", pig.status.name)
                    }
                }
            }

            // Tabs
            TabRow(selectedTabIndex = selectedTab) {
                listOf("Weights", "Health", "History").forEachIndexed { i, title ->
                    Tab(selected = selectedTab == i, onClick = { selectedTab = i }, text = { Text(title) })
                }
            }

            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                when (selectedTab) {
                    0 -> {
                        if (detail?.weights.isNullOrEmpty()) {
                            item { EmptyState("No weight records yet") }
                        } else {
                            items(detail!!.weights) { w ->
                                Row(
                                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(w.recordedDate.toDateString(), style = MaterialTheme.typography.bodyMedium)
                                    Text("%.1f kg".format(w.weightKg), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = Green600)
                                }
                                HorizontalDivider()
                            }
                        }
                    }
                    1 -> {
                        item { SectionHeader("Treatments") }
                        if (detail?.treatments.isNullOrEmpty()) {
                            item { Text("No treatments", style = MaterialTheme.typography.bodySmall) }
                        } else {
                            items(detail!!.treatments) { t ->
                                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                                    Column(Modifier.padding(12.dp)) {
                                        Text(t.medicine, style = MaterialTheme.typography.titleMedium)
                                        Text("${t.treatmentDate.toDateString()} • ${t.diagnosis}", style = MaterialTheme.typography.bodySmall)
                                        if (t.dose.isNotBlank()) Text("Dose: ${t.dose}", style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                        item { SectionHeader("Vaccinations") }
                        if (detail?.vaccinations.isNullOrEmpty()) {
                            item { Text("No vaccinations", style = MaterialTheme.typography.bodySmall) }
                        } else {
                            items(detail!!.vaccinations) { v ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(v.vaccineName, style = MaterialTheme.typography.bodyMedium)
                                    Text(v.vaccinationDate.toDateString(), style = MaterialTheme.typography.bodySmall)
                                }
                                HorizontalDivider()
                            }
                        }
                    }
                    2 -> {
                        item { Text("Movements and transfers will appear here.", style = MaterialTheme.typography.bodySmall) }
                    }
                }
                item { Spacer(Modifier.height(80.dp)) }
            }
        }
    }
}


