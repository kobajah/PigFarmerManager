package com.pigfarm.manager.di

import android.content.Context
import androidx.work.WorkManager
import com.pigfarm.manager.data.local.AppDatabase
import com.pigfarm.manager.data.repository.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Singleton @Provides
    fun provideDatabase(@ApplicationContext ctx: Context): AppDatabase =
        AppDatabase.getInstance(ctx)

    @Singleton @Provides fun provideFarmDao(db: AppDatabase)            = db.farmDao()
    @Singleton @Provides fun provideBuildingDao(db: AppDatabase)        = db.buildingDao()
    @Singleton @Provides fun providePenDao(db: AppDatabase)             = db.penDao()
    @Singleton @Provides fun providePigDao(db: AppDatabase)             = db.pigDao()
    @Singleton @Provides fun provideWeightDao(db: AppDatabase)          = db.weightRecordDao()
    @Singleton @Provides fun provideTreatmentDao(db: AppDatabase)       = db.treatmentDao()
    @Singleton @Provides fun provideVaccinationDao(db: AppDatabase)     = db.vaccinationDao()
    @Singleton @Provides fun provideDewormingDao(db: AppDatabase)       = db.dewormingDao()
    @Singleton @Provides fun provideMovementDao(db: AppDatabase)        = db.movementDao()
    @Singleton @Provides fun provideBreedingDao(db: AppDatabase)        = db.breedingDao()
    @Singleton @Provides fun providePregnancyDao(db: AppDatabase)       = db.pregnancyDao()
    @Singleton @Provides fun provideFarrowingDao(db: AppDatabase)       = db.farrowingDao()
    @Singleton @Provides fun provideLitterDao(db: AppDatabase)          = db.litterDao()
    @Singleton @Provides fun providePigletDao(db: AppDatabase)          = db.pigletDao()
    @Singleton @Provides fun provideFeedFormulaDao(db: AppDatabase)     = db.feedFormulaDao()
    @Singleton @Provides fun provideFeedInventoryDao(db: AppDatabase)   = db.feedInventoryDao()
    @Singleton @Provides fun provideFeedingPlanDao(db: AppDatabase)     = db.feedingPlanDao()
    @Singleton @Provides fun provideFeedConsumptionDao(db: AppDatabase) = db.feedConsumptionDao()
    @Singleton @Provides fun provideSaleDao(db: AppDatabase)            = db.saleDao()
    @Singleton @Provides fun provideExpenseDao(db: AppDatabase)         = db.expenseDao()
    @Singleton @Provides fun provideNotificationDao(db: AppDatabase)    = db.notificationDao()

    @Singleton @Provides
    fun providePigRepository(db: AppDatabase)          = PigRepository(db)

    @Singleton @Provides
    fun provideBreedingRepository(db: AppDatabase)     = BreedingRepository(db)

    @Singleton @Provides
    fun provideFeedRepository(db: AppDatabase)         = FeedRepository(db)

    @Singleton @Provides
    fun provideHealthRepository(db: AppDatabase)       = HealthRepository(db)

    @Singleton @Provides
    fun provideFinanceRepository(db: AppDatabase)      = FinanceRepository(db)

    @Singleton @Provides
    fun provideNotificationRepository(db: AppDatabase) = NotificationRepository(db)

    @Singleton @Provides
    fun provideWorkManager(@ApplicationContext ctx: Context): WorkManager =
        WorkManager.getInstance(ctx)
}
