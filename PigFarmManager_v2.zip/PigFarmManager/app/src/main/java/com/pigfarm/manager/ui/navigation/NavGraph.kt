package com.pigfarm.manager.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.*
import androidx.navigation.compose.*
import com.pigfarm.manager.ui.screens.dashboard.DashboardScreen
import com.pigfarm.manager.ui.screens.pigs.PigsScreen
import com.pigfarm.manager.ui.screens.pigs.PigDetailScreen
import com.pigfarm.manager.ui.screens.breeding.BreedingScreen
import com.pigfarm.manager.ui.screens.farrowing.FarrowingScreen
import com.pigfarm.manager.ui.screens.feed.FeedScreen
import com.pigfarm.manager.ui.screens.health.HealthScreen
import com.pigfarm.manager.ui.screens.finance.FinanceScreen
import com.pigfarm.manager.ui.screens.reports.ReportsScreen
import com.pigfarm.manager.ui.screens.notifications.NotificationsScreen

sealed class Screen(val route: String, val label: String, val icon: ImageVector) {
    object Dashboard     : Screen("dashboard",     "Dashboard",    Icons.Default.Dashboard)
    object Pigs          : Screen("pigs",          "Pigs",         Icons.Default.Pets)
    object PigDetail     : Screen("pigs/{pigId}",  "Pig Detail",   Icons.Default.Pets)
    object Breeding      : Screen("breeding",      "Breeding",     Icons.Default.Favorite)
    object Farrowing     : Screen("farrowing",     "Farrowing",    Icons.Default.ChildCare)
    object Feed          : Screen("feed",          "Feed",         Icons.Default.Grass)
    object Health        : Screen("health",        "Health",       Icons.Default.LocalHospital)
    object Finance       : Screen("finance",       "Finance",      Icons.Default.AccountBalance)
    object Reports       : Screen("reports",       "Reports",      Icons.Default.BarChart)
    object Notifications : Screen("notifications", "Alerts",       Icons.Default.Notifications)
}

val bottomNavItems = listOf(
    Screen.Dashboard, Screen.Pigs, Screen.Breeding, Screen.Feed, Screen.Finance
)

@Composable
fun PigFarmNavGraph(
    navController: NavHostController,
    unreadCount: Int
) {
    NavHost(navController = navController, startDestination = Screen.Dashboard.route) {
        composable(Screen.Dashboard.route)     { DashboardScreen(navController) }
        composable(Screen.Pigs.route)          { PigsScreen(navController) }
        composable(
            Screen.PigDetail.route,
            arguments = listOf(navArgument("pigId") { type = NavType.LongType })
        ) { back ->
            PigDetailScreen(pigId = back.arguments?.getLong("pigId") ?: 0L, navController = navController)
        }
        composable(Screen.Breeding.route)      { BreedingScreen(navController) }
        composable(Screen.Farrowing.route)     { FarrowingScreen(navController) }
        composable(Screen.Feed.route)          { FeedScreen(navController) }
        composable(Screen.Health.route)        { HealthScreen(navController) }
        composable(Screen.Finance.route)       { FinanceScreen(navController) }
        composable(Screen.Reports.route)       { ReportsScreen(navController) }
        composable(Screen.Notifications.route) { NotificationsScreen(navController) }
    }
}

@Composable
fun PigFarmBottomBar(navController: NavController, unreadCount: Int) {
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route

    NavigationBar {
        bottomNavItems.forEach { screen ->
            val selected = currentRoute == screen.route
            NavigationBarItem(
                selected = selected,
                onClick  = {
                    navController.navigate(screen.route) {
                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                        launchSingleTop = true
                        restoreState    = true
                    }
                },
                icon = {
                    BadgedBox(badge = {
                        if (screen is Screen.Notifications && unreadCount > 0)
                            Badge { Text(if (unreadCount > 99) "99+" else unreadCount.toString()) }
                    }) {
                        Icon(screen.icon, contentDescription = screen.label)
                    }
                },
                label = { Text(screen.label) }
            )
        }
    }
}
