package com.pigfarm.manager.ui.screens.reports

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.pigfarm.manager.data.local.entity.LitterEntity
import com.pigfarm.manager.ui.components.*
import com.pigfarm.manager.ui.theme.*
import com.pigfarm.manager.viewmodel.ReportsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    navController: NavController,
    vm: ReportsViewModel = hiltViewModel()
) {
    val mortalityRate   by vm.mortalityRate.collectAsState()
    val avgBornAlive    by vm.avgBornAlive.collectAsState()
    val topLitters      by vm.topLitters.collectAsState()
    val forecast        by vm.monthlyForecast.collectAsState()
    val revenue         by vm.totalRevenue.collectAsState()
    val totalExpenses   by vm.totalExpenses.collectAsState()
    val netProfit       by vm.netProfit.collectAsState()
    val activePigs      by vm.activePigCount.collectAsState()
    val totalConsumption by vm.totalConsumption.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title  = { Text("Reports & Analytics") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor    = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { padding ->
        LazyColumn(
            contentPadding      = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier            = Modifier.padding(padding)
        ) {
            // ── 1. Mortality Rate ─────────────────────
            item {
                ReportCard(
                    title    = "Mortality Rate",
                    subtitle = "Total livestock loss indicator",
                    icon     = Icons.Default.TrendingDown,
                    iconColor = if (mortalityRate > 10) Red700 else Green600
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("%.2f%%".format(mortalityRate),
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold,
                                color = when {
                                    mortalityRate > 15 -> Red700
                                    mortalityRate > 8  -> Amber700
                                    else               -> Green600
                                })
                            Text(
                                when {
                                    mortalityRate > 15 -> "⚠️ High — investigate causes"
                                    mortalityRate > 8  -> "⚡ Above average — monitor"
                                    else               -> "✓ Good — within normal range"
                                },
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        MortalityGauge(mortalityRate.toFloat(), modifier = Modifier.size(80.dp))
                    }
                    Spacer(Modifier.height(8.dp))
                    ProgressRow("Target: <5%",  (mortalityRate / 20.0).toFloat().coerceIn(0f, 1f), "%.1f%%".format(mortalityRate),
                        if (mortalityRate < 5) Green600 else Red700)
                }
            }

            // ── 2. Reproductive Performance ───────────
            item {
                ReportCard(
                    title     = "Reproductive Performance",
                    subtitle  = "30-day rolling average",
                    icon      = Icons.Default.ChildCare,
                    iconColor = Blue600
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("%.1f".format(avgBornAlive ?: 0.0),
                                style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Blue600)
                            Text("Avg Born Alive", style = MaterialTheme.typography.bodySmall)
                        }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            ProgressRow("Born alive (target 11)", ((avgBornAlive ?: 0.0) / 14.0).toFloat().coerceIn(0f, 1f),
                                "%.1f".format(avgBornAlive ?: 0.0), Blue600)
                        }
                    }
                }
            }

            // ── 3. Financial Summary (30 days) ────────
            item {
                ReportCard(
                    title     = "Financial Summary (30 days)",
                    subtitle  = "Revenue vs Expenses",
                    icon      = Icons.Default.AccountBalance,
                    iconColor = if (netProfit >= 0) Green600 else Red700
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        FinanceStat("Revenue",  revenue ?: 0.0, Green600)
                        FinanceStat("Expenses", totalExpenses ?: 0.0, Red700)
                        FinanceStat("Net",      netProfit, if (netProfit >= 0) Green600 else Red700)
                    }
                    Spacer(Modifier.height(8.dp))
                    if ((revenue ?: 0.0) > 0) {
                        val margin = netProfit / (revenue ?: 1.0)
                        ProgressRow(
                            label      = "Profit margin",
                            value      = margin.toFloat().coerceIn(0f, 1f),
                            valueLabel = "%.1f%%".format(margin * 100),
                            color      = if (margin >= 0) Green600 else Red700
                        )
                    }
                    if (activePigs > 0 && (revenue ?: 0.0) > 0) {
                        Spacer(Modifier.height(4.dp))
                        Text("Revenue per active pig: %.2f".format((revenue ?: 0.0) / activePigs),
                            style = MaterialTheme.typography.bodySmall, color = Green600)
                    }
                }
            }

            // ── 4. Feed Efficiency ────────────────────
            item {
                ReportCard(
                    title     = "Feed Usage (30 days)",
                    subtitle  = "Total consumption vs active herd",
                    icon      = Icons.Default.Grass,
                    iconColor = Green600
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("%.0f kg".format(totalConsumption ?: 0.0),
                                style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Green600)
                            Text("Total consumed (30d)", style = MaterialTheme.typography.bodySmall)
                        }
                        if (activePigs > 0) {
                            Column(horizontalAlignment = Alignment.End) {
                                Text("%.1f kg/pig".format((totalConsumption ?: 0.0) / activePigs),
                                    style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Amber700)
                                Text("Per active pig/month", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    SectionHeader("Next Month Forecast")
                    forecast.forEach { (group, kg) ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(group.name, style = MaterialTheme.typography.bodySmall)
                            Text("%.0f kg".format(kg), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                        }
                    }
                    if (forecast.isNotEmpty()) {
                        HorizontalDivider(Modifier.padding(vertical = 4.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total forecast", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                            Text("%.0f kg".format(forecast.sumOf { it.second }),
                                style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Green800)
                        }
                    }
                }
            }

            // ── 5. Top Performing Litters ─────────────
            item {
                ReportCard(
                    title     = "Top Performing Litters",
                    subtitle  = "Ranked by total weaning weight",
                    icon      = Icons.Default.EmojiEvents,
                    iconColor = Amber700
                ) {
                    if (topLitters.isEmpty()) {
                        Text("No weaned litters yet", style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                    } else {
                        topLitters.take(5).forEachIndexed { i, litter ->
                            LitterRankRow(rank = i + 1, litter = litter)
                            if (i < topLitters.size - 1) HorizontalDivider(Modifier.padding(vertical = 4.dp))
                        }
                    }
                }
            }

            // ── 6. Profitability per pig ──────────────
            item {
                ReportCard(
                    title     = "Herd Profitability",
                    subtitle  = "Which animals are generating value",
                    icon      = Icons.Default.MonetizationOn,
                    iconColor = Green600
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            KpiMini("Active pigs",  activePigs.toString(),  Blue600,  Modifier.weight(1f))
                            KpiMini("Rev/pig",      if (activePigs > 0) "%.0f".format((revenue ?: 0.0) / activePigs) else "—", Green600, Modifier.weight(1f))
                            KpiMini("Cost/pig",     if (activePigs > 0) "%.0f".format((totalExpenses ?: 0.0) / activePigs) else "—", Red700, Modifier.weight(1f))
                        }
                        if (activePigs > 0 && (revenue ?: 0.0) > 0) {
                            val profitPerPig = netProfit / activePigs
                            Card(
                                Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (profitPerPig >= 0) Green50 else Red100
                                )
                            ) {
                                Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(if (profitPerPig >= 0) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                                        null, tint = if (profitPerPig >= 0) Green600 else Red700)
                                    Text("%.2f net profit per active pig this month".format(profitPerPig),
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = if (profitPerPig >= 0) Green800 else Red700)
                                }
                            }
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(32.dp)) }
        }
    }
}

// ── Sub-composables ───────────────────────────────────────
@Composable
private fun ReportCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        Modifier.fillMaxWidth(),
        colors    = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    Modifier.size(36.dp)
                        .background(iconColor.copy(alpha = 0.12f), androidx.compose.foundation.shape.CircleShape),
                    contentAlignment = Alignment.Center
                ) { Icon(icon, null, tint = iconColor, modifier = Modifier.size(20.dp)) }
                Column {
                    Text(title,    style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(subtitle, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
                }
            }
            content()
        }
    }
}

@Composable
private fun FinanceStat(label: String, value: Double, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("%.0f".format(value), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = color)
        Text(label, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun LitterRankRow(rank: Int, litter: LitterEntity) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("#$rank", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold,
            color = when (rank) { 1 -> Amber700; 2 -> Color(0xFF9E9E9E); 3 -> Brown700; else -> ColorLow },
            modifier = Modifier.width(24.dp))
        Column(Modifier.weight(1f)) {
            Text("Litter #${litter.litterNumber} · Sow ${litter.sowId}", style = MaterialTheme.typography.bodyMedium)
            Text("${litter.pigletsWeaned} weaned · %.1f kg avg".format(litter.weaningWeightAvg), style = MaterialTheme.typography.bodySmall)
        }
        Text("%.0f kg".format(litter.weaningWeightAvg * litter.pigletsWeaned),
            style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = Green600)
    }
}

@Composable
private fun KpiMini(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.08f))) {
        Column(Modifier.padding(10.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = color)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
        }
    }
}

// ── Donut-style mortality gauge ───────────────────────────
@Composable
private fun MortalityGauge(pct: Float, modifier: Modifier = Modifier) {
    val safeColor    = Green600
    val warningColor = Amber700
    val dangerColor  = Red700
    val gaugeColor   = when {
        pct > 15 -> dangerColor
        pct > 8  -> warningColor
        else     -> safeColor
    }
    Canvas(modifier) {
        val stroke     = 10.dp.toPx()
        val sweepAngle = (pct / 100f).coerceIn(0f, 1f) * 360f
        drawArc(color = Color.LightGray, startAngle = -90f, sweepAngle = 360f, useCenter = false,
            style = Stroke(stroke), size = Size(size.width - stroke, size.height - stroke),
            topLeft = Offset(stroke / 2, stroke / 2))
        drawArc(color = gaugeColor, startAngle = -90f, sweepAngle = sweepAngle, useCenter = false,
            style = Stroke(stroke), size = Size(size.width - stroke, size.height - stroke),
            topLeft = Offset(stroke / 2, stroke / 2))
    }
}


