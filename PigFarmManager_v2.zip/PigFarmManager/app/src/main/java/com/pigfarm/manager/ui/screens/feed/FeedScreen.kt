package com.pigfarm.manager.ui.screens.feed

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.pigfarm.manager.data.local.entity.*
import com.pigfarm.manager.ui.components.*
import com.pigfarm.manager.ui.theme.*
import com.pigfarm.manager.viewmodel.FeedViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FeedScreen(
    navController: NavController,
    vm: FeedViewModel = hiltViewModel()
) {
    val formulas       by vm.formulasWithIngredients.collectAsState()
    val inventory      by vm.inventory.collectAsState()
    val lowStock       by vm.lowStockItems.collectAsState()
    val plans          by vm.activePlans.collectAsState()
    val consumption    by vm.allConsumption.collectAsState()
    val forecast       by vm.monthlyForecast.collectAsState()
    val invValue       by vm.totalInventoryValue.collectAsState()

    var selectedTab     by remember { mutableIntStateOf(0) }
    var showAddFormula  by remember { mutableStateOf(false) }
    var showAddInventory by remember { mutableStateOf(false) }
    var showLogConsumption by remember { mutableStateOf(false) }
    var showAddPlan     by remember { mutableStateOf(false) }
    var expandedFormula by remember { mutableStateOf<Long?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title  = { Text("Feed Management") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor    = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        floatingActionButton = {
            when (selectedTab) {
                0 -> PrimaryFab("Add Formula",   Icons.Default.Science)    { showAddFormula = true }
                1 -> PrimaryFab("Add Item",      Icons.Default.AddBox)     { showAddInventory = true }
                2 -> PrimaryFab("Log Feeding",   Icons.Default.Edit)       { showLogConsumption = true }
                3 -> PrimaryFab("Add Plan",      Icons.Default.PlaylistAdd){ showAddPlan = true }
                else -> {}
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding)) {

            // Inventory value banner
            Card(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                colors = CardDefaults.cardColors(containerColor = Green50)
            ) {
                Row(
                    Modifier.padding(12.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(inventory.size.toString(), style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold, color = Green600)
                        Text("Ingredients", style = MaterialTheme.typography.bodySmall)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(lowStock.size.toString(), style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold, color = if (lowStock.isEmpty()) Green600 else Red700)
                        Text("Low Stock", style = MaterialTheme.typography.bodySmall)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("%.0f".format(invValue ?: 0.0), style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold, color = Blue600)
                        Text("Inv. Value", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            TabRow(selectedTabIndex = selectedTab) {
                listOf("Formulas", "Inventory", "Consumption", "Plans", "Forecast").forEachIndexed { i, t ->
                    Tab(selected = selectedTab == i, onClick = { selectedTab = i },
                        text = { Text(t, style = MaterialTheme.typography.labelSmall) })
                }
            }

            LazyColumn(
                contentPadding     = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                when (selectedTab) {

                    // ── Formulas ──────────────────────────
                    0 -> {
                        if (formulas.isEmpty()) {
                            item { EmptyState("No feed formulas. Add your first formula!", Icons.Default.Science) }
                        } else {
                            items(formulas, key = { it.formula.id }) { fwi ->
                                FormulaCard(
                                    fwi        = fwi,
                                    isExpanded = expandedFormula == fwi.formula.id,
                                    onToggle   = { expandedFormula = if (expandedFormula == fwi.formula.id) null else fwi.formula.id }
                                )
                            }
                        }
                    }

                    // ── Inventory ─────────────────────────
                    1 -> {
                        if (lowStock.isNotEmpty()) {
                            item {
                                Card(
                                    Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = Red100)
                                ) {
                                    Column(Modifier.padding(12.dp)) {
                                        Text("⚠️ ${lowStock.size} item(s) below reorder level",
                                            style = MaterialTheme.typography.titleMedium, color = Red700)
                                        lowStock.forEach { item ->
                                            Text("• ${item.ingredientName}: %.1f kg (min %.1f kg)".format(
                                                item.quantityKg, item.reorderLevelKg),
                                                style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                }
                            }
                        }
                        if (inventory.isEmpty()) {
                            item { EmptyState("No inventory items yet") }
                        } else {
                            items(inventory, key = { it.id }) { item ->
                                InventoryItemCard(
                                    item      = item,
                                    onAddStock = { kg -> vm.addStock(item.id, kg) },
                                    onRemoveStock = { kg -> vm.removeStock(item.id, kg) }
                                )
                            }
                        }
                    }

                    // ── Consumption ───────────────────────
                    2 -> {
                        if (consumption.isEmpty()) {
                            item { EmptyState("No consumption records yet") }
                        } else {
                            items(consumption.take(50), key = { it.id }) { c ->
                                Row(
                                    Modifier.fillMaxWidth().padding(vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(c.targetGroup.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                        Text(c.consumptionDate.toDateString(), style = MaterialTheme.typography.bodySmall)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("%.1f kg".format(c.amountKg),
                                            style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = Green600)
                                        if (c.pigCount > 0)
                                            Text("${c.pigCount} pigs", style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                                HorizontalDivider()
                            }
                        }
                    }

                    // ── Feeding Plans ─────────────────────
                    3 -> {
                        if (plans.isEmpty()) {
                            item { EmptyState("No feeding plans configured", Icons.Default.PlaylistAdd) }
                        } else {
                            items(plans, key = { it.id }) { plan ->
                                FeedingPlanCard(plan)
                            }
                        }
                    }

                    // ── Monthly Forecast ──────────────────
                    4 -> {
                        item {
                            Card(
                                Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Blue100)
                            ) {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("Next Month Feed Forecast", style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold, color = Blue600)
                                    Text("Based on active feeding plans × 30 days",
                                        style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                        if (forecast.isEmpty()) {
                            item { EmptyState("Set up feeding plans to see forecast") }
                        } else {
                            val total = forecast.sumOf { it.second }
                            items(forecast) { (group, kg) ->
                                Card(
                                    Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                ) {
                                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(group.name, style = MaterialTheme.typography.titleMedium)
                                            Text("%.1f kg".format(kg),
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold, color = Green600)
                                        }
                                        ProgressRow(
                                            label      = "Share of total",
                                            value      = if (total > 0) (kg / total).toFloat() else 0f,
                                            valueLabel = "%.0f%%".format(if (total > 0) kg / total * 100 else 0.0),
                                            color      = Green600
                                        )
                                    }
                                }
                            }
                            item {
                                HorizontalDivider(Modifier.padding(vertical = 4.dp))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("TOTAL", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Text("%.1f kg".format(total),
                                        style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Green800)
                                }
                            }
                        }
                    }
                }
                item { Spacer(Modifier.height(80.dp)) }
            }
        }
    }

    if (showAddFormula)      AddFormulaDialog(onDismiss = { showAddFormula = false }, onSave = { f, i -> vm.saveFormula(f, i); showAddFormula = false })
    if (showAddInventory)    AddInventoryDialog(onDismiss = { showAddInventory = false }, onSave = { vm.addInventoryItem(it); showAddInventory = false })
    if (showLogConsumption)  LogConsumptionDialog(onDismiss = { showLogConsumption = false }, onSave = { vm.logConsumption(it); showLogConsumption = false })
    if (showAddPlan)         AddFeedingPlanDialog(onDismiss = { showAddPlan = false }, onSave = { vm.saveFeedingPlan(it); showAddPlan = false })
}

// ── Formula card with expandable ingredient list ──────────
@Composable
private fun FormulaCard(fwi: FormulaWithIngredients, isExpanded: Boolean, onToggle: () -> Unit) {
    val f = fwi.formula
    Card(
        Modifier.fillMaxWidth(),
        colors    = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment     = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(f.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(f.targetGroup.name, style = MaterialTheme.typography.bodySmall, color = Green600)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("%.2f/kg".format(f.totalCostPerKg), style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold, color = Amber700)
                    IconButton(onClick = onToggle) {
                        Icon(if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null)
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                if (f.crudeProtein > 0) LabeledField("CP", "%.1f%%".format(f.crudeProtein))
                if (f.energyMj > 0)    LabeledField("DE", "%.1f MJ".format(f.energyMj))
                if (f.lysinePct > 0)   LabeledField("Lysine", "%.2f%%".format(f.lysinePct))
            }
            if (isExpanded && fwi.ingredients.isNotEmpty()) {
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                Text("Ingredients", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                Spacer(Modifier.height(4.dp))
                fwi.ingredients.forEach { ing ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(ing.ingredientName, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                        Text("%.1f%%".format(ing.percentage),
                            style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
}

// ── Inventory item card with stock adjustment ─────────────
@Composable
private fun InventoryItemCard(item: FeedInventoryEntity, onAddStock: (Double) -> Unit, onRemoveStock: (Double) -> Unit) {
    var showAdjust by remember { mutableStateOf(false) }
    val isLow = item.reorderLevelKg > 0 && item.quantityKg <= item.reorderLevelKg

    Card(
        Modifier.fillMaxWidth(),
        colors    = CardDefaults.cardColors(containerColor = if (isLow) Red100 else MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(Modifier.padding(14.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(item.ingredientName, style = MaterialTheme.typography.titleMedium)
                Text(
                    "%.1f kg in stock".format(item.quantityKg) +
                            if (item.reorderLevelKg > 0) " (min %.0f kg)".format(item.reorderLevelKg) else "",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isLow) Red700 else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
                if (item.supplier.isNotBlank())
                    Text("Supplier: ${item.supplier}", style = MaterialTheme.typography.bodySmall)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("%.2f/kg".format(item.unitCost), style = MaterialTheme.typography.bodySmall, color = Amber700)
                IconButton(onClick = { showAdjust = true }) {
                    Icon(Icons.Default.Tune, "Adjust", modifier = Modifier.size(20.dp))
                }
            }
        }
    }

    if (showAdjust) {
        StockAdjustDialog(
            item      = item,
            onAdd     = { kg -> onAddStock(kg); showAdjust = false },
            onRemove  = { kg -> onRemoveStock(kg); showAdjust = false },
            onDismiss = { showAdjust = false }
        )
    }
}

@Composable
private fun StockAdjustDialog(item: FeedInventoryEntity, onAdd: (Double) -> Unit, onRemove: (Double) -> Unit, onDismiss: () -> Unit) {
    var amount by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Adjust Stock: ${item.ingredientName}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Current stock: %.1f kg".format(item.quantityKg), style = MaterialTheme.typography.bodyMedium)
                OutlinedTextField(value = amount, onValueChange = { amount = it },
                    label = { Text("Amount (kg)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { amount.toDoubleOrNull()?.let { onRemove(it) } }) { Text("Remove", color = Red700) }
                TextButton(onClick = { amount.toDoubleOrNull()?.let { onAdd(it) } }) { Text("Add Stock") }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun FeedingPlanCard(plan: FeedingPlanEntity) {
    Card(
        Modifier.fillMaxWidth(),
        colors    = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(Modifier.padding(14.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(plan.targetGroup.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("${plan.feedingFrequency}x per day", style = MaterialTheme.typography.bodySmall)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("%.2f kg/head/day".format(plan.dailyAmountKg),
                    style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = Green600)
                Text("%.0f kg/month".format(plan.dailyAmountKg * 30), style = MaterialTheme.typography.bodySmall, color = Amber700)
            }
        }
    }
}

// ── Dialogs ──────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddFormulaDialog(onDismiss: () -> Unit, onSave: (FeedFormulaEntity, List<FormulaIngredientEntity>) -> Unit) {
    var name         by remember { mutableStateOf("") }
    var group        by remember { mutableStateOf(TargetGroup.GESTATION) }
    var cpText       by remember { mutableStateOf("") }
    var deText       by remember { mutableStateOf("") }
    var groupExpanded by remember { mutableStateOf(false) }

    // Simplified: 5 ingredient slots
    val ingredients = remember { mutableStateListOf("", "", "", "", "") }
    val percents    = remember { mutableStateListOf("", "", "", "", "") }
    val costs       = remember { mutableStateListOf("", "", "", "", "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Feed Formula") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.heightIn(max = 400.dp)) {
                item {
                    OutlinedTextField(value = name, onValueChange = { name = it },
                        label = { Text("Formula Name *") }, modifier = Modifier.fillMaxWidth())
                }
                item {
                    ExposedDropdownMenuBox(expanded = groupExpanded, onExpandedChange = { groupExpanded = it }) {
                        OutlinedTextField(value = group.name, onValueChange = {}, readOnly = true,
                            label = { Text("Target Group") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(groupExpanded) },
                            modifier = Modifier.menuAnchor().fillMaxWidth())
                        ExposedDropdownMenu(expanded = groupExpanded, onDismissRequest = { groupExpanded = false }) {
                            TargetGroup.entries.forEach { g ->
                                DropdownMenuItem(text = { Text(g.name) }, onClick = { group = g; groupExpanded = false })
                            }
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = cpText, onValueChange = { cpText = it },
                            label = { Text("CP %") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(value = deText, onValueChange = { deText = it },
                            label = { Text("DE MJ/kg") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                }
                item { Text("Ingredients", style = MaterialTheme.typography.labelLarge) }
                items(5) { i ->
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        OutlinedTextField(value = ingredients[i], onValueChange = { ingredients[i] = it },
                            label = { Text("Name") }, modifier = Modifier.weight(2f), singleLine = true)
                        OutlinedTextField(value = percents[i], onValueChange = { percents[i] = it },
                            label = { Text("%") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(value = costs[i], onValueChange = { costs[i] = it },
                            label = { Text("Cost") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank(),
                onClick = {
                    val ingList = (0..4).mapNotNull { i ->
                        val n = ingredients[i].trim()
                        val p = percents[i].toDoubleOrNull() ?: 0.0
                        if (n.isNotBlank() && p > 0)
                            FormulaIngredientEntity(formulaId = 0, ingredientName = n, percentage = p, costPerKg = costs[i].toDoubleOrNull() ?: 0.0)
                        else null
                    }
                    val totalCost = ingList.sumOf { it.percentage / 100.0 * it.costPerKg }
                    onSave(
                        FeedFormulaEntity(farmId = 1L, name = name, targetGroup = group,
                            crudeProtein = cpText.toDoubleOrNull() ?: 0.0,
                            energyMj = deText.toDoubleOrNull() ?: 0.0,
                            totalCostPerKg = totalCost),
                        ingList
                    )
                }
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun AddInventoryDialog(onDismiss: () -> Unit, onSave: (FeedInventoryEntity) -> Unit) {
    var name     by remember { mutableStateOf("") }
    var qty      by remember { mutableStateOf("") }
    var cost     by remember { mutableStateOf("") }
    var supplier by remember { mutableStateOf("") }
    var reorder  by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Inventory Item") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Ingredient Name *") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = qty, onValueChange = { qty = it }, label = { Text("Qty (kg)") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = cost, onValueChange = { cost = it }, label = { Text("Cost/kg") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                OutlinedTextField(value = supplier, onValueChange = { supplier = it }, label = { Text("Supplier") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(value = reorder, onValueChange = { reorder = it }, label = { Text("Reorder level (kg)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = {
                onSave(FeedInventoryEntity(farmId = 1L, ingredientName = name,
                    quantityKg = qty.toDoubleOrNull() ?: 0.0,
                    unitCost = cost.toDoubleOrNull() ?: 0.0,
                    supplier = supplier, reorderLevelKg = reorder.toDoubleOrNull() ?: 0.0))
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LogConsumptionDialog(onDismiss: () -> Unit, onSave: (FeedConsumptionEntity) -> Unit) {
    var group        by remember { mutableStateOf(TargetGroup.GESTATION) }
    var amount       by remember { mutableStateOf("") }
    var pigCount     by remember { mutableStateOf("") }
    var groupExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Log Feed Consumption") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ExposedDropdownMenuBox(expanded = groupExpanded, onExpandedChange = { groupExpanded = it }) {
                    OutlinedTextField(value = group.name, onValueChange = {}, readOnly = true,
                        label = { Text("Group") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(groupExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = groupExpanded, onDismissRequest = { groupExpanded = false }) {
                        TargetGroup.entries.forEach { g ->
                            DropdownMenuItem(text = { Text(g.name) }, onClick = { group = g; groupExpanded = false })
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = amount, onValueChange = { amount = it },
                        label = { Text("Amount (kg) *") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = pigCount, onValueChange = { pigCount = it },
                        label = { Text("# Pigs") }, modifier = Modifier.weight(1f), singleLine = true)
                }
            }
        },
        confirmButton = {
            TextButton(enabled = amount.isNotBlank(), onClick = {
                onSave(FeedConsumptionEntity(farmId = 1L, targetGroup = group,
                    amountKg = amount.toDoubleOrNull() ?: 0.0,
                    pigCount = pigCount.toIntOrNull() ?: 0))
            }) { Text("Log") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddFeedingPlanDialog(onDismiss: () -> Unit, onSave: (FeedingPlanEntity) -> Unit) {
    var group        by remember { mutableStateOf(TargetGroup.GESTATION) }
    var daily        by remember { mutableStateOf("") }
    var freq         by remember { mutableStateOf("2") }
    var groupExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Feeding Plan") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ExposedDropdownMenuBox(expanded = groupExpanded, onExpandedChange = { groupExpanded = it }) {
                    OutlinedTextField(value = group.name, onValueChange = {}, readOnly = true,
                        label = { Text("Target Group") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(groupExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = groupExpanded, onDismissRequest = { groupExpanded = false }) {
                        TargetGroup.entries.forEach { g ->
                            DropdownMenuItem(text = { Text(g.name) }, onClick = { group = g; groupExpanded = false })
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = daily, onValueChange = { daily = it },
                        label = { Text("kg/head/day *") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = freq, onValueChange = { freq = it },
                        label = { Text("Feedings/day") }, modifier = Modifier.weight(1f), singleLine = true)
                }
            }
        },
        confirmButton = {
            TextButton(enabled = daily.isNotBlank(), onClick = {
                onSave(FeedingPlanEntity(farmId = 1L, targetGroup = group,
                    dailyAmountKg = daily.toDoubleOrNull() ?: 0.0,
                    feedingFrequency = freq.toIntOrNull() ?: 2))
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
