package com.pigfarm.manager.viewmodel

import androidx.lifecycle.*
import com.pigfarm.manager.data.local.entity.*
import com.pigfarm.manager.data.repository.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

// ── Shared farm-id state (single farm for now) ───────────
private const val DEFAULT_FARM_ID = 1L

// ══════════════════════════════════════════════════════════
//  DASHBOARD VIEW MODEL
// ══════════════════════════════════════════════════════════
data class DashboardUiState(
    val activePigCount: Int       = 0,
    val pregnantSowCount: Int     = 0,
    val farrowingsCount: Int      = 0,
    val unreadAlerts: Int         = 0,
    val mortalityRate: Double     = 0.0,
    val avgBornAlive: Double      = 0.0,
    val todayNotifications: List<FarmNotificationEntity> = emptyList(),
    val sowsDueSoon: List<PregnancyWithSow>              = emptyList(),
    val pigletsNeedingIron: List<PigletEntity>           = emptyList(),
    val sowsDueForHeatCheck: List<BreedingEntity>        = emptyList(),
    val lowStockItems: List<FeedInventoryEntity>         = emptyList()
)

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val pigRepo:          PigRepository,
    private val breedingRepo:     BreedingRepository,
    private val feedRepo:         FeedRepository,
    private val notificationRepo: NotificationRepository
) : ViewModel() {

    private val farmId = DEFAULT_FARM_ID

    val uiState: StateFlow<DashboardUiState> = combine(
        pigRepo.getActivePigCount(farmId),
        breedingRepo.getConfirmedPregnancyCount(farmId),
        breedingRepo.getFarrowingCount(farmId),
        notificationRepo.getUnreadCount(farmId),
        pigRepo.getMortalityRate(farmId),
        breedingRepo.getAvgBornAlive(farmId),
        notificationRepo.getDueToday(farmId),
        breedingRepo.getSowsDueSoon(farmId, daysAhead = 7),
        breedingRepo.getPigletsNeedingIron(farmId),
        breedingRepo.getSowsDueForHeatCheck(farmId)
    ) { arr ->
        DashboardUiState(
            activePigCount       = arr[0] as Int,
            pregnantSowCount     = arr[1] as Int,
            farrowingsCount      = arr[2] as Int,
            unreadAlerts         = arr[3] as Int,
            mortalityRate        = arr[4] as Double,
            avgBornAlive         = (arr[5] as Double?) ?: 0.0,
            todayNotifications   = (arr[6] as List<*>).filterIsInstance<FarmNotificationEntity>(),
            sowsDueSoon          = (arr[7] as List<*>).filterIsInstance<PregnancyWithSow>(),
            pigletsNeedingIron   = (arr[8] as List<*>).filterIsInstance<PigletEntity>(),
            sowsDueForHeatCheck  = (arr[9] as List<*>).filterIsInstance<BreedingEntity>()
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DashboardUiState())

    val lowStockItems = feedRepo.getLowStockItems(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun markNotificationCompleted(id: Long) = viewModelScope.launch {
        notificationRepo.markCompleted(id)
    }
}

// ══════════════════════════════════════════════════════════
//  PIGS VIEW MODEL
// ══════════════════════════════════════════════════════════
@HiltViewModel
class PigsViewModel @Inject constructor(
    private val pigRepo: PigRepository
) : ViewModel() {

    private val farmId = DEFAULT_FARM_ID

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    private val _filterSex = MutableStateFlow<PigSex?>(null)
    val filterSex: StateFlow<PigSex?> = _filterSex

    @OptIn(ExperimentalCoroutinesApi::class)
    val pigs: StateFlow<List<PigWithPen>> = combine(_searchQuery, _filterSex) { q, sex -> Pair(q, sex) }
        .flatMapLatest { (query, sex) ->
            pigRepo.getActivePigsWithPens(farmId).map { list ->
                list.filter { pwp ->
                    val matchQ = query.isBlank() || pwp.pig.tagNumber.contains(query, true) || pwp.pig.name.contains(query, true)
                    val matchS = sex == null || pwp.pig.sex == sex
                    matchQ && matchS
                }
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val pens = pigRepo.getPensByFarm(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val buildings = pigRepo.getBuildingsByFarm(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun setSearchQuery(q: String)  { _searchQuery.value = q }
    fun setFilterSex(sex: PigSex?) { _filterSex.value = sex }

    fun addPig(pig: PigEntity)     = viewModelScope.launch { pigRepo.addPig(pig) }
    fun updatePig(pig: PigEntity)  = viewModelScope.launch { pigRepo.updatePig(pig) }
    fun sellPig(pigId: Long)       = viewModelScope.launch { pigRepo.updateStatus(pigId, PigStatus.SOLD) }
    fun markDeceased(pigId: Long)  = viewModelScope.launch { pigRepo.updateStatus(pigId, PigStatus.DECEASED) }
    fun addWeightRecord(w: WeightRecordEntity) = viewModelScope.launch { pigRepo.addWeightRecord(w) }
    fun addBuilding(b: BuildingEntity) = viewModelScope.launch { pigRepo.addBuilding(b) }
    fun addPen(p: PenEntity)       = viewModelScope.launch { pigRepo.addPen(p) }

    fun getPigDetail(pigId: Long)  = pigRepo.getPigWithHealth(pigId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
}

// ══════════════════════════════════════════════════════════
//  BREEDING VIEW MODEL
// ══════════════════════════════════════════════════════════
@HiltViewModel
class BreedingViewModel @Inject constructor(
    private val breedingRepo: BreedingRepository,
    private val pigRepo:      PigRepository
) : ViewModel() {

    private val farmId = DEFAULT_FARM_ID

    val breedingsWithSow = breedingRepo.getBreedingsWithSow(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val confirmedPregnancies = breedingRepo.getConfirmedPregnanciesWithSow(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val sowsDueSoon = breedingRepo.getSowsDueSoon(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val heatCheckDue = breedingRepo.getSowsDueForHeatCheck(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val activeSows = pigRepo.getActiveFemales(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val activeBoars = pigRepo.getActiveBoars(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun addBreeding(b: BreedingEntity) = viewModelScope.launch { breedingRepo.addBreeding(b) }

    fun confirmPregnancy(p: PregnancyEntity, confirmedBy: String) = viewModelScope.launch {
        breedingRepo.updatePregnancyStatus(p.copy(status = PregnancyStatus.CONFIRMED, confirmedBy = confirmedBy))
    }

    fun markOpen(p: PregnancyEntity) = viewModelScope.launch {
        breedingRepo.updatePregnancyStatus(p.copy(status = PregnancyStatus.OPEN))
    }
}

// ══════════════════════════════════════════════════════════
//  FARROWING VIEW MODEL
// ══════════════════════════════════════════════════════════
@HiltViewModel
class FarrowingViewModel @Inject constructor(
    private val breedingRepo: BreedingRepository,
    private val pigRepo:      PigRepository
) : ViewModel() {

    private val farmId = DEFAULT_FARM_ID

    val farrowingsWithSow = breedingRepo.getFarrowingsWithSow(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val littersWithPiglets = breedingRepo.getLittersWithPiglets(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val topLitters = breedingRepo.getTopLitters(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val pigletsNeedingIron = breedingRepo.getPigletsNeedingIron(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val activeSows = pigRepo.getActiveFemales(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val avgBornAlive = breedingRepo.getAvgBornAlive(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0.0)

    fun addFarrowing(f: FarrowingEntity) = viewModelScope.launch { breedingRepo.addFarrowing(f) }
    fun updateLitter(l: LitterEntity)    = viewModelScope.launch { breedingRepo.updateLitter(l) }
    fun updatePiglet(p: PigletEntity)    = viewModelScope.launch { breedingRepo.updatePiglet(p) }
    fun markIronInjection(id: Long)      = viewModelScope.launch { breedingRepo.markIronInjection(id, System.currentTimeMillis()) }
    fun markPigletDeath(id: Long, cause: String) = viewModelScope.launch { breedingRepo.markPigletDeath(id, cause) }

    fun getPiglets(litterId: Long) = breedingRepo.getPigletsByLitter(litterId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
}

// ══════════════════════════════════════════════════════════
//  FEED VIEW MODEL
// ══════════════════════════════════════════════════════════
@HiltViewModel
class FeedViewModel @Inject constructor(
    private val feedRepo: FeedRepository
) : ViewModel() {

    private val farmId = DEFAULT_FARM_ID

    val formulasWithIngredients = feedRepo.getActiveFormulasWithIngredients(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val inventory = feedRepo.getInventory(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val lowStockItems = feedRepo.getLowStockItems(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val activePlans = feedRepo.getActivePlans(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val allConsumption = feedRepo.getAllConsumption(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val monthlyForecast = feedRepo.getMonthlyFeedForecast(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val totalInventoryValue = feedRepo.getTotalInventoryValue(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0.0)

    fun saveFormula(formula: FeedFormulaEntity, ingredients: List<FormulaIngredientEntity>) =
        viewModelScope.launch { feedRepo.saveFormulaWithIngredients(formula, ingredients) }

    fun addInventoryItem(i: FeedInventoryEntity) = viewModelScope.launch { feedRepo.addInventoryItem(i) }
    fun addStock(id: Long, kg: Double)           = viewModelScope.launch { feedRepo.addStock(id, kg) }
    fun removeStock(id: Long, kg: Double)        = viewModelScope.launch { feedRepo.removeStock(id, kg) }
    fun saveFeedingPlan(p: FeedingPlanEntity)    = viewModelScope.launch { feedRepo.addFeedingPlan(p) }
    fun logConsumption(c: FeedConsumptionEntity) = viewModelScope.launch { feedRepo.logConsumption(c) }
}

// ══════════════════════════════════════════════════════════
//  HEALTH VIEW MODEL
// ══════════════════════════════════════════════════════════
@HiltViewModel
class HealthViewModel @Inject constructor(
    private val healthRepo: HealthRepository,
    private val pigRepo:    PigRepository
) : ViewModel() {

    private val farmId = DEFAULT_FARM_ID

    val allTreatments        = healthRepo.getAllTreatments(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val pendingFollowUps     = healthRepo.getPendingFollowUps(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val upcomingVaccinations = healthRepo.getUpcomingVaccinations(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val upcomingDeworming    = healthRepo.getUpcomingDeworming(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val activePigs           = pigRepo.getActivePigs(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun addTreatment(t: TreatmentEntity)    = viewModelScope.launch { healthRepo.addTreatment(t) }
    fun addVaccination(v: VaccinationEntity) = viewModelScope.launch { healthRepo.addVaccination(v) }
    fun addDeworming(d: DewormingEntity)    = viewModelScope.launch { healthRepo.addDeworming(d) }
    fun deleteTreatment(t: TreatmentEntity) = viewModelScope.launch { healthRepo.deleteTreatment(t) }

    fun getPigTreatments(pigId: Long)    = healthRepo.getTreatmentsByPig(pigId)
    fun getPigVaccinations(pigId: Long)  = healthRepo.getVaccinationsByPig(pigId)
    fun getPigDeworming(pigId: Long)     = healthRepo.getDewormingByPig(pigId)
}

// ══════════════════════════════════════════════════════════
//  FINANCE VIEW MODEL
// ══════════════════════════════════════════════════════════
@HiltViewModel
class FinanceViewModel @Inject constructor(
    private val financeRepo: FinanceRepository
) : ViewModel() {

    private val farmId = DEFAULT_FARM_ID
    private val _period = MutableStateFlow(Pair(startOfMonth(), endOfMonth()))
    val period: StateFlow<Pair<Long, Long>> = _period

    val allSales    = financeRepo.getAllSales(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val allExpenses = financeRepo.getAllExpenses(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val periodRevenue = _period.flatMapLatest { (from, to) ->
        financeRepo.getRevenueSince(farmId, from, to)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0.0)

    @OptIn(ExperimentalCoroutinesApi::class)
    val periodExpenses = _period.flatMapLatest { (from, to) ->
        financeRepo.getExpenseSince(farmId, from, to)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0.0)

    @OptIn(ExperimentalCoroutinesApi::class)
    val expensesByCategory = _period.flatMapLatest { (from, to) ->
        financeRepo.getExpensesByCategory(farmId, from, to)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val netProfit = combine(periodRevenue, periodExpenses) { r: Double?, e: Double? -> (r ?: 0.0) - (e ?: 0.0) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0.0)

    fun setPeriod(from: Long, to: Long) { _period.value = Pair(from, to) }
    fun addSale(s: SaleEntity)          = viewModelScope.launch { financeRepo.addSale(s) }
    fun addExpense(e: ExpenseEntity)    = viewModelScope.launch { financeRepo.addExpense(e) }
    fun deleteSale(s: SaleEntity)       = viewModelScope.launch { financeRepo.deleteSale(s) }
    fun deleteExpense(e: ExpenseEntity) = viewModelScope.launch { financeRepo.deleteExpense(e) }

    private fun startOfMonth(): Long {
        val c = java.util.Calendar.getInstance()
        c.set(java.util.Calendar.DAY_OF_MONTH, 1)
        c.set(java.util.Calendar.HOUR_OF_DAY, 0); c.set(java.util.Calendar.MINUTE, 0); c.set(java.util.Calendar.SECOND, 0)
        return c.timeInMillis
    }
    private fun endOfMonth(): Long {
        val c = java.util.Calendar.getInstance()
        c.set(java.util.Calendar.DAY_OF_MONTH, c.getActualMaximum(java.util.Calendar.DAY_OF_MONTH))
        c.set(java.util.Calendar.HOUR_OF_DAY, 23); c.set(java.util.Calendar.MINUTE, 59); c.set(java.util.Calendar.SECOND, 59)
        return c.timeInMillis
    }
}

// ══════════════════════════════════════════════════════════
//  REPORTS VIEW MODEL
// ══════════════════════════════════════════════════════════
@HiltViewModel
class ReportsViewModel @Inject constructor(
    private val pigRepo:      PigRepository,
    private val breedingRepo: BreedingRepository,
    private val feedRepo:     FeedRepository,
    private val financeRepo:  FinanceRepository
) : ViewModel() {

    private val farmId = DEFAULT_FARM_ID
    private val thirtyDaysAgo = System.currentTimeMillis() - 30L * 86_400_000L
    private val now = System.currentTimeMillis()

    val mortalityRate   = pigRepo.getMortalityRate(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0.0)

    val avgBornAlive    = breedingRepo.getAvgBornAlive(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0.0)

    val topLitters      = breedingRepo.getTopLitters(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val monthlyForecast = feedRepo.getMonthlyFeedForecast(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val totalRevenue    = financeRepo.getRevenueSince(farmId, thirtyDaysAgo, now)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0.0)

    val totalExpenses   = financeRepo.getExpenseSince(farmId, thirtyDaysAgo, now)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0.0)

    val netProfit       = combine(totalRevenue, totalExpenses) { r, e -> (r ?: 0.0) - (e ?: 0.0) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0.0)

    val activePigCount  = pigRepo.getActivePigCount(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    val totalConsumption = feedRepo.getTotalConsumptionRange(farmId, thirtyDaysAgo, now)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0.0)
}

// ══════════════════════════════════════════════════════════
//  NOTIFICATION VIEW MODEL
// ══════════════════════════════════════════════════════════
@HiltViewModel
class NotificationViewModel @Inject constructor(
    private val notificationRepo: NotificationRepository
) : ViewModel() {

    private val farmId = DEFAULT_FARM_ID

    val allNotifications    = notificationRepo.getAllNotifications(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val urgentNotifications = notificationRepo.getUrgentNotifications(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val unreadCount         = notificationRepo.getUnreadCount(farmId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    fun markRead(id: Long)       = viewModelScope.launch { notificationRepo.markRead(id) }
    fun markAllRead()            = viewModelScope.launch { notificationRepo.markAllRead(farmId) }
    fun markCompleted(id: Long)  = viewModelScope.launch { notificationRepo.markCompleted(id) }
    fun deleteCompleted()        = viewModelScope.launch { notificationRepo.deleteCompleted(farmId) }
    fun delete(n: FarmNotificationEntity) = viewModelScope.launch { notificationRepo.delete(n) }
}
