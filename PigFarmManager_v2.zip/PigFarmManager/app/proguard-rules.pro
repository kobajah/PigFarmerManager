# ── Kotlin / Coroutines ───────────────────────────────────
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembernames class kotlinx.** { volatile <fields>; }

# ── Room ──────────────────────────────────────────────────
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-keepclassmembers @androidx.room.Entity class * { *; }
-keepclassmembers class * extends androidx.room.RoomDatabase { abstract *; }

# ── Hilt / Dagger ─────────────────────────────────────────
-keepnames @dagger.hilt.android.lifecycle.HiltViewModel class * extends androidx.lifecycle.ViewModel
-dontwarn com.google.errorprone.annotations.**

# ── Data classes (used in Room queries) ──────────────────
-keepclassmembers class com.pigfarm.manager.data.local.entity.** { *; }
-keepclassmembers class com.pigfarm.manager.data.local.dao.CategoryTotal { *; }

# ── WorkManager ───────────────────────────────────────────
-keep class * extends androidx.work.Worker
-keep class * extends androidx.work.CoroutineWorker
-keepclassmembers class * extends androidx.work.CoroutineWorker { public <init>(...); }

# ── Gson / serialization ──────────────────────────────────
-keepattributes Signature
-keepattributes *Annotation*
-dontwarn sun.misc.**
-keep class com.google.gson.** { *; }

# ── General Android ───────────────────────────────────────
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
