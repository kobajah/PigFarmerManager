# 🐷 Pig Farm Manager — Android App

Full-stack pig farm management system.
**No computer needed** — build the APK via GitHub Actions from your phone.

---

## Getting the APK — No Computer Needed

### Step 1 — Create a GitHub account
Go to [github.com](https://github.com) on your phone browser → Sign up (free).

---

### Step 2 — Create a new repository
1. Tap **+** → **New repository**
2. Name it `PigFarmManager`
3. Set to **Public** (free GitHub Actions minutes)
4. Leave "Initialize with README" **unchecked**
5. Tap **Create repository**

---

### Step 3 — Upload the project files
On the empty repo page, tap **uploading an existing file** and upload everything, keeping the exact folder structure:

```
.github/workflows/build.yml   ← critical
app/
gradle/
gradlew
gradlew.bat
build.gradle.kts
settings.gradle.kts
settings.gradle.kts
```

> Tip: zip the whole PigFarmManager folder → GitHub accepts zip uploads.
> Or use the **GitHub** mobile app to push files directly from your phone.

---

### Step 4 — Watch the build
1. Go to your repo → **Actions** tab
2. You will see **Build APK** running (~5–8 minutes first time)
3. Green ✅ = success

---

### Step 5 — Download the APK
1. Click the completed workflow run
2. Scroll to **Artifacts** at the bottom
3. Tap **PigFarmManager-debug-1** → downloads a zip
4. Extract the zip → inside is `app-debug.apk`

---

### Step 6 — Install on your phone
1. Open **Files** app → find `app-debug.apk`
2. Tap it → **Install**
3. If blocked: **Settings → Security → Install unknown apps → Allow**

> Every future push to GitHub triggers a new APK build automatically.

---

## Supabase Backend (optional — cloud sync / multi-device)

1. Create a project at [supabase.com](https://supabase.com)
2. Run `supabase_schema.sql` in the SQL editor
3. Add your keys to `di/AppModule.kt` (see Supabase section below)

---

## Architecture

```
MainActivity (Hilt)
 └─ NavHost (Compose Navigation)
     ├─ DashboardScreen    ← ViewModels (Hilt)
     ├─ PigsScreen                  ↕
     ├─ BreedingScreen         Repositories
     ├─ FarrowingScreen             ↕
     ├─ FeedScreen           Room DAOs
     ├─ HealthScreen               ↕
     ├─ FinanceScreen        AppDatabase (SQLite)
     ├─ ReportsScreen
     └─ NotificationsScreen

NotificationWorker (WorkManager, every 6h)
 └─ Scans due events → posts system notifications
```

**Pattern**: MVVM + Repository + Clean Architecture
**DI**: Hilt | **Async**: Coroutines + Flow | **Storage**: Room (offline-first)

---

## Notification Events

| Event | Trigger | Days |
|---|---|---|
| Iron injection | After farrowing | D+3 |
| Castration | After farrowing | D+7 |
| Weaning | After farrowing | D+21 |
| Return to heat / re-breed | After service | D+21 |
| Pregnancy confirmation | After service | D+28 |
| Pre-farrowing alert | After pregnancy confirmed | EFD−7 |
| Farrowing day | After pregnancy confirmed | EFD |
| Vaccination due | After vaccination recorded | Next due date |
| Deworming due | After deworming recorded | Next due date |
| Treatment follow-up | After treatment recorded | Follow-up date |
| Low feed stock | Real-time | qty ≤ reorder level |

*EFD = Expected Farrowing Date = breeding date + 114 days*

---

## Business Questions Answered

| Question | Screen |
|---|---|
| Which pigs need feeding today? | Dashboard + Feed → Plans |
| Which sows are due for farrowing? | Dashboard + Breeding → Due Soon |
| Which piglets need treatment? | Dashboard + Farrowing → Piglets |
| Which sows should be bred this week? | Breeding → Heat Check |
| How much feed next month? | Feed → Forecast + Reports |
| Which animals are profitable? | Reports → Herd Profitability |
| What is the mortality rate? | Reports → Mortality Gauge |
| Which litters perform best? | Farrowing → Top Litters + Reports |

---

## Key Dependencies

| Library | Version | Purpose |
|---|---|---|
| Jetpack Compose BOM | 2024.06.00 | UI framework |
| Material3 | BOM-managed | Design system |
| Navigation Compose | 2.7.7 | Screen routing |
| Room | 2.6.1 | Local SQLite ORM |
| Hilt | 2.51.1 | Dependency injection |
| WorkManager | 2.9.0 | Background notifications |
| KSP | 1.9.24-1.0.20 | Code generation |

---

## Requirements

- Android 8.0+ (minSdk 26)
- ~50 MB storage for app + local database
