package com.pigfarm.manager.worker

import android.app.*
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.pigfarm.manager.PigFarmApplication.*
import com.pigfarm.manager.data.local.entity.*
import com.pigfarm.manager.data.repository.*
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.flow.first

@HiltWorker
class NotificationWorker @AssistedInject constructor(
    @Assisted private val ctx: Context,
    @Assisted params: WorkerParameters,
    private val breedingRepo:  BreedingRepository,
    private val pigRepo:       PigRepository,
    private val healthRepo:    HealthRepository,
    private val feedRepo:      FeedRepository,
    private val notifRepo:     NotificationRepository
) : CoroutineWorker(ctx, params) {

    companion object {
        const val WORK_NAME = "pig_farm_notification_worker"
        private const val FARM_ID = 1L
    }

    override suspend fun doWork(): Result {
        return try {
            checkAndPostNotifications()
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    private suspend fun checkAndPostNotifications() {
        // 1. Sows due for farrowing (≤3 days)
        val dueSoon = breedingRepo.getSowsDueSoon(FARM_ID, daysAhead = 3).first()
        dueSoon.forEach { pws ->
            val daysLeft = pws.pregnancy.expectedFarrowingDate?.daysUntil() ?: return@forEach
            val title   = if (daysLeft <= 0) "🐷 Farrowing Today!" else "🐷 Farrowing in $daysLeft day(s)"
            val message = "Sow ${pws.sow?.tagNumber ?: "#${pws.pregnancy.sowId}"} is due to farrow"
            postNotification(
                id      = pws.pregnancy.id.toInt() + 1000,
                title   = title,
                message = message,
                channel = CHANNEL_URGENT,
                priority = NotificationCompat.PRIORITY_HIGH
            )
        }

        // 2. Piglets needing iron injection
        val ironPiglets = breedingRepo.getPigletsNeedingIron(FARM_ID).first()
        if (ironPiglets.isNotEmpty()) {
            postNotification(
                id       = 2001,
                title    = "💉 Iron Injection Overdue",
                message  = "${ironPiglets.size} piglet(s) need iron injection (3+ days old)",
                channel  = CHANNEL_HEALTH,
                priority = NotificationCompat.PRIORITY_HIGH
            )
        }

        // 3. Heat check due
        val heatCheck = breedingRepo.getSowsDueForHeatCheck(FARM_ID).first()
        if (heatCheck.isNotEmpty()) {
            postNotification(
                id       = 3001,
                title    = "🔁 Heat Check Due",
                message  = "${heatCheck.size} sow(s) may be returning to heat — check now",
                channel  = CHANNEL_URGENT,
                priority = NotificationCompat.PRIORITY_DEFAULT
            )
        }

        // 4. Upcoming vaccinations
        val vaccines = healthRepo.getUpcomingVaccinations(FARM_ID).first()
        if (vaccines.isNotEmpty()) {
            postNotification(
                id       = 4001,
                title    = "💉 Vaccination Due",
                message  = "${vaccines.size} vaccination(s) due within 14 days",
                channel  = CHANNEL_HEALTH,
                priority = NotificationCompat.PRIORITY_DEFAULT
            )
        }

        // 5. Upcoming deworming
        val deworm = healthRepo.getUpcomingDeworming(FARM_ID).first()
        if (deworm.isNotEmpty()) {
            postNotification(
                id       = 5001,
                title    = "🐛 Deworming Due",
                message  = "${deworm.size} deworming(s) due within 14 days",
                channel  = CHANNEL_HEALTH,
                priority = NotificationCompat.PRIORITY_LOW
            )
        }

        // 6. Treatment follow-ups
        val followUps = healthRepo.getPendingFollowUps(FARM_ID).first()
        if (followUps.isNotEmpty()) {
            postNotification(
                id       = 6001,
                title    = "🩺 Treatment Follow-up",
                message  = "${followUps.size} treatment follow-up(s) due within 7 days",
                channel  = CHANNEL_HEALTH,
                priority = NotificationCompat.PRIORITY_HIGH
            )
        }

        // 7. Low feed stock
        val lowStock = feedRepo.getLowStockItems(FARM_ID).first()
        if (lowStock.isNotEmpty()) {
            postNotification(
                id       = 7001,
                title    = "⚠️ Low Feed Stock",
                message  = "${lowStock.size} ingredient(s) below reorder level: ${lowStock.take(3).joinToString { it.ingredientName }}",
                channel  = CHANNEL_FEED,
                priority = NotificationCompat.PRIORITY_DEFAULT
            )
        }

        // 8. In-app notifications (DB-stored) that are due today
        val dueToday = notifRepo.getDueToday(FARM_ID).first()
        dueToday.filter { !it.isRead }.forEach { n ->
            val channel  = channelForPriority(n.priority)
            val priority = priorityForLevel(n.priority)
            postNotification(
                id       = n.id.toInt() + 9000,
                title    = n.title,
                message  = n.message,
                channel  = channel,
                priority = priority
            )
            notifRepo.markRead(n.id)
        }
    }

    private fun postNotification(id: Int, title: String, message: String, channel: String, priority: Int) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) return
        }

        val intent = ctx.packageManager
            .getLaunchIntentForPackage(ctx.packageName)
            ?.addFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP)

        val pendingIntent = PendingIntent.getActivity(
            ctx, id, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(priority)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        NotificationManagerCompat.from(ctx).notify(id, notification)
    }

    private fun channelForPriority(p: NotificationPriority) = when (p) {
        NotificationPriority.URGENT, NotificationPriority.HIGH -> CHANNEL_URGENT
        NotificationPriority.MEDIUM                             -> CHANNEL_HEALTH
        NotificationPriority.LOW                                -> CHANNEL_GENERAL
    }

    private fun priorityForLevel(p: NotificationPriority) = when (p) {
        NotificationPriority.URGENT -> NotificationCompat.PRIORITY_MAX
        NotificationPriority.HIGH   -> NotificationCompat.PRIORITY_HIGH
        NotificationPriority.MEDIUM -> NotificationCompat.PRIORITY_DEFAULT
        NotificationPriority.LOW    -> NotificationCompat.PRIORITY_LOW
    }

    private fun Long.daysUntil() = (this - System.currentTimeMillis()) / 86_400_000L
}
