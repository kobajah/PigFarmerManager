package com.pigfarm.manager.data.repository

import com.pigfarm.manager.data.local.AppDatabase
import com.pigfarm.manager.data.local.entity.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

// ══════════════════════════════════════════════════════════
//  PIG REPOSITORY
// ══════════════════════════════════════════════════════════
@Singleton
class PigRepository @Inject constructor(private val db: AppDatabase) {

    fun getActivePigs(farmId: Long)              = db.pigDao().getActivePigs(farmId)
    fun getAllPigs(farmId: Long)                  = db.pigDao().getAllPigs(farmId)
    fun getActiveFemales(farmId: Long)           = db.pigDao().getActiveFemales(farmId)
    fun getActiveBoars(farmId: Long)             = db.pigDao().getActiveBoars(farmId)
    fun getActivePigsWithPens(farmId: Long)      = db.pigDao().getActivePigsWithPens(farmId)
    fun getPigWithHealth(pigId: Long)            = db.pigDao().getPigWithHealth(pigId)
    fun getActivePigCount(farmId: Long)          = db.pigDao().getActivePigCount(farmId)
    fun getTotalPigCount(farmId: Long)           = db.pigDao().getTotalPigCount(farmId)
    fun getDeceasedCount(farmId: Long)           = db.pigDao().getDeceasedCount(farmId)

    suspend fun getPigById(id: Long)             = db.pigDao().getPigById(id)
    suspend fun addPig(pig: PigEntity): Long      = db.pigDao().insert(pig)
    suspend fun updatePig(pig: PigEntity)        = db.pigDao().update(pig)
    suspend fun deletePig(pig: PigEntity)        = db.pigDao().delete(pig)
    suspend fun updateStatus(pigId: Long, status: PigStatus) = db.pigDao().updateStatus(pigId, status)
    suspend fun movePigToPen(pigId: Long, penId: Long?, fromPenId: Long?, reason: String = "") {
        db.pigDao().updatePen(pigId, penId)
        db.movementDao().insert(MovementEntity(pigId = pigId, farmId = 0, fromPenId = fromPenId, toPenId = penId, reason = reason))
    }

    fun getPensByFarm(farmId: Long)              = db.penDao().getPensByFarm(farmId)
    fun getBuildingsByFarm(farmId: Long)         = db.buildingDao().getBuildingsByFarm(farmId)
    suspend fun addBuilding(b: BuildingEntity)   = db.buildingDao().insert(b)
    suspend fun addPen(p: PenEntity)             = db.penDao().insert(p)

    // Weight
    fun getWeightsByPig(pigId: Long)             = db.weightRecordDao().getWeightsByPig(pigId)
    suspend fun addWeightRecord(w: WeightRecordEntity) = db.weightRecordDao().insert(w)
    suspend fun getLatestWeight(pigId: Long)     = db.weightRecordDao().getLatestWeight(pigId)
    suspend fun deleteWeight(w: WeightRecordEntity) = db.weightRecordDao().delete(w)

    // Movement history
    fun getMovementsByPig(pigId: Long)           = db.movementDao().getMovementsByPig(pigId)

    /** Mortality rate as a percentage */
    fun getMortalityRate(farmId: Long): Flow<Double> =
        combine(getDeceasedCount(farmId), getTotalPigCount(farmId)) { dead, total ->
            if (total == 0) 0.0 else dead.toDouble() / total.toDouble() * 100.0
        }
}

// ══════════════════════════════════════════════════════════
//  BREEDING REPOSITORY
// ══════════════════════════════════════════════════════════
@Singleton
class BreedingRepository @Inject constructor(private val db: AppDatabase) {

    fun getAllBreedings(farmId: Long)             = db.breedingDao().getAllBreedings(farmId)
    fun getBreedingsBySow(sowId: Long)           = db.breedingDao().getBreedingsBySow(sowId)
    fun getBreedingsWithSow(farmId: Long)        = db.breedingDao().getBreedingsWithSow(farmId)

    fun getConfirmedPregnancies(farmId: Long)    = db.pregnancyDao().getConfirmedPregnancies(farmId)
    fun getConfirmedPregnanciesWithSow(farmId: Long) = db.pregnancyDao().getConfirmedPregnanciesWithSow(farmId)
    fun getConfirmedPregnancyCount(farmId: Long) = db.pregnancyDao().getConfirmedPregnancyCount(farmId)
    fun getAllFarrowings(farmId: Long)            = db.farrowingDao().getAllFarrowings(farmId)
    fun getFarrowingsWithSow(farmId: Long)       = db.farrowingDao().getFarrowingsWithSow(farmId)
    fun getFarrowingCount(farmId: Long)          = db.farrowingDao().getFarrowingCount(farmId)
    fun getAvgBornAlive(farmId: Long)            = db.farrowingDao().getAvgBornAlive(farmId)
    fun getAllLitters(farmId: Long)               = db.litterDao().getAllLitters(farmId)
    fun getLittersWithPiglets(farmId: Long)      = db.litterDao().getLittersWithPiglets(farmId)
    fun getTopLitters(farmId: Long)              = db.litterDao().getTopPerformingLitters(farmId)

    /** Sows due to farrow within the next [daysAhead] days */
    fun getSowsDueSoon(farmId: Long, daysAhead: Int = 14): Flow<List<PregnancyWithSow>> {
        val now  = System.currentTimeMillis()
        val edge = now + daysAhead.toLong() * 86_400_000L
        return db.pregnancyDao().getPregnanciesDueSoon(farmId, now, edge)
    }

    /** Sows that may be returning to heat (bred 18–24 days ago, not yet confirmed pregnant) */
    fun getSowsDueForHeatCheck(farmId: Long): Flow<List<BreedingEntity>> {
        val now  = System.currentTimeMillis()
        val from = now - 24L * 86_400_000L
        val to   = now - 18L * 86_400_000L
        return db.breedingDao().getSowsDueForHeatCheck(farmId, from, to)
    }

    suspend fun addBreeding(b: BreedingEntity): Long {
        val id = db.breedingDao().insert(b)
        // Auto-create SUSPECTED pregnancy
        db.pregnancyDao().insert(
            PregnancyEntity(
                farmId = b.farmId,
                sowId  = b.sowId,
                breedingId = id,
                expectedFarrowingDate = b.expectedFarrowingDate,
                status = PregnancyStatus.SUSPECTED
            )
        )
        // Schedule notifications
        scheduleBreedingNotifications(b.copy(id = id))
        return id
    }

    suspend fun confirmPregnancy(pregnancyId: Long, confirmedBy: String) {
        val preg = db.pregnancyDao().getLatestPregnancyForSow(0) ?: return
        db.pregnancyDao().update(preg.copy(status = PregnancyStatus.CONFIRMED, confirmedBy = confirmedBy))
    }

    suspend fun updatePregnancyStatus(p: PregnancyEntity) = db.pregnancyDao().update(p)

    suspend fun addFarrowing(f: FarrowingEntity): Long {
        val id = db.farrowingDao().insert(f)
        // Create litter record
        val sow = db.pigDao().getPigById(f.sowId)
        val parityCount = db.farrowingDao().getFarrowingsBySow(f.sowId).let { 1 }
        val litterId = db.litterDao().insert(
            LitterEntity(farmId = f.farmId, farrowingId = id, sowId = f.sowId, litterNumber = parityCount)
        )
        // Bulk create piglet stubs
        if (f.bornAlive > 0) {
            val piglets = (1..f.bornAlive).map { i ->
                PigletEntity(
                    litterId  = litterId,
                    farmId    = f.farmId,
                    tagNumber = "${sow?.tagNumber ?: "UNK"}-L${litterId}-$i",
                    sex       = PigletSex.UNKNOWN,
                    birthDate = f.farrowingDate,
                    status    = PigletStatus.ALIVE
                )
            }
            db.pigletDao().insertAll(piglets)
        }
        // Schedule iron injection + weaning notifications
        scheduleFarrowingNotifications(f.copy(id = id), litterId)
        return id
    }

    suspend fun updateLitter(l: LitterEntity)  = db.litterDao().update(l)
    suspend fun updatePiglet(p: PigletEntity)  = db.pigletDao().update(p)
    suspend fun markIronInjection(pigletId: Long, date: Long) = db.pigletDao().markIronInjection(pigletId, date)
    suspend fun markPigletDeath(pigletId: Long, cause: String) =
        db.pigletDao().markDeath(pigletId, PigletStatus.DEAD, System.currentTimeMillis(), cause)

    fun getPigletsByLitter(litterId: Long)     = db.pigletDao().getPigletsByLitter(litterId)
    fun getPigletsNeedingIron(farmId: Long): Flow<List<PigletEntity>> {
        val threeDaysAgo = System.currentTimeMillis() - 3L * 86_400_000L
        return db.pigletDao().getPigletsNeedingIronInjection(farmId, threeDaysAgo)
    }

    private suspend fun scheduleBreedingNotifications(b: BreedingEntity) {
        db.notificationDao().insertAll(listOf(
            FarmNotificationEntity(farmId = b.farmId, pigId = b.sowId,
                type = NotificationType.REPEAT_BREEDING, priority = NotificationPriority.HIGH,
                title = "Heat Check", message = "Check if sow #${b.sowId} returned to heat",
                dueDate = b.repeatDueDate),
            FarmNotificationEntity(farmId = b.farmId, pigId = b.sowId,
                type = NotificationType.PREGNANCY_CHECK, priority = NotificationPriority.MEDIUM,
                title = "Pregnancy Confirmation", message = "Confirm pregnancy for sow #${b.sowId}",
                dueDate = b.breedingDate + 28L * 86_400_000L)
        ))
    }

    private suspend fun scheduleFarrowingNotifications(f: FarrowingEntity, litterId: Long) {
        db.notificationDao().insertAll(listOf(
            FarmNotificationEntity(farmId = f.farmId, pigId = f.sowId, litterId = litterId,
                type = NotificationType.IRON_INJECTION, priority = NotificationPriority.HIGH,
                title = "Iron Injection Due", message = "Piglets from sow #${f.sowId} need iron injection",
                dueDate = f.farrowingDate + 3L * 86_400_000L),
            FarmNotificationEntity(farmId = f.farmId, pigId = f.sowId, litterId = litterId,
                type = NotificationType.CASTRATION, priority = NotificationPriority.MEDIUM,
                title = "Castration Due", message = "Male piglets ready for castration",
                dueDate = f.farrowingDate + 7L * 86_400_000L),
            FarmNotificationEntity(farmId = f.farmId, pigId = f.sowId, litterId = litterId,
                type = NotificationType.WEANING_DUE, priority = NotificationPriority.HIGH,
                title = "Weaning Due", message = "Litter ready for weaning (21 days)",
                dueDate = f.farrowingDate + 21L * 86_400_000L)
        ))
    }
}

// ══════════════════════════════════════════════════════════
//  HEALTH REPOSITORY
// ══════════════════════════════════════════════════════════
@Singleton
class HealthRepository @Inject constructor(private val db: AppDatabase) {

    fun getTreatmentsByPig(pigId: Long)          = db.treatmentDao().getTreatmentsByPig(pigId)
    fun getAllTreatments(farmId: Long)            = db.treatmentDao().getAllTreatments(farmId)
    fun getVaccinationsByPig(pigId: Long)        = db.vaccinationDao().getVaccinationsByPig(pigId)
    fun getDewormingByPig(pigId: Long)           = db.dewormingDao().getDewormingByPig(pigId)

    fun getPendingFollowUps(farmId: Long): Flow<List<TreatmentEntity>> {
        val sevenDaysAhead = System.currentTimeMillis() + 7L * 86_400_000L
        return db.treatmentDao().getPendingFollowUps(farmId, sevenDaysAhead)
    }

    fun getUpcomingVaccinations(farmId: Long): Flow<List<VaccinationEntity>> {
        val fourteenDaysAhead = System.currentTimeMillis() + 14L * 86_400_000L
        return db.vaccinationDao().getUpcomingVaccinations(farmId, fourteenDaysAhead)
    }

    fun getUpcomingDeworming(farmId: Long): Flow<List<DewormingEntity>> {
        val fourteenDaysAhead = System.currentTimeMillis() + 14L * 86_400_000L
        return db.dewormingDao().getUpcomingDeworming(farmId, fourteenDaysAhead)
    }

    suspend fun addTreatment(t: TreatmentEntity): Long {
        val id = db.treatmentDao().insert(t)
        t.followUpDate?.let { followDate ->
            db.notificationDao().insert(
                FarmNotificationEntity(farmId = t.farmId, pigId = t.pigId,
                    type = NotificationType.TREATMENT_FOLLOWUP, priority = NotificationPriority.HIGH,
                    title = "Treatment Follow-up", message = "Follow up on ${t.medicine} treatment",
                    dueDate = followDate)
            )
        }
        return id
    }

    suspend fun addVaccination(v: VaccinationEntity): Long {
        val id = db.vaccinationDao().insert(v)
        v.nextDueDate?.let { nextDate ->
            db.notificationDao().insert(
                FarmNotificationEntity(farmId = v.farmId, pigId = v.pigId,
                    type = NotificationType.VACCINATION_DUE, priority = NotificationPriority.MEDIUM,
                    title = "Vaccination Due", message = "${v.vaccineName} next dose due",
                    dueDate = nextDate)
            )
        }
        return id
    }

    suspend fun addDeworming(d: DewormingEntity): Long {
        val id = db.dewormingDao().insert(d)
        d.nextDueDate?.let { nextDate ->
            db.notificationDao().insert(
                FarmNotificationEntity(farmId = d.farmId, pigId = d.pigId,
                    type = NotificationType.DEWORMING_DUE, priority = NotificationPriority.MEDIUM,
                    title = "Deworming Due", message = "${d.product} next dose due",
                    dueDate = nextDate)
            )
        }
        return id
    }

    suspend fun deleteTreatment(t: TreatmentEntity)   = db.treatmentDao().delete(t)
    suspend fun deleteVaccination(v: VaccinationEntity) = db.vaccinationDao().delete(v)
    suspend fun deleteDeworming(d: DewormingEntity)   = db.dewormingDao().delete(d)
}

// ══════════════════════════════════════════════════════════
//  FEED REPOSITORY
// ══════════════════════════════════════════════════════════
@Singleton
class FeedRepository @Inject constructor(private val db: AppDatabase) {

    fun getActiveFormulas(farmId: Long)          = db.feedFormulaDao().getActiveFormulas(farmId)
    fun getAllFormulas(farmId: Long)              = db.feedFormulaDao().getAllFormulas(farmId)
    fun getFormulaWithIngredients(id: Long)      = db.feedFormulaDao().getFormulaWithIngredients(id)
    fun getActiveFormulasWithIngredients(farmId: Long) = db.feedFormulaDao().getActiveFormulasWithIngredients(farmId)
    fun getInventory(farmId: Long)               = db.feedInventoryDao().getInventory(farmId)
    fun getLowStockItems(farmId: Long)           = db.feedInventoryDao().getLowStockItems(farmId)
    fun getTotalInventoryValue(farmId: Long)     = db.feedInventoryDao().getTotalInventoryValue(farmId)
    fun getActivePlans(farmId: Long)             = db.feedingPlanDao().getActivePlans(farmId)
    fun getAllConsumption(farmId: Long)           = db.feedConsumptionDao().getAllConsumption(farmId)

    suspend fun saveFormulaWithIngredients(formula: FeedFormulaEntity, ingredients: List<FormulaIngredientEntity>): Long {
        val id = db.feedFormulaDao().insert(formula)
        db.feedFormulaDao().insertIngredients(ingredients.map { it.copy(formulaId = id) })
        return id
    }

    suspend fun updateFormulaWithIngredients(formula: FeedFormulaEntity, ingredients: List<FormulaIngredientEntity>) {
        db.feedFormulaDao().update(formula)
        db.feedFormulaDao().deleteIngredientsByFormula(formula.id)
        db.feedFormulaDao().insertIngredients(ingredients.map { it.copy(formulaId = formula.id) })
    }

    suspend fun addInventoryItem(i: FeedInventoryEntity) = db.feedInventoryDao().insert(i)
    suspend fun addStock(id: Long, kg: Double)           = db.feedInventoryDao().addStock(id, kg)
    suspend fun removeStock(id: Long, kg: Double)        = db.feedInventoryDao().removeStock(id, kg)
    suspend fun updateInventory(i: FeedInventoryEntity)  = db.feedInventoryDao().update(i)

    suspend fun addFeedingPlan(p: FeedingPlanEntity)     = db.feedingPlanDao().insert(p)
    suspend fun updateFeedingPlan(p: FeedingPlanEntity)  = db.feedingPlanDao().update(p)

    suspend fun logConsumption(c: FeedConsumptionEntity) = db.feedConsumptionDao().insert(c)

    /** Estimate next-month feed requirement from active plans × active pig counts */
    fun getMonthlyFeedForecast(farmId: Long): Flow<List<Pair<TargetGroup, Double>>> =
        db.feedingPlanDao().getActivePlans(farmId).map { plans ->
            plans.filter { it.isActive }.map { plan ->
                plan.targetGroup to plan.dailyAmountKg * 30.0
            }
        }

    fun getTotalConsumptionRange(farmId: Long, from: Long, to: Long) =
        db.feedConsumptionDao().getTotalConsumption(farmId, from, to)
}

// ══════════════════════════════════════════════════════════
//  FINANCE REPOSITORY
// ══════════════════════════════════════════════════════════
@Singleton
class FinanceRepository @Inject constructor(private val db: AppDatabase) {

    fun getAllSales(farmId: Long)             = db.saleDao().getAllSales(farmId)
    fun getAllExpenses(farmId: Long)          = db.expenseDao().getAllExpenses(farmId)
    fun getExpensesByCategory(farmId: Long, from: Long, to: Long) = db.expenseDao().getExpensesByCategory(farmId, from, to)

    fun getRevenueSince(farmId: Long, from: Long, to: Long)  = db.saleDao().getTotalRevenue(farmId, from, to)
    fun getExpenseSince(farmId: Long, from: Long, to: Long)  = db.expenseDao().getTotalExpenses(farmId, from, to)

    /** Net profit for a given period */
    fun getNetProfit(farmId: Long, from: Long, to: Long): Flow<Double> =
        combine(getRevenueSince(farmId, from, to), getExpenseSince(farmId, from, to)) { rev, exp ->
            (rev ?: 0.0) - (exp ?: 0.0)
        }

    suspend fun addSale(s: SaleEntity): Long {
        val id = db.saleDao().insert(s)
        s.pigId?.let { db.pigDao().updateStatus(it, PigStatus.SOLD) }
        return id
    }

    suspend fun addExpense(e: ExpenseEntity) = db.expenseDao().insert(e)
    suspend fun updateSale(s: SaleEntity)    = db.saleDao().update(s)
    suspend fun updateExpense(e: ExpenseEntity) = db.expenseDao().update(e)
    suspend fun deleteSale(s: SaleEntity)    = db.saleDao().delete(s)
    suspend fun deleteExpense(e: ExpenseEntity) = db.expenseDao().delete(e)
    suspend fun getRevenueByPig(farmId: Long, pigId: Long) = db.saleDao().getRevenueByPig(farmId, pigId)
}

// ══════════════════════════════════════════════════════════
//  NOTIFICATION REPOSITORY
// ══════════════════════════════════════════════════════════
@Singleton
class NotificationRepository @Inject constructor(private val db: AppDatabase) {

    fun getAllNotifications(farmId: Long)        = db.notificationDao().getAllNotifications(farmId)
    fun getUnreadNotifications(farmId: Long)     = db.notificationDao().getUnreadNotifications(farmId)
    fun getUnreadCount(farmId: Long)             = db.notificationDao().getUnreadCount(farmId)
    fun getUrgentNotifications(farmId: Long)     = db.notificationDao().getUrgentNotifications(farmId)
    fun getDueToday(farmId: Long): Flow<List<FarmNotificationEntity>> {
        val endOfDay = System.currentTimeMillis()
        return db.notificationDao().getDueToday(farmId, endOfDay)
    }

    suspend fun markRead(id: Long)               = db.notificationDao().markRead(id)
    suspend fun markAllRead(farmId: Long)        = db.notificationDao().markAllRead(farmId)
    suspend fun markCompleted(id: Long)          = db.notificationDao().markCompleted(id)
    suspend fun delete(n: FarmNotificationEntity) = db.notificationDao().delete(n)
    suspend fun deleteCompleted(farmId: Long)    = db.notificationDao().deleteCompleted(farmId)
    suspend fun insert(n: FarmNotificationEntity) = db.notificationDao().insert(n)
}
