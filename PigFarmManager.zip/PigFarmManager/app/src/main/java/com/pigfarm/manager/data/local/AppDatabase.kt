package com.pigfarm.manager.data.local

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.pigfarm.manager.data.local.dao.*
import com.pigfarm.manager.data.local.entity.*

@Database(
    entities = [
        FarmEntity::class,
        BuildingEntity::class,
        PenEntity::class,
        PigEntity::class,
        WeightRecordEntity::class,
        TreatmentEntity::class,
        VaccinationEntity::class,
        DewormingEntity::class,
        MovementEntity::class,
        BreedingEntity::class,
        PregnancyEntity::class,
        FarrowingEntity::class,
        LitterEntity::class,
        PigletEntity::class,
        FeedFormulaEntity::class,
        FormulaIngredientEntity::class,
        FeedInventoryEntity::class,
        FeedingPlanEntity::class,
        FeedConsumptionEntity::class,
        SaleEntity::class,
        ExpenseEntity::class,
        FarmNotificationEntity::class
    ],
    version = 1,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun farmDao(): FarmDao
    abstract fun buildingDao(): BuildingDao
    abstract fun penDao(): PenDao
    abstract fun pigDao(): PigDao
    abstract fun weightRecordDao(): WeightRecordDao
    abstract fun treatmentDao(): TreatmentDao
    abstract fun vaccinationDao(): VaccinationDao
    abstract fun dewormingDao(): DewormingDao
    abstract fun movementDao(): MovementDao
    abstract fun breedingDao(): BreedingDao
    abstract fun pregnancyDao(): PregnancyDao
    abstract fun farrowingDao(): FarrowingDao
    abstract fun litterDao(): LitterDao
    abstract fun pigletDao(): PigletDao
    abstract fun feedFormulaDao(): FeedFormulaDao
    abstract fun feedInventoryDao(): FeedInventoryDao
    abstract fun feedingPlanDao(): FeedingPlanDao
    abstract fun feedConsumptionDao(): FeedConsumptionDao
    abstract fun saleDao(): SaleDao
    abstract fun expenseDao(): ExpenseDao
    abstract fun notificationDao(): NotificationDao

    companion object {
        const val DATABASE_NAME = "pig_farm_db"

        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, DATABASE_NAME)
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Seed a default farm on first launch
                        }
                    })
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
