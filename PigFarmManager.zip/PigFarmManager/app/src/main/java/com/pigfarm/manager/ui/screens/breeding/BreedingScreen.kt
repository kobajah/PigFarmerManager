package com.pigfarm.manager.ui.screens.breeding

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.pigfarm.manager.data.local.entity.*
import com.pigfarm.manager.ui.components.*
import com.pigfarm.manager.ui.theme.*
import com.pigfarm.manager.viewmodel.BreedingViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BreedingScreen(
    navController: NavController,
    vm: BreedingViewModel = hiltViewModel()
) {
    val breedings         by vm.breedingsWithSow.collectAsState()
    val confirmedPregs    by vm.confirmedPregnancies.collectAsState()
    val sowsDueSoon       by vm.sowsDueSoon.collectAsState()
    val heatCheckDue      by vm.heatCheckDue.collectAsState()
    val activeSows        by vm.activeSows.collectAsState()
    val activeBoars       by vm.activeBoars.collectAsState()

    var selectedTab       by remember { mutableIntStateOf(0) }
    var showAddBreeding   by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Breeding & Pregnancy") },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary)
            )
        },
        floatingActionButton = {
            if (selectedTab == 0) PrimaryFab("Record Service", Icons.Default.Favorite) { showAddBreeding = true }
        }
    ) { padding ->
        Column(Modifier.padding(padding)) {
            TabRow(selectedTabIndex = selectedTab) {
                listOf("Services", "Pregnancies", "Due Soon", "Heat Check").forEachIndexed { i, t ->
                    Tab(selected = selectedTab == i, onClick = { selectedTab = i }, text = { Text(t) })
                }
            }
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                when (selectedTab) {
                    // ── Services tab ──────────────────────
                    0 -> {
                        if (breedings.isEmpty()) {
                            item { EmptyState("No breeding records yet") }
                        } else {
                            items(breedings, key = { it.breeding.id }) { bws ->
                                BreedingCard(bws)
                            }
                        }
                    }
                    // ── Pregnancies tab ───────────────────
                    1 -> {
                        if (confirmedPregs.isEmpty()) {
                            item { EmptyState("No confirmed pregnancies") }
                        } else {
                            items(confirmedPregs, key = { it.pregnancy.id }) { pws ->
                                PregnancyCard(pws,
                                    onMarkOpen = { vm.markOpen(pws.pregnancy) }
                                )
                            }
                        }
                    }
                    // ── Due Soon tab ──────────────────────
                    2 -> {
                        if (sowsDueSoon.isEmpty()) {
                            item { EmptyState("No sows due in the next 14 days") }
                        } else {
                            item {
                                Card(
                                    Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = Amber100)
                                ) {
                                    Text(
                                        "⚠️ ${sowsDueSoon.size} sow(s) farrowing within 14 days",
                                        Modifier.padding(12.dp),
                                        style = MaterialTheme.typography.titleMedium, color = Amber700
                                    )
                                }
                            }
                            items(sowsDueSoon, key = { it.pregnancy.id }) { pws ->
                                DueSoonCard(pws)
                            }
                        }
                    }
                    // ── Heat Check tab ────────────────────
                    3 -> {
                        if (heatCheckDue.isEmpty()) {
                            item { EmptyState("No sows currently due for heat check") }
                        } else {
                            item {
                                Card(
                                    Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = Blue100)
                                ) {
                                    Column(Modifier.padding(12.dp)) {
                                        Text("🔁 Return-to-Heat Check", style = MaterialTheme.typography.titleMedium, color = Blue600)
                                        Text("Sows bred 18–24 days ago without confirmed pregnancy",
                                            style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                            items(heatCheckDue, key = { it.id }) { b ->
                                HeatCheckCard(b,
                                    onConfirmPregnant = {
                                        // find the pregnancy and confirm it
                                    },
                                    onMarkOpen = { /* re-breed */ }
                                )
                            }
                        }
                    }
                }
                item { Spacer(Modifier.height(80.dp)) }
            }
        }
    }

    if (showAddBreeding) {
        AddBreedingDialog(
            sows   = activeSows,
            boars  = activeBoars,
            onDismiss = { showAddBreeding = false }
        ) { breeding ->
            vm.addBreeding(breeding)
            showAddBreeding = false
        }
    }
}

@Composable
private fun BreedingCard(bws: BreedingWithSow) {
    Card(
        Modifier.fillMaxWidth(),
        colors    = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Favorite, contentDescription = null, tint = Color(0xFFE91E63), modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Sow: ${bws.sow?.tagNumber ?: bws.breeding.sowId}", style = MaterialTheme.typography.titleMedium)
                Text("Date: ${bws.breeding.breedingDate.toDateString()} · ${bws.breeding.method.name}",
                    style = MaterialTheme.typography.bodySmall)
                Text("Expected farrowing: ${bws.breeding.expectedFarrowingDate.toDateString()}",
                    style = MaterialTheme.typography.bodySmall, color = Amber700)
            }
        }
    }
}

@Composable
private fun PregnancyCard(pws: PregnancyWithSow, onMarkOpen: () -> Unit) {
    val daysLeft = pws.pregnancy.expectedFarrowingDate?.daysUntil() ?: 0L
    Card(
        Modifier.fillMaxWidth(),
        colors    = CardDefaults.cardColors(containerColor = if (daysLeft < 7) Red100 else Green50),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(pws.sow?.tagNumber ?: "—", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    if (daysLeft <= 0) "DUE" else "$daysLeft days",
                    style  = MaterialTheme.typography.labelLarge,
                    color  = if (daysLeft < 7) Red700 else Green600,
                    fontWeight = FontWeight.Bold
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                pws.pregnancy.expectedFarrowingDate?.let {
                    LabeledField("Expected", it.toDateString())
                }
                pws.pregnancy.confirmationDate?.let {
                    LabeledField("Confirmed", it.toDateString())
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onMarkOpen) { Text("Mark Open", color = Red700) }
            }
        }
    }
}

@Composable
private fun DueSoonCard(pws: PregnancyWithSow) {
    val daysLeft = pws.pregnancy.expectedFarrowingDate?.daysUntil() ?: 0L
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Red100)
    ) {
        Row(Modifier.padding(14.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(pws.sow?.tagNumber ?: "—", style = MaterialTheme.typography.titleMedium)
                Text(pws.sow?.breed ?: "", style = MaterialTheme.typography.bodySmall)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    if (daysLeft <= 0) "TODAY" else "D-$daysLeft",
                    style = MaterialTheme.typography.headlineSmall,
                    color = if (daysLeft <= 0) Red700 else Amber700,
                    fontWeight = FontWeight.Bold
                )
                pws.pregnancy.expectedFarrowingDate?.let {
                    Text(it.toDateString(), style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun HeatCheckCard(b: BreedingEntity, onConfirmPregnant: () -> Unit, onMarkOpen: () -> Unit) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Blue100)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Sow #${b.sowId}", style = MaterialTheme.typography.titleMedium)
                Text("${b.breedingDate.daysAgo()}d since service", style = MaterialTheme.typography.bodySmall, color = Blue600)
            }
            Text("Bred: ${b.breedingDate.toDateString()} · ${b.method.name}", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onMarkOpen, modifier = Modifier.weight(1f)) { Text("Open / Re-breed") }
                Button(onClick = onConfirmPregnant, modifier = Modifier.weight(1f)) { Text("Confirm Pregnant") }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddBreedingDialog(
    sows: List<PigEntity>,
    boars: List<PigEntity>,
    onDismiss: () -> Unit,
    onSave: (BreedingEntity) -> Unit
) {
    var selectedSow    by remember { mutableStateOf<Long?>(null) }
    var selectedBoar   by remember { mutableStateOf<Long?>(null) }
    var method         by remember { mutableStateOf(BreedingMethod.NATURAL) }
    var aiBatch        by remember { mutableStateOf("") }
    var sowExpanded    by remember { mutableStateOf(false) }
    var boarExpanded   by remember { mutableStateOf(false) }
    var methodExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Record Service") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Sow picker
                ExposedDropdownMenuBox(expanded = sowExpanded, onExpandedChange = { sowExpanded = it }) {
                    OutlinedTextField(
                        value = sows.find { it.id == selectedSow }?.tagNumber ?: "Select Sow *",
                        onValueChange = {}, readOnly = true,
                        label = { Text("Sow") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(sowExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = sowExpanded, onDismissRequest = { sowExpanded = false }) {
                        sows.forEach { s ->
                            DropdownMenuItem(
                                text = { Text("${s.tagNumber} ${if (s.name.isNotBlank()) "· ${s.name}" else ""}") },
                                onClick = { selectedSow = s.id; sowExpanded = false }
                            )
                        }
                    }
                }
                // Method
                ExposedDropdownMenuBox(expanded = methodExpanded, onExpandedChange = { methodExpanded = it }) {
                    OutlinedTextField(
                        value = method.name, onValueChange = {}, readOnly = true,
                        label = { Text("Method") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(methodExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = methodExpanded, onDismissRequest = { methodExpanded = false }) {
                        BreedingMethod.entries.forEach { m ->
                            DropdownMenuItem(text = { Text(m.name) }, onClick = { method = m; methodExpanded = false })
                        }
                    }
                }
                if (method == BreedingMethod.NATURAL && boars.isNotEmpty()) {
                    ExposedDropdownMenuBox(expanded = boarExpanded, onExpandedChange = { boarExpanded = it }) {
                        OutlinedTextField(
                            value = boars.find { it.id == selectedBoar }?.tagNumber ?: "Select Boar",
                            onValueChange = {}, readOnly = true,
                            label = { Text("Boar (optional)") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(boarExpanded) },
                            modifier = Modifier.menuAnchor().fillMaxWidth()
                        )
                        ExposedDropdownMenu(expanded = boarExpanded, onDismissRequest = { boarExpanded = false }) {
                            boars.forEach { b ->
                                DropdownMenuItem(text = { Text(b.tagNumber) }, onClick = { selectedBoar = b.id; boarExpanded = false })
                            }
                        }
                    }
                }
                if (method == BreedingMethod.AI) {
                    OutlinedTextField(value = aiBatch, onValueChange = { aiBatch = it },
                        label = { Text("AI Batch Number") }, modifier = Modifier.fillMaxWidth())
                }
                Text(
                    "Expected farrowing: ${selectedSow?.let { "+114 days from today" } ?: "—"}",
                    style = MaterialTheme.typography.bodySmall, color = Amber700
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    selectedSow?.let { sowId ->
                        onSave(BreedingEntity(
                            farmId   = 1L,
                            sowId    = sowId,
                            boarId   = selectedBoar,
                            method   = method,
                            aiBatch  = aiBatch
                        ))
                    }
                },
                enabled = selectedSow != null
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
